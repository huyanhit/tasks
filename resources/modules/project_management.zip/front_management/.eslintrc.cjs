/* eslint-env node */
require('@rushstack/eslint-patch/modern-module-resolution')

module.exports = {
    root: true,
    'extends': [
        'plugin:vue/vue3-essential',
        'eslint:recommended',
        '@vue/eslint-config-prettier/skip-formatting',
        "plugin:vue/vue3-recommended",
        "plugin:@typescript-eslint/recommended"
    ],
    "parser": "vue-eslint-parser",
    parserOptions: {
        ecmaVersion: 'latest',
        "parser": "@typescript-eslint/parser",
        "extraFileExtensions": [".vue"],
    },
    rules: {
        'vue/multi-word-component-names': 'off',
        'vue/singleline-html-element-content-newline': 'off',
        'vue/multiline-html-element-content-newline': 'off',
        "vue/max-attributes-per-line": ["error", {
            "singleline": {
                "max": 3
            },
            "multiline": {
                "max": 3
            }
        }],
        "object-curly-newline": ["error", {
            "multiline": true,
            "consistent": true,
            "ObjectExpression": { "multiline": 3 },
            "ObjectPattern": { "multiline": 3 },
            "ImportDeclaration": { "multiline": true },
            "ExportDeclaration": { "multiline": true }
        }],
        "vue/html-indent": ["error", tab, {
            "attribute": 1,
            "baseIndent": 1,
            "closeBracket": 1,
            "alignAttributesVertically": true,
            "ignores": []
        }]
    },
    "globals": {
        "$": true,
        "require": true,
        "process": true
    },
    "plugins": [
        "vue",
        "@typescript-eslint"
    ],
}
