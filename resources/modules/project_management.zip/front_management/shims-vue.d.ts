// declare module '*.vue' {
//   import type { DefineComponent } from 'vue'
//   const component: DefineComponent<object, object, any>
//   export default component
// }

// shims-vue.d.ts
declare module "*.vue"

declare module "*.ts" {
  const value: any;
  export default value;
}

declare module "*.js" {
  const value: any;
  export default value;
}
