import { createApp } from 'vue'
import { createPinia } from 'pinia'
import App from './App.vue'
import router from './router'
import i18n from './plugins/i18n'
import mitt from 'mitt'
import axios from 'axios'
import VueAxios from 'vue-axios'
import filters from './helpers/filter'
import CKEditor from '@ckeditor/ckeditor5-vue'
import simpleBar from './plugins/simple-bar'
import iconify from './plugins/iconify'
import globalComponent from './plugins/globals'
import contextMenu from './plugins/context-menu'
import vueForm from './plugins/vueform'
import './plugins/vee-validate'
import './plugins/flat-date-picker'

import BootstrapVueNext from 'bootstrap-vue-next'
import 'bootstrap-vue-next/dist/bootstrap-vue-next.css'
import '@/assets/scss/config/creative/app.scss'
import '@/assets/scss/mermaid.min.css'
import bootstrapVue from 'bootstrap-vue-next'
import Popper from 'vue3-popper'
import VueApexCharts from "vue3-apexcharts";

const app = createApp(App)
const pinia = createPinia();
const emitter  = mitt();

app.use(router)
app.use(pinia)
app.use(i18n)
app.use(VueAxios, axios)
app.use(BootstrapVueNext)
app.use(CKEditor)
app.use(VueApexCharts);
app.use(iconify)
app.use(simpleBar)
app.use(globalComponent)
app.use(contextMenu)
app.use(vueForm)
app.component('Popper', Popper)

app.use(bootstrapVue({ plugins: { modalController: true } }))

app.config.globalProperties.event = emitter;
app.provide('emitter', emitter);
app.config.globalProperties.filters = filters;

app.mount('#app')
