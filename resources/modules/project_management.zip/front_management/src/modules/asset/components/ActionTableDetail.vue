<template>
  <div class="d-flex">
    <d-dropdown :dropdown-data="data.dropdown_data" @click-item="handleClickItem" />
    <d-dropdown-context-menu :dropdown-data="data.dropdown_data_context" />
  </div>
  <AllocateModal />
</template>

<script setup lang="ts">
import { inject, reactive, h } from "vue";
import DDropdown from "@/components/common/action-bar/DDropdown.vue";
import DDropdownContextMenu from "@/components/common/action-bar/DDropdownContextMenu.vue";
import { useI18n } from "vue-i18n";
import AllocateModal from "../views/assets/modals/AllocateModal.vue";

const emitter = inject<any>("emitter");

const openModal = (modalKey: string) => {
  emitter.emit(`open-${modalKey}`);
};

const { t } = useI18n();
const data = reactive({
  dropdown_data: [
    {
      id: "allocate",
      icon: "ri-briefcase-line",
      type: "modal",
      label: "Cấp phát",
    },
    {
      id: "task_categories",
      icon: "ri-arrow-go-back-line",
      type: "link",
      label: "Thu hồi",
    },
    {
      id: "modalCreateJob1",
      icon: "ri-close-circle-line",
      label: "Báo Huỷ",
      type: "modal",
    },
    {
      id: "modalCreateJob2",
      icon: "ri-error-warning-line",
      label: "Báo Hỏng",
      type: "modal",
    },
    {
      id: "modalCreateJob3",
      icon: "ri-tools-line",
      label: "Sửa chữa",
      type: "modal",
    },
  ],
  dropdown_data_context: {
    name: "label",
    icon: "ri-more-2-line",
    label: t("projects.projects.action.add"),
    item: [
      {
        label: t("projects.projects.add_task"),
        icon: h("i", { class: "ri-add-large-line" }),
        children: [
          {
            label: t("projects.projects.add_normal_task"),
            icon: h("i", { class: "ri-add-line" }),
            onClick: () => {},
          },
          {
            label: t("projects.projects.add_task_by_category"),
            icon: h("i", { class: "ri-add-line" }),
            onClick: () => {},
          },
          {
            label: t("projects.projects.add_task_by_phase"),
            icon: h("i", { class: "ri-add-line" }),
            onClick: () => {},
          },
        ],
      },
    ],
  },
});

const handleClickItem = (item: any) => {
  if (item.type === 'modal') {
    openModal(item.id);
  }
};

</script>
