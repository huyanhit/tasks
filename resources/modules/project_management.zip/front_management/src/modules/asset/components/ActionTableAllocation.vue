<template>
	<div class="button-container d-flex">
		<DDropdown :dropdownData="data.dropdown_data" @clickItem="clickItem"/>
	</div>
</template>

<script setup lang="ts">
import { reactive } from 'vue';
import { useRoute, useRouter } from 'vue-router';
import DDropdown from '@/components/common/action-bar/DDropdown.vue';
import DDropdownCheckBox from "@/components/common/action-bar/DDropdownCheckBox.vue";
const route = useRoute();
const router = useRouter();
const data = reactive({
	dropdown_data: [
		{ icon: 'ri-question-line', label: 'common.action_bar.help', type: 'link', href: '#' }
	]
});
</script>
<style scoped>
	.button-container {
		display: flex;
	}
</style>
