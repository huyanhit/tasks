<template>
    <SearchHeader v-model="multiSearch" is-show-modal @filter="search">
      form searh Asset
    </SearchHeader>
</template>

<script setup lang="ts">
const multiSearch = ref();
const search = ref();
</script>
