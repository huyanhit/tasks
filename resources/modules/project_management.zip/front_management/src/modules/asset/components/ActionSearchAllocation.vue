<template>
    <SearchHeader v-model="multiSearch" is-show-modal @filter="search">
      form searh Allocation
    </SearchHeader>
</template>

<script setup lang="ts">
const multiSearch = ref();
const search = ref();
</script>
