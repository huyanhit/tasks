<template>
  <div class="d-flex align-items-center">
    <DHeaderAction :dropdownData="dropdownData" :page-title="pageTitle" />
  </div>
</template>

<script setup lang="ts">
import { useI18n } from "vue-i18n";

const { t } = useI18n();
import DHeaderAction from "@/components/common/DHeaderAction.vue";
const props = defineProps({
  pageTitle: {
    type: String,
    required: true,
  },
});

const dropdownData = [
  {
    id: "add_asset",
    title: t("assets.assets.headerAction.assets"),
    type: "link",
    href: "/asset/add-asset",
  },
  {
    id: "add_allocation",
    title: t("assets.assets.headerAction.allocation"),
    type: "link",
    href: "/asset/add-allocation",
  },
  {
    id: "add_recovery",
    title: t("assets.assets.headerAction.reclaim"),
    type: "/asset/add-recovery",
    href: "#",
  },
  {
    id: "setting",
    title: t("assets.assets.headerAction.settings"),
    type: "link",
    href: "/setting-asset",
    footer: true,
  },
];
</script>
