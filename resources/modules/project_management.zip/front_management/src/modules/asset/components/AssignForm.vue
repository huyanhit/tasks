<template>
<div class="field-group-container">
    <div v-for="(fieldGroup, groupIndex) in fields" :key="groupIndex" class="field-group">
        <div class="fields-wrapper" :style="{ gridTemplateColumns: `repeat(${fieldGroup.length}, 1fr)` }">
            <!-- Render fields directly -->
        <component
          v-for="(field, fieldIndex) in fieldGroup"
          :is="field.type === 'select' ? DAutocomplete : DTextField"
          :key="field.id"
          v-bind="field"
          v-model="assetInfo[groupIndex][field.forInput]"
          :options="field.type === 'select' ? options[field.forInput] : undefined"
          :rules="field.rules || []"
          class="field-item"
        />     
        </div>
        <div xl="1">
          <Icon @click="removeFieldGroup(groupIndex)" class="icon-sp-remove-field" :class="{ 'cursor-pointer': canRemoveField, 'cursor-no-drop': !canRemoveField }" icon="ri:indeterminate-circle-line" width="25" :color="canRemoveField ? '' : '#ccc'" />
        </div>
    </div>
    <div class="add-button-wrapper col-2">
        <Icon @click="addFields" class="icon-sp-addField p-1 cursor-pointer" icon="ri:add-circle-line" width="35" color="#f87c30" />
    </div>
</div>
</template>

<script setup lang="ts">
import { ref, onMounted, defineEmits, computed } from 'vue';
import DTextField from "@/components/common/DTextField.vue";
import DAutocomplete from "@/components/common/DAutocomplete.vue";

interface Rules {
  // Define your validation rules here, for example:
  (value: any): string | boolean;
}

interface FieldConfig {
  type: string;
  label: string;
  name: string;
  placeholder: string;
  rules?: Rules[];
}

interface AssetInfo {
    [key: string]: string; // All other properties are strings
    rules?: Rules[]; // Explicitly define the rules property
}


const props = defineProps<{
  initialAssetInfo: Array<AssetInfo>;
  fieldsConfig: Array<FieldConfig>;
  options: { [key: string]: Array<{ id: string; name: string }> };
}>();

const assetInfo = ref(props.initialAssetInfo || []);
const fields = ref([cloneFieldGroup(props.fieldsConfig)]);
const canRemoveField = computed(() => fields.value.length > 1);

const emit = defineEmits(['asset-change']);
const valueModel = defineModel < any[] > ();

const addFields = () => {
    fields.value.push(cloneFieldGroup(props.fieldsConfig));
    assetInfo.value.push(createEmptyAssetInfo(props.fieldsConfig));
    updateModelValue();
};

const removeFieldGroup = (groupIndex: number) => {
    if (canRemoveField.value) {
        fields.value.splice(groupIndex, 1);
        assetInfo.value.splice(groupIndex, 1);
        updateModelValue();
    }
};

const updateModelValue = () => {
    valueModel.value = assetInfo.value;
    emit('asset-change', assetInfo.value);
};

onMounted(() => {
    updateModelValue();
});

function cloneFieldGroup(fieldConfigs: FieldConfig[]) {
    return fieldConfigs.map(config => ({
        ...config,
        id: generateUniqueId(),
    }));
}

function createEmptyAssetInfo(fieldConfigs: FieldConfig[]) {
    const emptyInfo: { [key: string]: any } = {};
    fieldConfigs.forEach(config => {
        emptyInfo[config.name] = '';
    });
    return emptyInfo;
}

function generateUniqueId() {
    return Date.now() + Math.random();
}

</script>

<style scoped>
.field-group-container {
    display: flex;
    flex-direction: column;
}

.field-group {
    display: flex;
    align-items: flex-start;
    /* Align fields and the remove icon */
    gap: 16px;
    /* Adjust spacing between fields and the remove icon */
}

.fields-wrapper {
    display: grid;
    gap: 16px;
    /* Adjust spacing between individual fields */
    flex-grow: 1;
}

.field-item {
    min-width: 0;
    /* Allow fields to shrink to fit within their grid cell */
}

.icon-sp-remove-field {
    margin-top: 8px;
}

.add-button-wrapper {
    display: flex;
    justify-content: flex-start;
}

</style>
