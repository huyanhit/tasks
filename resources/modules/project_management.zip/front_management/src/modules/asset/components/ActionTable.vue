<template>
	<div class="button-container d-flex">
		<DDropdownCheckBox :dropdownData="data.dropdown_checkbox" @apply="apply" @showDropdownCheckBox="showDropdownCheckBox"/>
		<DDropdown :dropdownData="data.dropdown_data" @clickItem="clickItem"/>
	</div>
</template>

<script setup lang="ts">
import { reactive } from 'vue';
import { useRoute, useRouter } from 'vue-router';
import DDropdown from '@/components/common/action-bar/DDropdown.vue';
import DDropdownCheckBox from "@/components/common/action-bar/DDropdownCheckBox.vue";
import { tagPStore } from '@/stores/tag.js';

const route = useRoute();
const router = useRouter();
const storePTag = tagPStore();
const emit = defineEmits<{ (e: 'filter', payload: { tag_ids: string[] }): void }>();

const data = reactive({
	dropdown_checkbox: [
		{ name: 'label', icon: 'ri-price-tag-3-line', label: 'common.action_bar.label', child: [] }
	],
	dropdown_data: [
		{ icon: 'ri-question-line', label: 'common.action_bar.help', type: 'link', href: '#' }
	]
});

const clickItem = (item: any) => item.href && router.push(item.href);

const apply = (item: any) => emit('filter', { tag_ids: item.child?.filter((child: any) => child.check).map((child: any) => child.id) || [] });

const getDataLabel = () => {
	const labelCheckBox = data.dropdown_checkbox.find(item => item.name === 'label');
	if (labelCheckBox && !labelCheckBox.child.length) {
		storePTag.tags.forEach(tag => labelCheckBox.child.push({ id: tag.id.toString(), title: tag.name, check: route.query.tag_ids?.includes(tag.id.toString()) }));
	}
};

const showDropdownCheckBox = async () => {
	if (!storePTag.tags) await storePTag.getTags();
	getDataLabel();
};
</script>

<style scoped>
.button-container {
	display: flex;
}
</style>
