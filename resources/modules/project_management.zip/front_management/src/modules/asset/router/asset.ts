
const MainLayout = () => import("@/layouts/Main.vue");
const ListAsset = () => import("@/modules/asset/views/assets/ListAsset.vue");
const ListAllocation = () => import("@/modules/asset/views/allocations/ListAllocation.vue");
const ListRecovery = () => import("@/modules/asset/views/recoveries/ListRecovery.vue");
const ListDepreciation = () => import("@/modules/asset/views/depreciations/ListDepreciation.vue");
const ListAssetAdd = () => import("@/modules/asset/views/assets/AddAsset.vue");
import DetailAsset from "@/modules/asset/views/assets/DetailAsset.vue";
import DetailAllocation from "@/modules/asset/views/allocations/DetailAllocation.vue";
import AddAllocation from "@/modules/asset/views/allocations/AddAllocation"
export default [
  {
    path: "/asset",
    name: "asset",
    component: MainLayout,
    children: [
      {
        path: "",
        name: "asset-list",
        component: ListAsset,
        meta: { module: "asset" },
      },
      {
        path: "add-asset",
        name: "asset-add",
        component: ListAssetAdd,
        meta: { module: "asset" },
      },
      {
        path: "detail-asset/:id",
        name: "detail-asset",
        component: DetailAsset,
        meta: { module: "asset" },
      },
      {
        path: "allocation",
        name: "allocation",
        component: ListAllocation,
        meta: { module: "asset" },
      },
      {
        path: "add-allocation",
        name: "add-allocation",
        component: AddAllocation,
        meta: { module: "asset" },
      },
      {
        path: "detail-allocation/detail/:id",
        name: "detail-allocation",
        component: DetailAllocation,
        meta: { module: "asset" },
      },
      {
        path: "recovery",
        name: "list-recovery",
        component: ListRecovery,
        meta: { module: "asset" },
      },
      {
        path: "depreciation",
        name: "list-depreciation",
        component: ListDepreciation,
        meta: { module: "asset" },
      },
    ],
  },
];
