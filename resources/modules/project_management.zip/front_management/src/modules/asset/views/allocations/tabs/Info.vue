<template>
    <BCard>
        <BRow class="mt-1">
            <BCol xl="5">
                <BRow>
                    <DTextField :label="$t('Mã CP')" name="ma_ts" required :placeholder="$t('Mã CP')" class="mb-3" xl="4" />
                    <DTextField :label="$t('Nhập tên cấp phát')" name="ma_ts" required :placeholder="$t('Nhập tên cấp phát')" class="mb-3" xl="8" />
                </BRow>
                <BRow>
                    <DAutocomplete :label="$t('Cấp phát cho')" name="asset_location" :placeholder="$t('Người cấp phát')" :options="options.localOptions" isMultiple="false" required class="mb-3" :col="12" />
                </BRow>
                <BRow>
                    <DAutocomplete :label="$t('Người cấp phát')" name="asset_location" :placeholder="$t('Nhập người cấp phát')" :options="options.localOptions" isMultiple="false" required class="mb-3" :col="12" />
                </BRow>
                <BRow>
                    <DDatePicker :label="$t('Ngày cấp phát')" name="purchase_date" required :placeholder="$t('Ngày cấp phát')" icon="ri-calendar-line" class="mb-3" :col="6" />
                    <DDatePicker :label="$t('Thời gian cấp phát')" name="warranty_end_date" required :placeholder="$t('Thời gian cấp phát')" icon="ri-calendar-line" class="mb-3" :col="6" />
                </BRow>
                <BRow>
                    <DTextField :label="$t('Địa điểm bàn giao')" name="purchase_price" required :placeholder="$t('Nhập địa điểm bàn giao')" class="mb-3" :col="12" />
                </BRow>
                <BRow>
                    <DTextField :label="$t('Đặt cọc')" name="purchase_price" required :placeholder="$t('Nhân đặt cọc')" class="mb-3" :col="12" />
                </BRow>
                <BRow>
                    <DDatePicker :label="$t('Nhập dự kiến ngày trả')" name="purchase_date" required :placeholder="$t('Nhập dự kiến ngày trả')" icon="ri-calendar-line" class="mb-3" :col="12" />
                </BRow>
                <BRow>
                  <DTextArea :label="'Lý do cấp phát'" name="ma_CP" required class='mb-3'/>
                </BRow>
                <BRow>
				          <FormAssign :initialAssetInfo="initialAssetData" :fieldsConfig="fieldsConfig" :options="selectOptions" />
			          </BRow>
            </BCol>
        </BRow>
  </BCard>
</template>

<script setup lang="ts">
  import { ref, computed } from 'vue';
  import DTextField from "@/components/common/DTextField.vue";
  import DTextArea from "@/components/common/DTextArea.vue";
  import FormAssign from "@/modules/asset/components/AssignForm.vue";
  
  const options = {
	localOptions: [
	  { name: 'Hà Nội', id: '' },
	  { name: 'Đà Nẵng', id: '2' },
	  { name: 'Hồ Chí Minh', id: '3' }
	]
  };

  const initialAssetData = [
	{ asset_name: 'Asset 1', quantity: '100', stock: '50', receiver: 'Receiver A' },
	{ asset_name: 'Asset 2', quantity: '200', stock: '120', receiver: 'Receiver B' },
  ];
  
  const fieldsConfig = [
	{ type: 'select', label: 'Tài sản', name: 'asset_name', placeholder: 'Chọn tài sản' },
	{ type: 'input', label: 'Số lượng', name: 'quantity', placeholder: 'Nhập số lượng' },
	{ type: 'input', label: 'Tồn kho', name: 'stock', placeholder: 'Nhập tồn kho' },
	{ type: 'select', label: 'Người nhận', name: 'receiver', placeholder: 'Chọn người nhận' },
  ];

  const selectOptions = {
	asset_name: [
	  { id: 'Asset 1', name: 'Asset 1' },
	  { id: 'Asset 2', name: 'Asset 2' },
	],
	receiver: [
	  { id: 'Receiver A', name: 'Receiver A' },
	  { id: 'Receiver B', name: 'Receiver B' },
	  { id: 'Receiver C', name: 'Receiver C' },
	],
  };
  </script>