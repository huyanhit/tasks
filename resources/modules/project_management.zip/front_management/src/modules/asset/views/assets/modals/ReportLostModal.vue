<!-- FailureModal -->
<template>
	<d-form-modal :loading="loading" v-model="isVisible" size="lg" scrollable :title="title" @submit="onSubmit">
		<BRow>
			<DTextField
				:label="'Tài sản'"
				name="ma_CP"
				forInput="ma_CP"
				required
				:placeholder="'Chọn sản'"
				class="mb-3"
				xl="12"
			/>
		</BRow>
		<BRow>
			<DDatePicker
				:label="$t('assets.assets.addAsset.information.purchaseDate')"
				name="purchase_date"
				forInput="purchase_date"
				required
				:placeholder="$t('assets.assets.addAsset.information.purchaseDatePlaceholder')"
				icon="ri-calendar-line"
				class="mb-3"
				:col="4"
			/>
			<DTextField
				:label="'Số lượng'"
				name="ma_CP"
				forInput="ma_CP"
				required
				:placeholder="'Số lượng'"
				class="mb-3"
				xl="4"
			/>
			<DTextField
				:label="'Giá trị'"
				name="ma_CP"
				forInput="ma_CP"
				required
				:placeholder="'Giá trị'"
				class="mb-3"
				xl="4"
			/>
		</BRow>
		
			<DTextArea
				:label="'Mô tả'"
				name="ma_CP"
				forInput="ma_CP"
				required
				:placeholder="'Nhập mô tả'"
			/>
		
	</d-form-modal>
</template>

<script setup lang="ts">
import { ref, inject, onMounted, onUnmounted, defineExpose } from 'vue';
import DFormModal from "@/components/common/DFormModal.vue";
import DTextField from "@/components/common/DTextField.vue";
import DDatePicker from "@/components/common/DDatePicker.vue";

const isVisible = ref(false);
const title = 'Phiếu báo mất';
const loading = ref(false);

const open = () => {
	isVisible.value = true;
};

const emitter = inject<any>('emitter');

if (emitter) {
	const handleOpen = () => open();
	
	onMounted(() => {
		emitter.on('open-reportLost', handleOpen);
	});
	
	onUnmounted(() => {
		emitter.off('open-reportLost', handleOpen);
	});
}

defineExpose({ open });
</script>
