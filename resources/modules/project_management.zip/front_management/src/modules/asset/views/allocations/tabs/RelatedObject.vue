<template>
    <BCard>
    <BRow class="mt-1">
        <BCol xl="5">
          <FormAssign :initialAssetInfo="iRelatedObjectsData" :fieldsConfig="iRelatedObjectsConfig" :options="selectOptions" />
        </BCol>
    </BRow>
  </BCard>
</template>

<script setup lang="ts">
  import { ref, computed } from 'vue';
  import FormAssign from "@/modules/asset/components/AssignForm.vue";
  const iRelatedObjectsData = [
	{ asset_name: 'Asset 1', quantity: '100', stock: '50', receiver: 'Receiver A' },
	{ asset_name: 'Asset 2', quantity: '200', stock: '120', receiver: 'Receiver B' },
  ];
  
  const iRelatedObjectsConfig = [
	{ type: 'select', label: 'Đối tượng liên quan', name: 'asset_name', placeholder: 'Chọn tài này' },
  ];

  
  const selectOptions = {
	asset_name: [
	  { id: 'Asset 1', name: 'Asset 1' },
	  { id: 'Asset 2', name: 'Asset 2' },
	],
	receiver: [
	  { id: 'Receiver A', name: 'Receiver A' },
	  { id: 'Receiver B', name: 'Receiver B' },
	  { id: 'Receiver C', name: 'Receiver C' },
	],
  };
</script>