<!--TagsModal-->
<template>
	<d-form-modal :loading="loading" v-model="isVisible" size="lg" scrollable :title="title" @submit="onSubmit">
		<DAutocomplete
			:label="'Chọn nhãn'"
			name="contract_type"
			forInput="contract_type"
			:placeholder="'Chọn nhãn'"
			isMultiple="{false}"
			required
		/>
	</d-form-modal>
</template>

<script setup lang="ts">
import { ref, inject, onMounted, onUnmounted, defineExpose } from 'vue';
import DFormModal from "@/components/common/DFormModal.vue";
import DAutocomplete from "@/components/common/DAutocomplete.vue";

const isVisible = ref(false);
const title = 'Allocate Modal';
const loading = ref(false);

const open = () => {
	isVisible.value = true;
};

const emitter = inject<any>('emitter');

if (emitter) {
	const handleOpen = () => open();
	
	onMounted(() => {
		emitter.on('open-tags', handleOpen);
	});
	
	onUnmounted(() => {
		emitter.off('open-tags', handleOpen);
	});
}

defineExpose({ open });
</script>
