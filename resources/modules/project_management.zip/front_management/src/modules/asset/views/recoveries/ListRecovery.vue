<template>
    <section no-body class="section-teleport gap">
      <DTeleport to="#teleport-header-action">
        <HeaderAction :page-title="$t('Danh sách thu hồi')" />
      </DTeleport>
      <DTeleport to="#teleport-header-search">
        <SearchAllocation />
      </DTeleport>
    </section>
  
    <BRow>
      <BCol class="page_header" cols="12">
        <div class="page-title-box d-lg-flex align-items-center justify-content-between bg-galaxy-transparent">
          <DTabs v-model="activeTab" :tabs="tabs" />
          <ActionTableAllocation />
        </div>
      </BCol>
    </BRow>
  
    <BCard no-body>
      <BCardBody class="p-0 tab-content text-muted">
        <data-table
          @open-menu="openContextMenu"
          is-show-checkbox
          v-model:selected="selected"
          v-model:params="params"
          :loading="loading"
          :data="data"
          :headers="headers">
          <template #item.name_recovery="{ item }">
            <a href="">{{ item.name_recovery }}</a>
          </template>
        </data-table>
      </BCardBody>
    </BCard>
  </template>
  
  <script setup lang="ts">
  import { ref, Ref, computed, h, watch } from "vue";
  import { useI18n } from "vue-i18n";
  import { useRouter } from "vue-router";
  import ContextMenu from "@imengyu/vue3-context-menu";
  import DTeleport from "@/components/common/DTeleport.vue";
  import DataTable from "@/components/common/DataTable.vue";
  import useGetDatatable from "@/modules/setting_project/composables/use-get-datatable";
  import HeaderAction from "@/modules/asset/components/ActionHeader.vue";
  import ActionTableAllocation from "@/modules/asset/components/ActionTableAllocation.vue";
  import SearchAllocation from "@/modules/asset/components/ActionSearchAllocation.vue"
  import { AssetTypeService } from "@/modules/setting_asset/services/asset_type";

  const router = useRouter();
  const { t } = useI18n();
  const getData = async (data: any) => {
  return {
    data : {
      data: [
      {
        id: 1,
        name_recovery: "Thu hồi Server",
        code_recovery: "0001",
        date_recovery: "01/06/2024",
        created_at: "01/06/2024",
        created_by: "MP Vietnam",
    },
    {
        id: 1,
        name_recovery: "Thu hồi Server",
        code_recovery: "0001",
        date_recovery: "01/06/2024",
        created_at: "01/06/2024",
        created_by: "MP Vietnam",
    }
      ],
      pagination: {},
      summary: []
    }
  }
}

  const { loading, selected, totalPages, data, fetchData, params } = useGetDatatable(getData);

  
  const openContextMenu = ({ $event, item }) => {
    ContextMenu.showContextMenu({
      x: $event.x,
      y: $event.y,
      items: [
        {
          label: "Chi tiết",
          icon: h("i", { class: "ri-file-list-line" }),
        },
        {
          label: "Sửa",
          icon: h("i", { class: "ri-edit-line" }),
        },
        {
          label: "Xoá",
          icon: h("i", { class: "ri-delete-bin-line" }),
        },
      ],
    });
  };
  
  interface TableHeader {
    text: string;
    value: string;
    align: string;
    sortable: boolean;
    width?: string;
  }
  
  const headers = ref<Array<TableHeader>>([
    {
      text: t("Tên thu hồi"),
      value: "name_recovery",
      align: "left",
      sortable: true,
      width: "150px",
    },
    {
      text: t("Mã thu hồi"),
      value: "code_recovery",
      align: "left",
      sortable: false,
      width: "300px",
    },
    {
      text: t("Ngày thu hồi"),
      value: "date_recovery",
      align: "left",
      sortable: false,
      width: "100px",
    },
    {
      text: t("Ngày tạo"),
      value: "created_at",
      align: "left",
      sortable: false,
      width: "170px",
    },
    {
      text: t("Người tạo"),
      value: "created_by",
      align: "left",
      sortable: false,
      width: "170px",
    }
  ]);
  
  const activeTab = ref(0);
  const tabs = [
    { id: 0, label: t("assets.assets.tabs.all"),  count: 0 }
  ];

  </script>
  