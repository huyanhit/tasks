<template>
	<BCard>
		<BRow class="mt-1">
            <BCol xl="5">
                <BRow>
                    <DTextField
                        :label="$t('assets.assets.addAsset.information.assetCode')"
                        name="ma_ts"
                        forInput="ma_ts"
                        required
                        :placeholder="$t('assets.assets.addAsset.information.assetCodePlaceholder')"
                        class="mb-3"
                        xl="4"
                    />
                    <DTextField
                        :label="$t('assets.assets.addAsset.information.quantity')"
                        name="quantity"
                        forInput="quantity"
                        required
                        :placeholder="$t('assets.assets.addAsset.information.quantityPlaceholder')"
                        class="mb-3"
                        xl="4"
                    />
                    <DAutocomplete
                        :label="$t('assets.assets.addAsset.information.unit')"
                        name="contract_type"
                        forInput="contract_type"
                        :placeholder="$t('assets.assets.addAsset.information.unitTypePlaceholder')"
                        :options="options.unitOptions"
                        isMultiple="{false}"
                        required
                        class="mb-3"
                        xl="4"
                    />
                </BRow>
                <BRow>
                    <DTextField
                        :label="$t('assets.assets.addAsset.information.assetName')"
                        name="asset_name"
                        forInput="asset_name"
                        required
                        :placeholder="$t('assets.assets.addAsset.information.assetNamePlaceholder')"
                        class="mb-3"
                        :col="8"
                    />
                    <DTextField
                        :label="$t('assets.assets.addAsset.information.modelSeries')"
                        name="model_series"
                        forInput="model_series"
                        required
                        :placeholder="$t('assets.assets.addAsset.information.modelSeriesPlaceholder')"
                        class="mb-3"
                        :col="4"
                    />
                </BRow>
                <BRow>
                    <DAutocomplete
                        :label="$t('assets.assets.addAsset.information.assetType')"
                        name="asset_type"
                        forInput="asset_type"
                        :placeholder="$t('assets.assets.addAsset.information.assetTypePlaceholder')"
                        :options="options.assetTypeOptions"
                        isMultiple="{false}"
                        required
                        class="mb-3"
                        :col="8"
                    />
                    <DTextField
                        :label="$t('assets.assets.addAsset.information.barcode')"
                        name="barcode"
                        forInput="barcode"
                        required
                        :placeholder="$t('assets.assets.addAsset.information.barcodePlaceholder')"
                        class="mb-3"
                        :col="4"
                    />
                </BRow>
                <BRow>
                    <DDatePicker
                        :label="$t('assets.assets.addAsset.information.purchaseDate')"
                        name="purchase_date"
                        forInput="purchase_date"
                        required
                        :placeholder="$t('assets.assets.addAsset.information.purchaseDatePlaceholder')"
                        icon="ri-calendar-line"
                        class="mb-3"
                        :col="4"
                    />
                    <DTextField
                        :label="$t('assets.assets.addAsset.information.warrantyPeriod')"
                        name="warranty_period"
                        forInput="warranty_period"
                        required
                        :placeholder="$t('assets.assets.addAsset.information.warrantyPeriodPlaceholder')"
                        class="mb-3"
                        :col="4"
                    />
                    <DDatePicker
                        :label="$t('assets.assets.addAsset.information.warrantyEndDate')"
                        name="warranty_end_date"
                        forInput="warranty_end_date"
                        required
                        :placeholder="$t('assets.assets.addAsset.information.warrantyEndDatePlaceholder')"
                        icon="ri-calendar-line"
                        class="mb-3"
                        :col="4"
                    />
                </BRow>
                <BRow>
                    <DTextField
                        :label="$t('assets.assets.addAsset.information.purchasePrice')"
                        name="purchase_price"
                        forInput="purchase_price"
                        required
                        :placeholder="$t('assets.assets.addAsset.information.purchasePricePlaceholder')"
                        class="mb-3"
                        :col="6"
                    />
                    <DTextField
                        :label="$t('assets.assets.addAsset.information.depreciation')"
                        name="depreciation"
                        forInput="depreciation"
                        required
                        :placeholder="$t('assets.assets.addAsset.information.depreciationPlaceholder')"
                        class="mb-3"
                        :col="6"
                    />
                </BRow>
                <BRow>
                    <DTextField
                        :label="$t('assets.assets.addAsset.information.supplier')"
                        name="supplier"
                        forInput="supplier"
                        required
                        :placeholder="$t('assets.assets.addAsset.information.supplierPlaceholder')"
                        class="mb-3"
                        :col="12"
                    />
                </BRow>
                <BRow>
                    <DTextField
                        :label="$t('assets.assets.addAsset.information.supplierAddress')"
                        name="address"
                        forInput="address"
                        required
                        :placeholder="$t('assets.assets.addAsset.information.supplierAddressPlaceholder')"
                        class="mb-3"
                        :col="12"
                    />
                </BRow>
                <BRow>
                    <DTextField
                        :label="$t('assets.assets.addAsset.information.supplierPhone')"
                        name="phone"
                        forInput="phone"
                        required
                        :placeholder="$t('assets.assets.addAsset.information.supplierPhonePlaceholder')"
                        class="mb-3"
                        :col="12"
                    />
                </BRow>
                <BRow>
                    <DAutocomplete
                        :label="$t('assets.assets.addAsset.information.assetLocation')"
                        name="asset_location"
                        forInput="asset_location"
                        :placeholder="$t('assets.assets.addAsset.information.assetLocationPlaceholder')"
                        :options="options.localOptions"
                        isMultiple="{false}"
                        required
                        class="mb-3"
                        :col="12"
                    />
                </BRow>
                <BRow>
                    <DAutocomplete
                        :label="$t('assets.assets.addAsset.information.legalOwner')"
                        name="legal_owner"
                        forInput="legal_owner"
                        :placeholder="$t('assets.assets.addAsset.information.legalOwnerPlaceholder')"
                        :options="options.legalEntityOptions"
                        isMultiple="{false}"
                        required
                        class="mb-3"
                        :col="12"
                    />
                </BRow>
                <BRow>
                    <DAutocomplete
                        :label="$t('assets.assets.addAsset.information.managingDepartment')"
                        name="managing_department"
                        forInput="managing_department"
                        :placeholder="$t('assets.assets.addAsset.information.managingDepartmentPlaceholder')"
                        :options="options.departmentOptions"
                        isMultiple="{false}"
                        required
                        class="mb-3"
                        :col="12"
                    />
                </BRow>
                <BRow class="mb-lg-3">
                    <BCol xl="4">
                        <DUploadFile :col="12" :label="$t('assets.assets.addAsset.information.assetImage')" />
                    </BCol>
                </BRow>
                <BRow class="mb-lg-4">
                    <BCol>
                        <p class="text__enter--description mb-2">{{ $t('assets.assets.addAsset.information.description') }}</p>
                        <div class="mt-lg-2">
                            <Field
                                name="description"
                                :label="$t('assets.assets.addAsset.information.description')"
                                class="form-control"
                                v-slot="{ field }"
                            >
                                <ckeditor :editor="editor" v-bind="field"></ckeditor>
                            </Field>
                        </div>
                    </BCol>
                </BRow>
                <BRow class="mb-lg-3">
                    <BCol>
                        <div class="border border-2 border-dotted">
                            <DropZone class="mb-2 text-center"/>
                        </div>
                    </BCol>
                </BRow>
			</BCol>
		</BRow>
	</BCard>
</template>


<script setup lang="ts">
import { reactive, ref, computed } from 'vue'
import { required } from '@vuelidate/validators'
import { ErrorMessage, Field } from 'vee-validate'
import ClassicEditor from '@ckeditor/ckeditor5-build-classic'
import DropZone from '@/components/common/DropZone.vue'
import DTextField from "@/components/common/DTextField.vue";
import DAutocomplete from "@/components/common/DAutocomplete.vue";
import DCheckbox from "@/components/common/DCheckbox.vue";
import DDatePicker from "@/components/common/DDatePicker.vue";

const options = {
  unitOptions: [
    { name: 'Đơn vị', id: '' },
    { name: 'Chiếc', id: '2' },
    { name: 'Mét', id: '3' },
    { name: 'Bình', id: '4' },
    { name: 'Cuôn', id: '5' }
  ],
  assetTypeOptions: [
    { name: 'Bàn phím dây', id: '' },
    { name: '- Bộ phím chuột', id: '2' },
    { name: 'Chuột dây', id: '3' }
  ],
  localOptions: [
    { name: 'Hà Nội', id: '' },
    { name: 'Đà Nẵng', id: '2' },
    { name: 'Hồ Chí Minh', id: '3' }
  ],
  legalEntityOptions: [
    { name: 'Pháp nhân A', id: '' },
    { name: 'Pháp nhân B', id: '2' }
  ],
  departmentOptions: [
    { name: 'Phòng ban A', id: '' },
    { name: 'Phòng ban B', id: '2' }
  ]
}

const editor = ClassicEditor
</script>
