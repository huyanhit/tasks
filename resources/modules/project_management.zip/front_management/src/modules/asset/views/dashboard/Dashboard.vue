<template>
    <section no-body class="section-teleport">
        <DTeleport to="#teleport-header-action">
            <HeaderAction :page-title="$t('Danh sách tài sản')" />
        </DTeleport>
        <DTeleport to="#teleport-header-search">
         
        </DTeleport>
    </section>
    <BCard>
        Dashboard Asset
    </BCard>
</template>

<script setup>
import DTeleport from '@/components/common/DTeleport.vue'
import HeaderAction from '@/modules/asset/components/ActionHeader.vue'
</script>
