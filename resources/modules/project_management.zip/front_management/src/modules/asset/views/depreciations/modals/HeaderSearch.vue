<template>
    <div>
        Modal search
    </div>
</template>