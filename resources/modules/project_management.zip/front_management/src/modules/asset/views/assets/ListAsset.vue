<template>
  <section no-body class="section-teleport gap">
    <DTeleport to="#teleport-header-action">
      <HeaderAction :page-title="$t('assets.assets.title')" />
    </DTeleport>
    <DTeleport to="#teleport-header-search">
      <SearchAsset />
    </DTeleport>
  </section>

  <BRow>
    <BCol class="page_header" cols="12">
      <div class="page-title-box d-lg-flex align-items-center justify-content-between bg-galaxy-transparent">
        <DTabs v-model="activeTab" :tabs="tabs" />
        <TableActions />
      </div>
    </BCol>
  </BRow>

  <BCard no-body>
    <BCardBody class="p-0 tab-content text-muted">
      <data-table
        @open-menu="openContextMenu"
        is-show-checkbox
        v-model:selected="selected"
        v-model:params="params"
        :loading="loading"
        :data="data"
        :headers="headers"
      >
        <template v-slot:item-assetCode="{ item }">
          {{ item.assetCode }}
        </template>
        <template #item.assetName="{ item }">
          <a href='/asset/detail-asset/1'>{{ item.assetName }}</a>
        </template>
        <template v-slot:item-assetType="{ item }">
          {{ item.assetType }}
        </template>
        <template v-slot:item-purchaseDate="{ item }">
          {{ item.purchaseDate }}
        </template>
        <template v-slot:item-quantity="{ item }">
          {{ item.quantity }}
        </template>
        <template v-slot:item-inUse="{ item }">
          {{ item.inUse }}
        </template>
        <template v-slot:item-remainingQuantity="{ item }">
          {{ item.remainingQuantity }}
        </template>
        <template v-slot:item-originalPrice="{ item }">
          {{ item.originalPrice }}
        </template>
        <template v-slot:item-usage="{ item }">
          <DUsers :users="item.usage" />
        </template>
        <template v-slot:item-departmentUsed="{ item }">
          {{ item.departmentUsed }}
        </template>
      </data-table>
    </BCardBody>
  </BCard>

  <!-- modals -->
  <AllocateModal />
  <RecoverModal />
  <RemoveModal />
  <FailureModal />
  <WarrantyModal />
  <LiquidateModal />
  <ReportLostModal />
  <IncreaseModal />
  <TagsModal />
</template>

<script setup lang="ts">
import { ref, Ref, computed, h, watch } from "vue";
import { useI18n } from "vue-i18n";
import DataTable from "@/components/common/DataTable.vue";
import { AssetTypeService } from "@/modules/setting_asset/services/asset_type";
import useGetDatatable from "@/modules/setting_project/composables/use-get-datatable";
import ContextMenu from "@imengyu/vue3-context-menu";
import HeaderAction from "@/modules/asset/components/ActionHeader.vue";
import DTeleport from "@/components/common/DTeleport.vue";
import TableActions from "@/modules/asset/components/ActionTable.vue";
import { useRouter } from "vue-router";
// import modal
import AllocateModal from "@/modules/asset/views/assets/modals/AllocateModal.vue";
import RecoverModal from "@/modules/asset/views/assets/modals/RecoverModal.vue";
import RemoveModal from "@/modules/asset/views/assets/modals/RemoveModal.vue";
import FailureModal from "@/modules/asset/views/assets/modals/FailureModal.vue";
import WarrantyModal from "@/modules/asset/views/assets/modals/WarrantyModal.vue";
import LiquidateModal from "@/modules/asset/views/assets/modals/LiquidateModal.vue";
import ReportLostModal from "@/modules/asset/views/assets/modals/ReportLostModal.vue";
import IncreaseModal from "@/modules/asset/views/assets/modals/IncreaseModal.vue";
import TagsModal from "@/modules/asset/views/assets/modals/TagsModal.vue";
import SearchAsset from "@/modules/asset/components/ActionSearchAsset.vue"
const router = useRouter();
const { t } = useI18n();

const getData = async (data: any) => {
	return {
		data : {
			data: [
				{
					id: 1,
					assetCode: "TS.125",
					assetName: "Pin Sạc Panasonic BQ-CC55 (1 sạc + 4 pin)",
					assetType: "Macbook",
					purchaseDate: "01/06/2024",
					quantity: "1",
					inUse: "1",
					remainingQuantity: "0",
					originalPrice: "10,000,000",
					usage: "inUse",
					departmentUsed: "Khối kinh doanh Hà Nội",
				},
				{
					id: 2,
					assetCode: "TS.1234",
					assetName: "Máy tính",
					assetType: "Macbook",
					purchaseDate: "01/06/2024",
					quantity: "1",
					inUse: "1",
					remainingQuantity: "0",
					originalPrice: "10,000,000",
					usage: "disposed",
					departmentUsed: "Khối kinh doanh Hà Nội",
				}
			],
			pagination: {},
			summary: []
		}
	}
}

const { loading, selected, totalPages, data, fetchData, params } = useGetDatatable(getData);

const emitter = inject<any>("emitter");

const openModal = (modalKey: string) => {
  emitter.emit(`open-${modalKey}`);
};

const openContextMenu = ({ $event, item }) => {
  ContextMenu.showContextMenu({
    x: $event.x,
    y: $event.y,
    items: [
		{
			label: "Cấp phát",
			icon: h("i", { class: "ri-shopping-bag-line" }),
			onClick: () => openModal("allocate"),
		},
		{
			label: "Thu hồi",
			icon: h("i", { class: "ri-arrow-go-back-line" }),
			onClick: () => openModal("recover"),
		},
		{
			label: "Báo huỷ",
			icon: h("i", { class: "ri-close-circle-line" }),
			onClick: () => openModal("remove"),
		},
		{
			label: "Báo hỏng",
			icon: h("i", { class: "ri-information-line" }),
			onClick: () => openModal("failure"),
		},
		{
			label: "Bảo trì, sữa chữa",
			icon: h("i", { class: "ri-tools-line" }),
			onClick: () => openModal("warranty"),
		},
		{
			label: "Đã thanh lý",
			icon: h("i", { class: "ri-shopping-cart-line" }),
			onClick: () => openModal("liquidate"),
		},
		{
			label: "Báo mất",
			icon: h("i", { class: "ri-arrow-down-line" }),
			onClick: () => openModal("reportLost"),
		},
		{
			label: "Báo tăng",
			icon: h("i", { class: "ri-arrow-up-line" }),
			onClick: () => openModal("increase"),
			divided: true,
		},
		{
			label: "Nhãn",
			icon: h("i", { class: "ri-price-tag-3-line" }),
			onClick: () => openModal("tags"),
			divided: true,
		},
		{
			label: "Chi tiết",
			icon: h("i", { class: "ri-file-list-line" }),
		},
		{
			label: "Sửa",
			icon: h("i", { class: "ri-edit-line" }),
		},
		{
			label: "Xoá",
			icon: h("i", { class: "ri-delete-bin-line" }),
		},
    ],
  });
};

interface TableHeader {
	text: string;
	value: string;
	align: string;
	sortable: boolean;
	width?: string;
}

const headers = ref<Array<TableHeader>>([
  {
    text: t("assets.assets.headers.assetCode"),
    value: "assetCode",
    align: "left",
    sortable: true,
    width: "150px",
  },
  {
    text: t("assets.assets.headers.assetName"),
    value: "assetName",
    align: "left",
    sortable: false,
    width: "300px",
  },
  {
    text: t("assets.assets.headers.assetType"),
    value: "assetType",
    align: "left",
    sortable: false,
    width: "150px",
  },
  {
    text: t("assets.assets.headers.purchaseDate"),
    value: "purchaseDate",
    align: "left",
    sortable: false,
    width: "100px",
  },
  {
    text: t("assets.assets.headers.quantity"),
    value: "quantity",
    align: "center",
    sortable: true,
    width: "170px",
  },
  {
    text: t("assets.assets.headers.inUse"),
    value: "inUse",
    align: "left",
    sortable: false,
    width: "170px",
  },
  {
    text: t("assets.assets.headers.remainingQuantity"),
    value: "remainingQuantity",
    align: "left",
    sortable: false,
    width: "170px",
  },
  {
    text: t("assets.assets.headers.originalPrice"),
    value: "originalPrice",
    align: "left",
    sortable: false,
    width: "170px",
  },
  {
    text: t("assets.assets.headers.usage"),
    value: "usage",
    align: "left",
    sortable: false,
    width: "170px",
  },
  {
    text: t("assets.assets.headers.departmentUsed"),
    value: "departmentUsed",
    align: "left",
    sortable: false,
    width: "250px",
  },
]);

const activeTab = ref(0);
const tabs = [
  { id: 0, label: t("assets.assets.tabs.all"), count: 0 },
  {
    id: 1,
    label: t("assets.assets.tabs.notIssued"),
    count: 0,
  },
  {
    id: 2,
    label: t("assets.assets.tabs.inUse"),
    count: 0,
  },
  {
    id: 3,
    label: t("assets.assets.tabs.disposed"),
    count: 0,
  },
  {
    id: 4,
    label: t("assets.assets.tabs.maintenance"),
    count: 0,
  },
  {
    id: 5,
    label: t("assets.assets.tabs.lost"),
    count: 0,
  },
  {
    id: 6,
    label: t("assets.assets.tabs.damaged"),
    count: 0,
  },
];
</script>
