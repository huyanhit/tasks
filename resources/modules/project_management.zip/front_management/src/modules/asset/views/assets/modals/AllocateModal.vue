<template>
	<d-form-modal :loading="loading" v-model="isVisible" size="lg" scrollable :title="title" @submit="onSubmit">
		<BRow>
			<DTextField
				:label="'Mã CP'"
				name="ma_CP"
				forInput="ma_CP"
				required
				:placeholder="'BBBG_12'"
				class="mb-3"
				xl="6"
			/>
			<DTextField
				:label="'Tài sản'"
				name="ma_ts"
				forInput="ma_ts"
				required
				:placeholder="'Thiết bị bêp KT-02'"
				class="mb-3"
				xl="6"
			/>
		</BRow>
		<BRow class="mb-3">
			<BCol>
				<DCheckbox :showLabel="false" v-model="isChecked" :label="'Phòng ban'" name="asset_copy" required />
			</BCol>
		</BRow>
		<BRow v-if="isChecked">
			<DAutocomplete
				:label="'Phòng ban'"
				name="asset_type"
				forInput="asset_type"
				:placeholder="'Chọn phòng ban '"
				isMultiple="{false}"
				required
				class="mb-3"
				:col="12"
			/>
		</BRow>
		<BRow>
			<DTextField
				:label="'Người nhận'"
				name="ma_CP"
				forInput="ma_CP"
				required
				:placeholder="'Chọn người nhân'"
				class="mb-3"
				xl="12"
			/>
		</BRow>
		<BRow>
			<DTextField
				:label="'Người cấp phát'"
				name="ma_CP"
				forInput="ma_CP"
				required
				:placeholder="'Chọn người cấp phát'"
				class="mb-3"
				xl="12"
			/>
		</BRow>
		<BRow>
			<DTextField
				:label="'Số lượng'"
				name="ma_CP"
				forInput="ma_CP"
				required
				:placeholder="'Số lượng'"
				class="mb-3"
				xl="6"
			/>
			<DTextField
				:label="'Tồn kho'"
				name="ma_ts"
				forInput="ma_ts"
				required
				:placeholder="'Tồn kho'"
				class="mb-3"
				xl="6"
			/>
		
		</BRow>
		<BRow>
			<DDatePicker
				:label="$t('assets.assets.addAsset.information.purchaseDate')"
				name="purchase_date"
				forInput="purchase_date"
				required
				:placeholder="$t('assets.assets.addAsset.information.purchaseDatePlaceholder')"
				icon="ri-calendar-line"
				class="mb-3"
				:col="6"
			/>
			<DDatePicker
				:label="$t('assets.assets.addAsset.information.purchaseDate')"
				name="purchase_date"
				forInput="purchase_date"
				required
				:placeholder="$t('assets.assets.addAsset.information.purchaseDatePlaceholder')"
				icon="ri-calendar-line"
				class="mb-3"
				:col="6"
			/>
		</BRow>
		<BRow>
			<DAutocomplete
				:label="'Vị trí tài sản'"
				name="asset_type"
				forInput="asset_type"
				:placeholder="'Chọn vị trí '"
				isMultiple="{false}"
				required
				class="mb-3"
				:col="12"
			/>
		</BRow>
		<BRow>
			<DTextField
				:label="'Địa điểm bàn giao'"
				name="ma_CP"
				forInput="ma_CP"
				required
				:placeholder="'Nhập địa điểm'"
				class="mb-3"
				xl="12"
			/>
		</BRow>
		<BRow>
			<DTextField
				:label="'Đặt cọc'"
				name="ma_CP"
				forInput="ma_CP"
				required
				:placeholder="'Nhận đặt cọc'"
				class="mb-3"
				xl="12"
			/>
		</BRow>
		<BRow>
			<DDatePicker
				:label="'Nhập dự kiến ngày trả'"
				name="purchase_date"
				forInput="purchase_date"
				required
				:placeholder="'Nhập dự kiến ngày trả'"
				icon="ri-calendar-line"
				class="mb-3"
				:col="12"
			/>
		</BRow>
		<DTextArea
			:label="'Lý do cấp phát'"
			name="ma_CP"
			forInput="ma_CP"
			required
			:placeholder="''"
		/>
	</d-form-modal>
</template>

<script setup lang="ts">
import { ref, inject, onMounted, onUnmounted, defineExpose } from 'vue';
import DFormModal from "@/components/common/DFormModal.vue";
import DTextField from "@/components/common/DTextField.vue";
import DCheckbox from "@/components/common/DCheckbox.vue";
import DDatePicker from "@/components/common/DDatePicker.vue";
import DAutocomplete from "@/components/common/DAutocomplete.vue";

const isVisible = ref(false);
const title = 'Cấp phát tài sản';
const loading = ref(false);
const isChecked = ref(false);

const open = () => {
	isVisible.value = true;
};

const emitter = inject<any>('emitter');

if (emitter) {
	const handleOpen = () => open();
	
	onMounted(() => {
		emitter.on('open-allocate', handleOpen);
	});
	
	onUnmounted(() => {
		emitter.off('open-allocate', handleOpen);
	});
}

defineExpose({ open });
</script>
