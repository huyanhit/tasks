<template>
	<BCard>
		<BRow class="mt-1">
			<p>Đối tượng liên quan</p>
		</BRow>
	</BCard>
</template>