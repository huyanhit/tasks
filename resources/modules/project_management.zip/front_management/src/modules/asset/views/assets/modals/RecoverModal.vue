<template>
	<d-form-modal :loading="loading" v-model="isVisible" size="lg" scrollable :title="title" @submit="onSubmit">
		Tài sản này chưa có cấp phát nào hoặc đã thu hồi hết!
	</d-form-modal>
</template>

<script setup lang="ts">
import { ref, inject, onMounted, onUnmounted, defineExpose } from 'vue';
import DFormModal from "@/components/common/DFormModal.vue";

const isVisible = ref(false);
const title = 'Thu hồi';
const loading = ref(false);

const open = () => {
	isVisible.value = true;
};

const emitter = inject<any>('emitter');

if (emitter) {
	const handleOpen = () => open();
	
	onMounted(() => {
		emitter.on('open-recover', handleOpen);
	});
	
	onUnmounted(() => {
		emitter.off('open-recover', handleOpen);
	});
}

defineExpose({ open });
</script>
