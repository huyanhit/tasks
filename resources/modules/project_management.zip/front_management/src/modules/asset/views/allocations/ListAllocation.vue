<template>
  <section no-body class="section-teleport gap">
    <DTeleport to="#teleport-header-action">
      <HeaderAction :page-title="$t('Danh sách cấp phát - 103')" />
    </DTeleport>
    <DTeleport to="#teleport-header-search">
      <SearchAllocation />
    </DTeleport>
  </section>

  <BRow>
    <BCol class="page_header" cols="12">
      <div class="page-title-box d-lg-flex align-items-center justify-content-between bg-galaxy-transparent">
        <DTabs v-model="activeTab" :tabs="tabs" />
        <ActionTableAllocation />
      </div>
    </BCol>
  </BRow>

  <BCard no-body>
    <BCardBody class="p-0 tab-content text-muted">
      <data-table
        @open-menu="openContextMenu"
        is-show-checkbox
        v-model:selected="selected"
        v-model:params="params"
        :loading="loading"
        :data="data"
        :headers="headers"
      >
        <template v-slot:item-assetCode="{ item }">
          {{ item.assetCode }}
        </template>
        <template #item.assetName="{ item }">
          <a href="#">{{ item.assetName }}</a>
        </template>
        <template v-slot:item-assetType="{ item }">
          {{ item.assetType }}
        </template>
        <template v-slot:item-purchaseDate="{ item }">
          {{ item.purchaseDate }}
        </template>
        <template v-slot:item-quantity="{ item }">
          {{ item.quantity }}
        </template>
        <template v-slot:item-inUse="{ item }">
          {{ item.inUse }}
        </template>
        <template v-slot:item-remainingQuantity="{ item }">
          {{ item.remainingQuantity }}
        </template>
        <template v-slot:item-originalPrice="{ item }">
          {{ item.originalPrice }}
        </template>
        <template v-slot:item-usage="{ item }">
          <DUsers :users="item.usage" />
        </template>
        <template v-slot:item-departmentUsed="{ item }">
          {{ item.departmentUsed }}
        </template>
      </data-table>
    </BCardBody>
  </BCard>
</template>

<script setup lang="ts">
import { ref, Ref, computed, h, watch } from "vue";
import { useI18n } from "vue-i18n";
import DataTable from "@/components/common/DataTable.vue";
import { AssetTypeService } from "@/modules/setting_asset/services/asset_type";
import useGetDatatable from "@/modules/setting_project/composables/use-get-datatable";
import ContextMenu from "@imengyu/vue3-context-menu";
import HeaderAction from "@/modules/asset/components/ActionHeader.vue";
import DTeleport from "@/components/common/DTeleport.vue";
import ActionTableAllocation from "@/modules/asset/components/ActionTableAllocation.vue";
import { useRouter } from "vue-router";
import SearchAllocation from "@/modules/asset/components/ActionSearchAllocation.vue"

const router = useRouter();

const { t } = useI18n();

const getData = async (data: any) => {
  return {
    data : {
      data: [
      {
        id: 1,
        assetCode: "TS.1234",
        assetName: "Máy tính",
        assetType: "Macbook",
        purchaseDate: "01/06/2024",
        quantity: "1",
        date: "01/06/2024",
        remainingQuantity: "MP Vietnam",
      },
      {
        id: 2,
        assetCode: "TS.1234",
        assetName: "Máy tính",
        assetType: "Macbook",
        purchaseDate: "01/06/2024",
        quantity: "1",
        date: "01/06/2024",
        remainingQuantity: "MP Vietnam",
      }
      ],
      pagination: {},
      summary: []
    }
  }
}

const { loading, selected, totalPages, data, fetchData, params } = useGetDatatable(getData);

const openContextMenu = ({ $event, item }) => {
  ContextMenu.showContextMenu({
    x: $event.x,
    y: $event.y,
    items: [
      {
        label: "Chi tiết",
        icon: h("i", { class: "ri-file-list-line" }),
      },
      {
        label: "Sửa",
        icon: h("i", { class: "ri-edit-line" }),
      },
      {
        label: "Xoá",
        icon: h("i", { class: "ri-delete-bin-line" }),
      },
    ],
  });
};

interface TableHeader {
  text: string;
  value: string;
  align: string;
  sortable: boolean;
  width?: string;
}

const headers = ref<Array<TableHeader>>([
  {
    text: t("Tên cấp phát"),
    value: "assetCode",
    align: "left",
    sortable: true,
    width: "150px",
  },
  {
    text: t("Mã cấp phát"),
    value: "assetName",
    align: "left",
    sortable: false,
    width: "300px",
  },
  {
    text: t("Người nhận"),
    value: "assetType",
    align: "left",
    sortable: false,
    width: "150px",
  },
  {
    text: t("Ngày cấp"),
    value: "purchaseDate",
    align: "left",
    sortable: false,
    width: "100px",
  },
  {
    text: t("assets.assets.headers.quantity"),
    value: "quantity",
    align: "center",
    sortable: true,
    width: "170px",
  },
  {
    text: t("Ngày tạo"),
    value: "inUse",
    align: "left",
    sortable: false,
    width: "170px",
  },
  {
    text: t("Người tạo"),
    value: "remainingQuantity",
    align: "left",
    sortable: false,
    width: "170px",
  }
]);

const activeTab = ref(0);
const tabs = [
  { id: 0, label: t("assets.assets.tabs.all"),  count: 0 },
  {
    id: 1,
    label: t("Đang cấp phát"),
    count: 0,
  },
  {
    id: 2,
    label: t("Đang thu hồi"),
    count: 0,
  },
  {
    id: 3,
    label: t("Đã thu hồi xong"),
    count: 0,
  },
  {
    id: 4,
    label: t("Điều chuyển"),
    count: 0,
  }
];
</script>
