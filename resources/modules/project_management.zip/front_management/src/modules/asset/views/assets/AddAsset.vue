<template>
	<section no-body class="section-teleport gap">
		<DTeleport to="#teleport-header-action">
			<HeaderAction :page-title="$t('Thêm tài sản')" />
		</DTeleport>
		<DTeleport to="#teleport-header-search">
			<ActionSearchAsset />
		</DTeleport>
	</section>
	<BRow>
        <BCol class="page_header" cols="12">
            <div class="page-title-box d-sm-flex align-items-center justify-content-between bg-galaxy-transparent py-0">
                <div id="breadCrumb" class="d-flex align-items-center justify-content-between breadcrumb">
                    <DTabs :tabs="tabs" v-model:activeTab="activeTab" @update:modelValue="activeTab = $event" />
                </div>
            </div>
			<div class="tab">
				<component :is="currentTabComponent" />
			</div>
			<DFooterAction>
				<div class="d-flex gap-2">
					<SubmitButton/>
					<CancelButton/>
				</div>
			</DFooterAction>
        </BCol>
    </BRow>
</template>


<script setup lang="ts">
import { reactive, ref, computed } from 'vue'
import { required } from '@vuelidate/validators'
import { ErrorMessage, Field } from 'vee-validate'
import HeaderAction from "@/modules/asset/components/ActionHeader.vue";
import DTeleport from "@/components/common/DTeleport.vue";
import ActionSearchAsset from "@/modules/asset/components/ActionSearchAsset.vue";
import CancelButton from "@/components/common/button/CancelButton.vue";
import SubmitButton from "@/components/common/button/SubmitButton.vue";
import Info from "@/modules/asset/views/assets/tabs/Info.vue"
import RelatedObject from "@/modules/asset/views/assets/tabs/RelatedObject.vue"

const tabs = [
	{ label: 'Thông tin chung', content: Info },
	{ label: 'Đối tượng liên quan', content: RelatedObject }
]
const activeTab = ref(0)
const currentTabComponent = computed(() => {
	return tabs[activeTab.value].content
})
</script>
