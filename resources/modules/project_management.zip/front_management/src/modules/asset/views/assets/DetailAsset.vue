<template>
  <section no-body class="section-teleport gap">
    <DTeleport to="#teleport-header-action">
      <HeaderAction :page-title="$t('Thông tin tài sản')" />
    </DTeleport>
    <DTeleport to="#teleport-header-search">
     <Search />
    </DTeleport>
  </section>
  <BRow>
    <BCol class="page_header" cols="12">
      <div
        class="page-title-box d-lg-flex align-items-center justify-content-between bg-galaxy-transparent"
      >
        <DTabs
          v-model="activeTab"
          :tabs="tabsWithCountHeader"
          @change="filterDataByTab"
        />
        <ToolbarDetail />
      </div>
    </BCol>
    <!-- Left Column with General Information -->
    <BCol xl="8">
      <DAccordion :header="'Thông tin chung'">
        <BCardBody class="p-md-3">
          <BRow>
            <!-- First Column of Information -->
            <BCol xl="6">
              <BRow class="mb-3 d-flex flex-column">
                <BCol class="fw-semibold text-black">Mã TS</BCol>
                <BCol>TS.125</BCol>
              </BRow>
              <BRow class="mb-3 d-flex flex-column">
                <BCol class="fw-semibold text-black">Model / Series</BCol>
                <BCol>a102</BCol>
              </BRow>
              <BRow class="mb-3 d-flex flex-column">
                <BCol class="fw-semibold text-black">Loại tài sản</BCol>
                <BCol>Macbook</BCol>
              </BRow>
              <BRow class="mb-3 d-flex flex-column">
                <BCol class="fw-semibold text-black">Ngày kết thúc BH</BCol>
                <BCol>05/08/2025</BCol>
              </BRow>
              <BRow class="mb-3 d-flex flex-column">
                <BCol class="fw-semibold text-black">Khấu hao (tháng)</BCol>
                <BCol>12 Tháng</BCol>
              </BRow>
              <BRow class="mb-3 d-flex flex-column">
                <BCol class="fw-semibold text-black">Pháp nhân sở hữu</BCol>
                <BCol>--</BCol>
              </BRow>
              <BRow class="mb-3 d-flex flex-column">
                <BCol class="fw-semibold text-black">Vị trí tài sản</BCol>
                <BCol>--</BCol>
              </BRow>
              <BRow class="mb-3 d-flex flex-column">
                <BCol class="fw-semibold text-black">Phòng ban sử dụng</BCol>
                <BCol>--</BCol>
              </BRow>
              <BRow class="mb-3 d-flex flex-column">
                <BCol class="fw-semibold text-black">Địa chỉ</BCol>
                <BCol>--</BCol>
              </BRow>
              <BRow class="mb-3 d-flex flex-column">
                <BCol class="fw-semibold text-black">Mô tả</BCol>
                <BCol>--</BCol>
              </BRow>
            </BCol>
            <!-- Second Column of Information -->
            <BCol xl="6">
              <BRow class="mb-3 d-flex flex-column">
                <BCol class="fw-semibold text-black">Tên tài sản</BCol>
                <BCol>laptop</BCol>
              </BRow>
              <BRow class="mb-3 d-flex flex-column">
                <BCol class="fw-semibold text-black">Đơn vị</BCol>
                <BCol>Chiếc</BCol>
              </BRow>
              <BRow class="mb-3 d-flex flex-column">
                <BCol class="fw-semibold text-black">Ngày mua</BCol>
                <BCol>05/08/2024</BCol>
              </BRow>
              <BRow class="mb-3 d-flex flex-column">
                <BCol class="fw-semibold text-black">Thời gian BH (tháng)</BCol>
                <BCol>12 Tháng</BCol>
              </BRow>
              <BRow class="mb-3 d-flex flex-column">
                <BCol class="fw-semibold text-black">Nhà cung cấp</BCol>
                <BCol>oppo</BCol>
              </BRow>
              <BRow class="mb-3 d-flex flex-column">
                <BCol class="fw-semibold text-black">Phòng ban quản lý</BCol>
                <BCol>Cửa hàng trưởng</BCol>
              </BRow>
              <BRow class="mb-3 d-flex flex-column">
                <BCol class="fw-semibold text-black">Trạng thái</BCol>
                <BCol>Chờ cấp phát</BCol>
              </BRow>
              <BRow class="mb-3 d-flex flex-column">
                <BCol class="fw-semibold text-black">Ngày báo tăng</BCol>
                <BCol>05/08/2024</BCol>
              </BRow>
              <BRow class="mb-3 d-flex flex-column">
                <BCol class="fw-semibold text-black">Điện thoại</BCol>
                <BCol>--</BCol>
              </BRow>
            </BCol>
          </BRow>
        </BCardBody>
      </DAccordion>
      <!-- Issuance and Withdrawal Section -->
      <DAccordion :header="'Cấp phát thu hồi'">
        <div class="p-2">
          <span>Không tìm thấy kết quả nào</span>
        </div>
      </DAccordion>
      <!-- Asset History Section -->
      <DAccordion :header="'Lịch sử tài sản'">
        <DataTable
          :headers="headers"
          :data="data"
          :totalPages="totalPages"
          :loading="loading"
          hidePagination="false"
        />
      </DAccordion>
    </BCol>

    <!-- Right Column with Asset Image -->
    <BCol xl="4">
      <DAccordion :header="'Ảnh tài sản'">
        <BCardImg class="p-2" v-bind:src="productImage" />
      </DAccordion>
      <DAccordion>
        <template #tabs>
          <DTabs :tabs="tabsWithCount" @change="filterDataByTab" />
        </template>
        <template #body-accordion>
          <div v-if="tabsWithCount[0].label === 'Thảo luận' && !hasDiscussions">
            <div class="d-flex align-items-center justify-content-center py-3" >
              <img :src="noDiscussionImage" alt="No discussions" class="me-2" />
              <span>Không có thảo luận nào</span>
            </div>
          </div>
          <!-- Add other content for body-accordion here -->
        </template>
      </DAccordion>
    </BCol>
  </BRow>
</template>
<script setup lang="ts">
import DAccordion from "@/components/common/DAccordion.vue";
import productImage from "@/assets/images/product.png";
import { ref } from "vue";
import HeaderAction from "@/modules/asset/components/ActionHeader.vue";
import DTeleport from "@/components/common/DTeleport.vue";
import TableHeader from "@/modules/setting_project/models/table";
import noDiscussionImage from "@/assets/images/chat.svg";
import Search from "@/modules/asset/components/ActionSearchAsset.vue"
import ToolbarDetail from "../../components/ActionTableDetail.vue";

const tabsWithCountHeader = [{ label: "Thông tin chung" }];
const tabsWithCount = [{ label: "Thảo luận" }, { label: "Lịch sử hoạt động" }];

// Dữ liệu mẫu cho DataTable
const data = ref<DataRow[]>([
  {
    id: 1,
    date: "01/08/2024",
    department: "HR",
    remarks: "Thu hồi từ nhân viên B",
    quantity_start: 20,
    quantity_end: 20,
    amount: 2000,
    description: "Ghi chú chi tiết",
  },
  {
    id: 2,
    date: "15/08/2024",
    department: "HR",
    remarks: "Thu hồi từ nhân viên B",
    quantity_start: 20,
    quantity_end: 20,
    amount: 2000,
    description: "Ghi chú chi tiết",
  },
]);

const headers = ref<TableHeader[]>([
  {
    value: "date",
    text: "Ngày",
    sortable: true,
    align: "center",
  },
  {
    value: "department",
    text: "Tác vụ",
    sortable: false,
    align: "left",
  },
  {
    value: "remarks",
    text: "Tồn đầu kỳ",
    sortable: false,
    align: "left",
  },
  {
    value: "quantity_start",
    text: "Số lượng",
    sortable: false,
    align: "left",
  },
  {
    value: "quantity_end",
    text: "Tồn cuối kỳ",
    sortable: false,
    align: "left",
  },
  {
    value: "amount",
    text: "Số tiền",
    sortable: false,
    align: "left",
  },
  {
    value: "description",
    text: "Mô tả",
    sortable: false,
    align: "left",
  },
]);

const totalPages = ref(1);
const loading = ref(false);
</script>

<style scoped></style>
