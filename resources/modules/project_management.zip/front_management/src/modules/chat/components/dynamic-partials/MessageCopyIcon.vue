<template>
    <span class="code-copy-icon">
       copy
    </span>
</template>