export const groupMenuProject = [
	{
		title: 'menu.group_menu.group_project.dashboard.title',
		icon: 'ri-home-5-line', 
		url: '/work-project-project/dashboard'
  	},
	{
		title: 'menu.group_menu.group_project.task.title',
		icon: 'ri-list-check-3',
		role: 'sidebarTask',
		children: [
			{ title: 'menu.group_menu.group_project.task.child.my_implement', url: '/work-project-project' },
			{ title: 'menu.group_menu.group_project.task.child.my_admin', url: '/work-project-project' },
			{ title: 'menu.group_menu.group_project.task.child.my_follow', url: '/work-project-project' },
			{ title: 'menu.group_menu.group_project.task.child.my_department', url: '/work-project-project' },
			{ title: 'menu.group_menu.group_project.task.child.all', url: '/work-project-project' }
		]
  	},
	{
		title: 'menu.group_menu.group_project.project.title',
		icon: 'ri-collage-line',
		role: 'sidebarProject',
		children: [
            { title: 'menu.group_menu.group_project.project.child.my_implement', url: '/work-project-project?menu=implementer' },
            { title: 'menu.group_menu.group_project.project.child.my_admin', url: '/work-project-project?menu=manager' },
            { title: 'menu.group_menu.group_project.project.child.my_follow', url: '/work-project-project?menu=follower' },
            { title: 'menu.group_menu.group_project.project.child.my_department', url: '/work-project-project?menu=deparment' },
            { title: 'menu.group_menu.group_project.project.child.all', url: '/work-project-project?menu=all' }
		]
  	},
	{
		title: 'menu.group_menu.group_project.sequential.title',
		icon: 'ri-swap-3-line',
		role: 'sidebarWorkflow',
		children: [
            { title: 'menu.group_menu.group_project.project.child.my_implement', url: '/work-project-project?menu=implementer' },
            { title: 'menu.group_menu.group_project.project.child.my_admin', url: '/work-project-project?menu=manager' },
            { title: 'menu.group_menu.group_project.project.child.my_follow', url: '/work-project-project?menu=follower' },
            { title: 'menu.group_menu.group_project.project.child.my_department', url: '/work-project-project?menu=deparment' },
            { title: 'menu.group_menu.group_project.project.child.all', url: '/work-project-project?menu=all' }
		]
  	},
	{
		title: 'menu.group_menu.group_project.recurring',
		icon: 'ri-repeat-line',
		url: '/work-project-project/report'
  	},
	{
		title: 'menu.group_menu.group_project.report',
		icon: 'ri-pie-chart-line',
		url: '/work-project-project/report'
  	},
	{
		title: 'menu.group_menu.group_project.warning',
		icon: 'ri-error-warning-line', 
		url: '/work-project-project/warning'
  	},
	{
		title: 'menu.group_menu.group_project.setting',
		icon: 'ri-settings-5-line',
		url: '/setting-work'
  	}
]
