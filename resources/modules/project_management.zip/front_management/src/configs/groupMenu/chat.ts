export const groupMenuChat = [
    { title: 'menu.group_menu.group_chat.title', url: '/chat', icon: 'ri-chat-2-line' },
]
