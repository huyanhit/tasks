import { groupMenuSample } from './sample';
import { groupMenuDashboard } from './dashboard';
import { groupMenuProject } from './project';
import { groupMenuSettingWork } from './setting_work';
import { groupMenuSettingAdmin } from './setting_admin'
import { groupMenuEmployee } from './employee';
import { groupMenuSettingEmployee } from './setting_employee';
import { groupMenuSettingSystem } from './setting_system';
import { groupMenuChat } from './chat';
import { groupMenuDocument } from './document';
import { groupMenuSettingDocument } from './setting_document';
import { groupMenuSettingAsset } from './setting_asset';
import { groupMenuAsset } from './asset';

export function getGroupMenu() {
    return {
        pagination: groupMenuSample,
        dashboard: groupMenuDashboard,
        project: groupMenuProject,
        setting_work: groupMenuSettingWork,
        employee: groupMenuEmployee,
        setting_admin: groupMenuSettingAdmin,
        setting_employee: groupMenuSettingEmployee,
        setting_system: groupMenuSettingSystem,
        document: groupMenuDocument,
        setting_document: groupMenuSettingDocument,
        setting_asset: groupMenuSettingAsset,
        asset: groupMenuAsset,
        chat: groupMenuChat,
        task: groupMenuProject,
    };
}

export function getGroupMenuByModule(role: string) {
    const groupMenu = getGroupMenu();
    return groupMenu[role];
}

export const groupMenu = ref([])