export const groupMenuSettingWork = [
	{
		title: 'menu.group_menu.setting_project.general_settings',
		icon: 'ri-settings-4-line',
		role: 'sidebarSettingGeneral',
		children: [
			{ title: 'menu.group_menu.setting_project.working_hours', url: '/setting-work/worktime' },
			{ title: 'menu.group_menu.setting_project.type_of_task', url: '/setting-work/task-types' },
			{ title: 'menu.group_menu.setting_project.task_unit', url: '/setting-work/task-units' },
			{ title: 'menu.group_menu.setting_project.project_group', url: '/setting-work/group-project' },
			{ title: 'Nhóm quy trình', url: '/setting-work/group-workflow' },
			{ title: 'menu.group_menu.setting_project.work_tags_setting', url: '/setting-work/work-tags' }
		]
  	},
	{
		title: 'menu.group_menu.setting_project.object_settings',
		icon: 'ri-settings-4-line',
		role: 'sidebarSettingObject',
		children: [
			{ title: 'menu.group_menu.setting_project.task_settings', url: '/setting-work/work-normal' },
			{ title: 'menu.group_menu.setting_project.work_process_settings', url: '/setting-work/work-process' },
			{ title: 'menu.group_menu.setting_project.project_settings', url: '/setting-work/work-project' },
			{ title: 'menu.group_menu.setting_project.timesheet_settings', url: '/setting-work/work-timesheet' },
		]
  	}
]
