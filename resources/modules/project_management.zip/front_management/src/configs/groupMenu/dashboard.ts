export const groupMenuDashboard = [
	{
		title: 'menu.group_menu.dashboard.title',
		icon: 'ri-home-line',
		url: '/dashboard-board',
  	},
	{
		title: 'Thông báo',
		icon: 'ri-notification-2-line',
		url: '/dashboard-notify',
  	},
    {
		title: 'Tài khoản',
		icon: 'ri-user-line',
		url: '/dashboard-account',
  	}
]
