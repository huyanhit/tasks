export const groupMenuSettingAdmin = [
    {
      title: 'Cài đặt chung',
      icon: 'ri-settings-4-line',
      role: 'sidebarSettingGeneral',
      children: [
        { title: 'Cài đặt hệ thống', url: '/settings/admin-settings-app_settings' },
      ]
    },
    {
      title: 'Danh mục',
      icon: 'ri-settings-4-line',
      role: 'sidebarSettingGeneral',
      children: [
        { title: 'Tích hợp ký số', url: '/settings/app-settings-integration_digitalsignature' },
      ]
    },
  ]
  