export const groupMenuDocument = [
	{
		title: 'menu.group_menu.group_document.company.title',
		icon: 'ri-folder-4-line', 
		role: 'sidebarDocumentCompany',
		children: [
			{ title: 'menu.group_menu.group_document.company.child.all', url: '/document' },
			{ title: 'menu.group_menu.group_document.company.child.managing', url: '/document/company/manager' }
		]
  	},
	{
		title: 'menu.group_menu.group_document.personal',
		icon: 'ri-folder-user-fill',
		url: '/document/personal'
  	},
	{
		title: 'menu.group_menu.group_document.attachment',
		icon: 'ri-attachment-2',
		url: '/document/attachment'
  	},
	{
		title: 'Cài đặt',
		icon: 'ri-settings-4-line',
		url: '/setting-document/document-tags'
  	},
]
