export const groupMenuSample = [
    {
        title: 'Sample',
        icon: 'ph:eyedropper-sample-fill',
        role: 'sidebarPagination',
        children: [
            { title: 'Phân trang', url: '/sample/pagination' },
            { title: 'Action Button', url: '/sample/action-button' }
        ]
    }
];
