export const groupMenuSettingSystem = [
	{
		title: 'Tài khoản',
		icon: 'ri-user-settings-fill',
		role: 'sidebarAccount',
		children: [
			{ title: 'Người dùng', url: '/settings/accounts' },
			{ title: 'Nhóm người dùng', url: '/settings/group-account' }
		]
  	},
	{
		title: 'Phòng ban',
		icon: 'ri-community-line',
		role: 'sidebarDepartment',
		children: [
			{ title: 'Phòng ban, chi nhánh', url: '/settings/departments' },
			{ title: 'Loại phòng ban', url: '/settings/department-type' },
			{ title: 'Khối nghiệp vụ', url: '/settings/department-business' }
		]
  	}
]
