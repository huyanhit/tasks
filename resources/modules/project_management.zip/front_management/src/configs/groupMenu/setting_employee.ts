export const groupMenuSettingEmployee = [
  {
    title: 'menu.group_menu.setting_employee.general_settings',
    icon: 'ri-settings-4-line',
    role: 'sidebarSettingGeneral',
    children: [
      { title: 'menu.group_menu.setting_employee.job_position', url: '/setting-personnel/job-position' },
      { title: 'menu.group_menu.setting_employee.job_title', url: '/setting-personnel/job-title' },
      { title: 'menu.group_menu.setting_employee.work_location', url: '/setting-personnel/work-location' },
      { title: 'menu.group_menu.setting_employee.company_rules', url: '/setting-personnel/company-rules' },
      { title: 'menu.group_menu.setting_employee.welfares', url: '/setting-personnel/welfares' },
      { title: 'menu.group_menu.setting_employee.careerpath', url: '/setting-personnel/careerpath' },
      { title: 'menu.group_menu.setting_employee.tag_settings', url: '/setting-personnel/personnel-tags' },
      { title: 'menu.group_menu.setting_employee.approval_process', url: '/setting-personnel/approval-process' },
    ]
  },
  // {
  //   title: 'menu.group_menu.setting_employee.general_settings',
  //   groupTitle: true,
  // },
  {
    title: 'menu.group_menu.setting_employee.personnel_record',
    icon: 'ri-settings-4-line',
    role: 'sidebarSettingObjectEmployee',
    children: [
      { title: 'menu.group_menu.setting_employee.general_settings', url: '/setting-personnel/general-personnel' },
      {
        title: 'menu.group_menu.setting_employee.certificate_type',
        url: '/setting-personnel/certificates'
      },
      { title: 'menu.group_menu.setting_employee.labor_type', url: '/setting-personnel/labors' },
      { title: 'menu.group_menu.setting_employee.job_history', url: '/setting-personnel/job-history' },
      { title: 'menu.group_menu.setting_employee.application_recieving', url: '/setting-personnel/receives' },
      { title: 'menu.group_menu.setting_employee.resignation_procedure', url: '/setting-personnel/jobouts' }
    ]
  },
  {
    title: 'menu.group_menu.setting_employee.contract',
    icon: 'ri-settings-4-line',
    role: 'sidebarSettingObjectContract',
    children: [
      { title: 'menu.group_menu.setting_employee.general_settings', url: '/setting-personnel/general-contract' },
      { title: 'menu.group_menu.setting_employee.labor_contract_type', url: '/setting-personnel/contract-types' },
      { title: 'menu.group_menu.setting_employee.allowances_type', url: '/setting-personnel/contract-allowances' }
    ]
  },
  {
    title: 'menu.group_menu.setting_employee.insurance',
    icon: 'ri-settings-4-line',
    role: 'sidebarSettingObjectInsurance',
    children: [
      { title: 'menu.group_menu.setting_employee.general_settings', url: '/setting-personnel/general-insurance' },
      { title: 'menu.group_menu.setting_employee.insurance_rate_setting', url: '/setting-personnel/insurance-rate' }
    ]
  }
  ,{
    title: 'Quyết định (pending)',
    icon: 'ri-settings-4-line',
    role: 'sidebarSettingObjectDecision',
    children: [
      { title: 'Hình thức khen thưởng', url: '/setting-personnel/decisions?type=abc' },
      { title: 'Hình thức kỷ luật', url: '/setting-personnel/decisions?type=abc' },
      { title: 'Lý do điều chuyển', url: '/setting-personnel/decisions?type=abc' },
      { title: 'Lý do tiếp nhận', url: '/setting-personnel/decisions?type=abc' },
      { title: 'Lý do bổ nhiệm', url: '/setting-personnel/decisions?type=abc' },
      { title: 'Lý do miễn nhiệm', url: '/setting-personnel/decisions?type=abc' },
      { title: 'Lý do chấm dứt HĐLĐ', url: '/setting-personnel/decisions?type=abc' }
    ]
  }
]
