export const groupMenuSettingAsset = [
	{
		title: 'menu.group_menu.setting_asset.general_settings',
		icon: 'ri-settings-4-line',
		role: 'sidebarSettingGeneral',
		children: [
			{ title: 'menu.group_menu.setting_asset.asset_group', url: '/setting-asset/asset-types' },
			{ title: 'menu.group_menu.setting_asset.asset_location', url: '/setting-asset/asset-positions' },
			{ title: 'menu.group_menu.setting_asset.asset_supplier', url: '/setting-asset/asset-suppliers' },
			{ title: 'menu.group_menu.setting_asset.asset_tag', url: '/setting-asset/asset-tags' },
		]
  	},
	{
		title: 'menu.group_menu.setting_asset.object_settings',
		icon: 'ri-settings-4-line',
		role: 'sidebarSettingGeneral',
		children: [
			{ title: 'menu.group_menu.setting_asset.asset', url: '/setting-asset/object-asset' },
			{ title: 'menu.group_menu.setting_asset.allocation', url: '/setting-asset/object-asset-allocation' },
			{ title: 'menu.group_menu.setting_asset.recovery', url: '/setting-asset/object-asset-recovery' },
		]
  	}
]
