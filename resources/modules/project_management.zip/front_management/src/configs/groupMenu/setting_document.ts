export const groupMenuSettingDocument = [
	{
		title: 'menu.group_menu.setting_document.general_settings.title',
		icon: 'ri-settings-4-line', 
		role: 'sidebarSettingDocumentGeneral',
		children: [
			{
				title: 'menu.group_menu.setting_document.general_settings.child.tag_settings',
				url: '/setting-document/document-tags'
			  }
			]
	},
]
