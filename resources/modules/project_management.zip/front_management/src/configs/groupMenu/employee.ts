export const groupMenuEmployee = [
	{
		title: 'menu.group_menu.group_employee.dashboard',
		icon: 'ri-home-5-line', 
		role: 'sidebarEmployeeDashboard',
		url: '/employee/dashboard'
  	},
	{
		title: 'menu.group_menu.group_employee.profile.title',
		icon: 'ri-profile-line',
		role: 'sidebarEmployee',
		children: [
			{ title: 'menu.group_menu.group_employee.profile.child.all', url: '/employee/list-profile' },
			{ title: 'menu.group_menu.group_employee.profile.child.working', url: '/employee/list-profile' },
			{ title: 'menu.group_menu.group_employee.profile.child.temporary_leave', url: '/employee/list-profile' },
			{ title: 'menu.group_menu.group_employee.profile.child.update_info', url: '/employee/list-profile' },
			{ title: 'menu.group_menu.group_employee.profile.child.resignation', url: '/employee/list-profile' }
		]
  	},
	{
		title: 'menu.group_menu.group_employee.contract.title',
		icon: 'ri-contract-line',
		role: 'sidebarEmployeeContract',
		children: [
			{ title: 'menu.group_menu.group_employee.contract.child.contract_type', url: '/employee/list-contract' },
			{ title: 'menu.group_menu.group_employee.contract.child.status', url: '/employee/list-contract' },
			{ title: 'menu.group_menu.group_employee.contract.child.digital_signature_contract', url: '/employee/list-contract' }
		]
  	},
	{
		title: 'menu.group_menu.group_employee.insurance.title',
		icon: 'ri-dossier-line',
		role: 'sidebarEmployeeInsurance',
		children: [
			{ title: 'menu.group_menu.group_employee.insurance.child.all', url: '/employee/list-insurance' },
			{ title: 'menu.group_menu.group_employee.insurance.child.estimated_increases', url: '/employee/list-insurance' },
			{ title: 'menu.group_menu.group_employee.insurance.child.estimated_decreases', url: '/employee/list-insurance' },
			{ title: 'menu.group_menu.group_employee.insurance.child.payment_history', url: '/employee/list-insurance' }
		]
  	},
	{
		title: 'menu.group_menu.group_employee.decision',
		icon: 'ri-gift-line',
		url: '/employee/list-decision',
  	},
	{
		title: 'menu.group_menu.group_employee.report',
		icon: 'ri-pie-chart-line',
		url: '/employee/report'
  	},
	{
		title: 'menu.group_menu.group_employee.warning',
		icon: 'ri-error-warning-line', 
		url: '/employee/warning'
  	},
	{
		title: 'menu.group_menu.group_employee.setting',
		icon: 'ri-settings-5-line',
		url: '/setting-personnel'
  	}
]
