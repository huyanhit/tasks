export const groupMenuAsset = [
	{
		title: 'menu.group_menu.group_asset.dashboard',
		icon: 'ri-home-5-line', 
		url: '/asset/dashboard',
  	},
	{
		title: 'menu.group_menu.group_asset.asset',
		icon: 'ri-tv-2-line',
		url: '/asset',
  	},
	{
		title: 'menu.group_menu.group_asset.allocate',
		icon: 'ri-briefcase-line',
		url: '/asset/allocation'
  	},
	{
		title: 'menu.group_menu.group_asset.recover',
		icon: 'ri-arrow-go-back-line', 
		url: '/asset/recovery'
  	},
	{
		title: 'menu.group_menu.group_asset.depreciation',
		icon: 'ri-file-reduce-line', 
		url: '/asset/depreciation'
  	},
	{
		title: 'Cài đặt',
		icon: 'ri-settings-4-line',
		url: '/setting-asset'
  	}
]
