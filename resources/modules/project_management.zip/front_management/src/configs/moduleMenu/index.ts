const MENUCOLOR = {
    BLUE: '32, 175, 255',
    PURPLE: '110,98,225',
    GREEN: '21, 200, 114',
    YELLOW: '251, 175, 26',
    RED: '224, 65, 65'
}

export const moduleMenu = [
    {
      title: 'WORKPLACE',
      items: [
        {
          icon: 'ri-earth-line',
          color: MENUCOLOR.BLUE,
          route_name: 'dashboard',
          title: 'menu.module_menu.social',
          desc: 'menu.module_menu.social_desc',
          active: false,
          disable: true
        },
        {
          icon: 'ri-file-text-line',
          color: MENUCOLOR.PURPLE,
          route_name: 'document-list',
          title: 'menu.module_menu.document',
          desc: 'menu.module_menu.document_desc',
          active: true,
          disable: false
        },
        {
          icon: 'ri-briefcase-2-line',
          color: MENUCOLOR.BLUE,
          route_name: 'dashboard',
          title: 'menu.module_menu.work',
          desc: 'menu.module_menu.work_desc',
          active: true,
          disable: false
        },
        {
          icon: 'ri-survey-line',
          color: MENUCOLOR.GREEN,
          route_name: 'project-list',
          title: 'menu.module_menu.project',
          desc: 'menu.module_menu.project_desc',
          active: true,
          disable: false
        },
        {
          icon: 'ri-shape-line',
          color: '251, 175, 26',
          route_name: 'dashboard',
          title: 'menu.module_menu.task',
          desc: 'menu.module_menu.task',
          active: true,
          disable: true
        },
        {
          icon: 'ri-article-line',
          color: MENUCOLOR.GREEN,
          route_name: 'dashboard',
          title: 'menu.module_menu.dispatch',
          desc: 'menu.module_menu.dispatch_desc',
          active: true,
          disable: true
        },
        {
          icon: 'ri-calendar-todo-line',
          color: '224, 65, 65',
          route_name: 'dashboard',
          title: 'menu.module_menu.calendar',
          desc: 'menu.module_menu.calendar_desc',
          active: true,
          disable: true
        },
        {
          icon: 'ri-pencil-line',
          color: MENUCOLOR.PURPLE,
          route_name: 'dashboard',
          title: 'menu.module_menu.signature',
          desc: 'menu.module_menu.signature_desc',
          active: true,
          disable: true
        }
      ]
    },
    {
      title: 'HRM',
      items: [
        {
          icon: 'ri-sticky-note-line',
          color: MENUCOLOR.BLUE,
          route_name: 'dashboard',
          title: 'menu.module_menu.application',
          desc: 'menu.module_menu.application_desc',
          active: true,
          disable: true
        },
        {
          icon: 'ri-computer-line',
          color: MENUCOLOR.YELLOW,
          route_name: 'asset-list',
          title: 'menu.module_menu.assets',
          desc: 'menu.module_menu.assets_desc',
          active: true,
          disable: false
        },
        {
          icon: 'ri-user-add-line',
          color: MENUCOLOR.GREEN,
          route_name: 'dashboard',
          title: 'menu.module_menu.recruitment',
          desc: 'menu.module_menu.recruitment_desc',
          active: true,
          disable: true
        },
        {
          icon: 'ri-group-line',
          color: MENUCOLOR.RED,
          route_name: 'list-profile',
          title: 'menu.module_menu.hr',
          desc: 'menu.module_menu.hr_desc',
          active: true,
          disable: false
        },
        {
          icon: 'ri-checkbox-circle-line',
          color: MENUCOLOR.BLUE,
          route_name: 'dashboard',
          title: 'menu.module_menu.timekeeping',
          desc: 'menu.module_menu.timekeeping_desc',
          active: true,
          disable: true
        },
        {
          icon: 'ri-money-dollar-circle-line',
          color: MENUCOLOR.BLUE,
          route_name: 'dashboard',
          title: 'menu.module_menu.payroll',
          desc: 'menu.module_menu.payroll_desc',
          active: true,
          disable: true
        },
        {
          icon: 'ri-list-check-3',
          color: MENUCOLOR.GREEN,
          route_name: 'dashboard',
          title: 'menu.module_menu.evaluation',
          desc: 'menu.module_menu.evaluation_desc',
          active: true,
          disable: true
        },
        {
          icon: 'ri-bar-chart-2-line',
          color: MENUCOLOR.YELLOW,
          route_name: 'dashboard',
          title: 'menu.module_menu.kpi',
          desc: 'menu.module_menu.kpi_desc',
          active: true,
          disable: true
        },
        {
          icon: 'ri-graduation-cap-line',
          color: MENUCOLOR.GREEN,
          route_name: 'dashboard',
          title: 'menu.module_menu.training',
          desc: 'menu.module_menu.training_desc',
          active: true,
          disable: true
        }
      ]
    },
    {
      title: 'CRM',
      items: [
        {
          icon: 'ri-crosshair-2-line',
          color: MENUCOLOR.RED,
          route_name: 'dashboard',
          title: 'menu.module_menu.marketing',
          desc: 'menu.module_menu.marketing_desc',
          active: true,
          disable: true
        },
        {
          icon: 'ri-service-fill',
          color: MENUCOLOR.PURPLE,
          route_name: 'dashboard',
          title: 'menu.module_menu.customer_service',
          desc: 'menu.module_menu.customer_service_desc',
          active: true,
          disable: true
        },
        {
          icon: 'ri-shopping-bag-line',
          color: MENUCOLOR.BLUE,
          route_name: 'dashboard',
          title: 'menu.module_menu.sales',
          desc: 'menu.module_menu.sales_desc',
          active: true,
          disable: true
        },
        {
          icon: 'ri-cash-line',
          color: MENUCOLOR.YELLOW,
          route_name: 'dashboard',
          title: 'menu.module_menu.payment',
          desc: 'menu.module_menu.payment_desc',
          active: true,
          disable: true
        },
        {
          icon: 'ri-box-3-line',
          color: MENUCOLOR.GREEN,
          route_name: 'dashboard',
          title: 'menu.module_menu.warehouse',
          desc: 'menu.module_menu.warehouse_desc',
          active: true,
          disable: true
        },
        {
          icon: 'ri-shopping-bag-4-line',
          color: MENUCOLOR.RED,
          route_name: 'dashboard',
          title: 'menu.module_menu.purchase',
          desc: 'menu.module_menu.purchase_desc',
          active: true,
          disable: true
        }
      ]
    },
    {
      title: 'ADVANCE',
      items: [
        {
          icon: 'ri-customer-service-line',
          color: MENUCOLOR.PURPLE,
          route_name: 'dashboard',
          title: 'menu.module_menu.support',
          desc: 'menu.module_menu.support_desc',
          active: true,
          disable: true
        },
        {
          icon: 'ri-shopping-cart-line',
          color: MENUCOLOR.BLUE,
          route_name: 'dashboard',
          title: 'menu.module_menu.market',
          desc: 'menu.module_menu.market_desc',
          active: true,
          disable: true
        },
        {
          icon: 'ri-pie-chart-line',
          color: MENUCOLOR.YELLOW,
          route_name: 'dashboard',
          title: 'menu.module_menu.report',
          desc: 'menu.module_menu.report_desc',
          active: true,
          disable: true
        },
        {
          icon: 'ri-robot-2-line',
          color: MENUCOLOR.GREEN,
          route_name: 'dashboard',
          title: 'menu.module_menu.workflow',
          desc: 'menu.module_menu.workflow_desc',
          active: true,
          disable: true
        },
        {
          icon: 'ri-code-s-slash-line',
          color: MENUCOLOR.RED,
          route_name: 'dashboard',
          title: 'menu.module_menu.open_api',
          desc: 'menu.module_menu.open_api_desc',
          active: true,
          disable: true
        }
        ,{
          icon: 'ri-checkbox-multiple-blank-line',
          color: MENUCOLOR.PURPLE,
          route_name: 'portal',
          title: 'Portal',
          desc: 'Quản lý danh sách Portal',
          active: true,
          disable: false
        }
      ]
    }
  ]
