type DataTableConfigs = {
    itemsPerPageOptions: { value: number; text: string }[];
};

export const DataTableConfigs: DataTableConfigs = {
    itemsPerPageOptions: [
        { value: 15, text: '15' },
        { value: 25, text: '25' },
        { value: 50, text: '50' },
    ],
};