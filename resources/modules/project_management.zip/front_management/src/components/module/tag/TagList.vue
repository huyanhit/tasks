<template>
  <BCard no-body>
    <BCardHeader class="align-items-center d-flex">
      <BCardTitle class="mb-0 flex-grow-1"> {{ props.title.toUpperCase() }}</BCardTitle>
      <BButton
        class="flex-shrink-0 rounded-pill bg_content m-0 p-0"
        variant="link"
        @click="createTag"
      >
        <Icon icon="mdi-plus-circle-outline" width="24" color="#f87c30" />
      </BButton>
    </BCardHeader>
    <div class="p-3">
      <BOverlay :show="loading" spinner-variant="secondary" rounded="sm" bg-color="white">
      <template v-if="data">
        <div
          v-for="tag in data"
          class="badge rounded-pill border me-2 cursor-pointer mb-1 keep-spaces "
          :style="`border-color: ${tag.color} !important; color: ${tag.color};`"
          @contextmenu.prevent.stop="onContextMenu($event, tag)"
        >
          {{ tag.name.toString() }}
        </div>
      </template>
      <div v-if="data?.length === 0 && !loading" class="text-center">
        <p class="text-muted">{{ $t('setting_project.tag.emptyTag') }}</p>
      </div>
      </BOverlay>
    </div>
  </BCard>
  <TagModal ref="tagModal"  @load-tags="getTags" />
</template>

<script setup lang="ts">
import TagModal from '@/components/module/tag/modals/TagModal.vue'
import { TagService } from '@/modules/setting_project/services/tag.js'
import { Icon } from '@iconify/vue'
import ContextMenu from '@imengyu/vue3-context-menu'
import { useI18n } from 'vue-i18n'
import { showToast, showConfirm } from '@/helpers/common'

const { t } = useI18n()
const apiTag = new TagService()
const data = ref<Array<{ name: string; color: string }>>([])
const loading = ref(false)
const tagModal = ref<typeof TagModal | null>(null)

const props = defineProps(
  {
    title: {
      type: String,
      required: true
    },
    module: {
      type: String,
      required: true
    }
  }
)

onBeforeMount(() => {
  getTags()
})

const getTags = () => {
  loading.value = true
  apiTag.getModuleTags({ module: props.module })
    .then((res: any) => {
      data.value = res.data
    })
    .catch((err: any) => {
      console.log(err)
    })
    .finally(() => {
      loading.value = false
    })
}

const deleteTag = (tag: any) => {
    showConfirm({
      html: t('setting_project.tag.confirmDelete', { name: tag.name }),
      confirmButtonColor: '#ca383a',
      cancelButtonColor: '#fff',
      confirmButtonText: t('common.common.sweetalert.delete_button_text'),
      customClass: {
          cancelButton: 'text-black-50 border',
      }
    })
    .then((result: any) => {
      if (result.isConfirmed) {
        apiTag.deleteTag(tag.id)
          .then((res: any) => {
            if (res.success) {
              getTags()
              showToast({ icon: 'success', title: t('common.message.success') })
            } else {
              showToast({ icon: 'error', title: t('common.message.error'), text: res.message })
            }
          })
          .catch((err: any) => {
            console.log(err)
          })
      }
    })
}

const updateTag = (tag: any) => {
  tagModal.value?.open(tag)
}

const createTag = () => {
  tagModal.value?.open({
    name: '',
    color: '#ff0000',
    module: props.module
  })
}

const onContextMenu = function(e: any, tag: any) {
  ContextMenu.showContextMenu({
    x: e.x, y: e.y,
    items: [
      {
        label: t('setting_project.tag.action.update'),
        icon: h('i', { class: 'ri-edit-2-line'}),
        onClick: () => updateTag(tag)
      },
      {
        label: t('setting_project.tag.action.delete'),
        icon: h('i', { class: 'ri-delete-bin-line'}),
        onClick: () => deleteTag(tag)
      }
    ]
  })
}

</script>

<style scoped>
.keep-spaces { 
  white-space: pre-wrap;
}
</style>