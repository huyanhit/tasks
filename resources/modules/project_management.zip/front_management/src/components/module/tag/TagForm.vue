<template>
  <DTextField v-model="form.name" name="name" :label="t('setting_project.tag.label.name')" required/>
  <div class="d-flex form-control position-relative">
    <BButton v-for="item in colorTag" class="p-0 shadow-sm rounded-pill" variant="link"
             @click="form.color = item.color">
      <Icon icon="material-symbols:circle" width="24" height="24" :color="item.color" />
    </BButton>
    <BButton class="p-0 shadow-sm rounded-pill position-relative" variant="link">
      <Icon class="position-absolute" style="top:2px;left:2px" icon="material-symbols:check" width="20"
            height="20"
            color="#fff" />
      <Icon class="" icon="material-symbols:circle" width="24" height="24" :color="form.color" />
    </BButton>
    <BButton class="p-0 shadow-sm rounded-pill position-relative border" variant="link">
      <input type="color" class="position-absolute opacity-0" id="colorPicker" v-model="form.color">
      <Icon class="" icon="mdi:plus" width="24" height="24" color="#000" />
    </BButton>
  </div>
</template>

<script setup lang="ts">
import { Icon } from '@iconify/vue'
import { useI18n } from 'vue-i18n'
import Tag from '@/modules/setting_project/models/tag'
import DTextField from "@/components/common/DTextField.vue";

const { t } = useI18n()
const form = defineModel<Tag>('modelValue', {
  type: Object as PropType<Tag>,
  required: true
})

const colorTag = [
  { name: 'color-1', color: '#3e2723' },
  { name: 'color-2', color: '#d50000' },
  { name: 'color-3', color: '#ff6d00' },
  { name: 'color-4', color: '#c51162' },
  { name: 'color-5', color: '#aa00ff' },
  { name: 'color-6', color: '#6200ea' },
  { name: 'color-7', color: '#304ffe' },
  { name: 'color-8', color: '#00bfa5' },
  { name: 'color-9', color: '#00c853' },
  { name: 'color-10', color: '#ffd600' },
]

</script>
<style scoped>

</style>