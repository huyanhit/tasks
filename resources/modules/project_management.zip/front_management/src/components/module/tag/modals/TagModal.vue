<template>
  <Form :validation-schema="schema" v-slot="{ handleSubmit, handleReset }">
    <BModal v-if="modal" v-model="modal" :title="form.id ? t('setting_project.tag.action.update') : t('setting_project.tag.action.create')" >
      <TagForm v-model="form" />
      <template #footer="{ cancel }">
        <b-button variant="secondary" class="w-sm btn-save-modal" @click="handleSubmit(updateTag)">
          <span v-if="loading" class="spinner-border spinner-border-sm mr-2"></span>
          <span v-else>{{ $t('common.form.update') }}</span>
        </b-button>
        <b-button variant="outline-secondary" class="btn-close-modal" @click="handleCancel(cancel, handleReset)">
          {{ $t('common.form.cancel') }}
        </b-button>
      </template>
    </BModal>
  </Form>
</template>

<script setup lang="ts">
import TagForm from '@/components/module/tag/TagForm.vue'
import { useI18n } from 'vue-i18n'
import { TagService } from '@/modules/setting_project/services/tag.js'
import { Form } from 'vee-validate'
import { showToast } from '@/helpers/common'
import Tag from '@/modules/setting_project/models/tag'

const apiTag = new TagService()
const { t } = useI18n()
const emit = defineEmits(['loadTags'])
const modal = ref(false)
const form :Ref<Tag> = ref({
  id: null,
  name: null,
  color: '#ff0000',
  module: null
})

const loading = ref(false)
const schema = ref({
  name: 'required|max:255'
})

const open = (tag:Tag) => {
  if (tag) {
    form.value = Object.assign({}, tag)
  } else {
    form.value = {
      id: null,
      name: null,
      color: '#ff0000',
      module: null
    }
  }
  modal.value = true
}

const updateTag = (_: any, { resetForm, setFieldError }: { resetForm: () => void, setFieldError: (key: string, value: string) => void }) => {
  loading.value = true
  let createOrUpdate = form.value.id ? apiTag.updateTag(form.value.id, form.value) : apiTag.createTag(form.value)
  createOrUpdate.then((res: any) => {
      if (res.success) {
        showToast({ icon: 'success', title: t('common.message.success') })
        resetForm()
        emit('loadTags')
        modal.value = false
      } else {
        if (res.errors) {
          for (const [key, value] of Object.entries(res.errors)) {
            setFieldError(key, t(`common.back_end_validation.${value}`, { field: t(`setting_project.tag.label.${key}`)}))
          }
        }
        showToast({ icon: 'error', title: t('common.message.error'), text: res.message })
      }
    })
    .finally(() => {
      loading.value = false
    })
}

const handleCancel = (cancel:any, handleReset:any) => {
  handleReset()
  cancel()
}

defineExpose({
  open
})
</script>
<style scoped>

</style>