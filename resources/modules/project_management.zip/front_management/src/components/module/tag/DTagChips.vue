<template>
      <span v-for="tag in tags"
            class="badge rounded-pill border me-1"
            :key="tag.name"
            :style="`border-color: ${tag.color} !important; color: ${tag.color};`">
        {{ tag.name }}
      </span>
</template>
<script setup lang="ts">
defineProps({
  tags: {
    type: Array as () => { name: string, color: string }[],
    default: []
  }
})
</script>

<style scoped>

</style>