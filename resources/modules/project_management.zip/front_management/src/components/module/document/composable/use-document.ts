export default function useDocument() {

    const accept="application/msword,application/vnd.openxmlformats-officedocument.wordprocessingml.document,text/csv,image/jpeg,image/png,video/mp4,audio/mpeg,application/pdf,application/vnd.ms-powerpoint,application/vnd.openxmlformats-officedocument.presentationml.presentation,application/vnd.ms-excel,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
    const isImage = (ext: string) => {
        return ["jpg", "jpeg", "png", "gif", "bmp", "tiff"].includes(ext);
    }

    const getItemSize = (size: number) => {
        if (!size) return "0 KB"
        if (size < 1024) { return `${size.toFixed(2)} B`}

        const sizeInKB = size / 1024
        if (sizeInKB < 1024) { return `${sizeInKB.toFixed(2)} KB`}

        const sizeInMB = sizeInKB / 1024
        if (sizeInMB < 1024) { return `${sizeInMB.toFixed(2)} MB`}

        const sizeInGB = sizeInMB / 1024
        return `${sizeInGB.toFixed(2)} GB`;
    }

    const getIconSrc = (ext: string) => {
        if (ext) {
            switch (ext) {
                case "jpg":
                case "jpeg":
                    return "/src/assets/images/jpg-format.png";
                case "png":
                    return "/src/assets/images/png.png";
                case "pdf":
                    return "/src/assets/images/pdf.png";
                case "doc":
                    return "/src/assets/images/docx-file-format.png";
                case "docx":
                    return "/src/assets/images/docx-file-format.png";
                case "xlsx":
                    return "/src/assets/images/xlsx.png";
                case "xlsm":
                    return "/src/assets/images/xlsm.png";
                case "xls":
                    return "/src/assets/images/xls.png";
                case "wav":
                    return "/src/assets/images/wav.png";
                case "txt":
                    return "/src/assets/images/txt.png";
                case "ttf":
                    return "/src/assets/images/ttf.png";
                case "tiff":
                    return "/src/assets/images/tiff.png";
                case "svg":
                    return "/src/assets/images/svg.png";
                case "rar":
                    return "/src/assets/images/rar.png";
                case "psd":
                    return "/src/assets/images/psd.png";
                case "pptx":
                    return "/src/assets/images/pptx.png";
                case "ppt":
                    return "/src/assets/images/ppt.png";
                case "zip":
                    return "/src/assets/images/zip.png";
                case "mpg":
                    return "/src/assets/images/mpg.png";
                case "mp4":
                    return "/src/assets/images/mp4.png";
                case "php":
                    return "/src/assets/images/php.png";
                case "otf":
                    return "/src/assets/images/otf.png";
                default:
                    return "/src/assets/images/txt.png";
            }
        }
        return "/src/assets/images/txt.png";
    }

    const downloadFile = (file:Blob, fileName:string) => {
        const url = window.URL.createObjectURL(file)
        const link = document.createElement('a');
        link.href = url
        link.download = fileName;
        document.body.appendChild(link);
        link.click();
        link.remove();
        window.URL.revokeObjectURL(url)
    }

    return {
        accept,
        isImage,
        getItemSize,
        getIconSrc,
        downloadFile
    }
}