<template>
  <div class="d-flex align-items-center">
    <span v-for="(item, index) in items"
          class="cursor-pointer d-flex align-items-center"
          @click="emit('current', index)"
    >
          {{ item.name }}
      <Icon v-if="index !== (items.length - 1)" icon="ri:arrow-right-s-line" class="icon" width="20" color="#6C87FE"/>
<!--   <Icon v-if="items.length > 2" icon="ri:arrow-drop-down-line" class="icon" color="#6C87FE" @click.prevent.stop="openViewMenu"/>-->
    </span>
<!--    <context-menu v-model:show="show" :options="options">-->
<!--      <template v-for="(item, index) in items" :key="item.id">-->
<!--        <context-menu-item v-if="index !== (items.length - 1)" @click="emit('current', index)">-->
<!--          <div v-if="index !== (items.length - 1)" class="d-flex align-items-center">-->
<!--            <span style="letter-spacing: -0.1em" class="me-1">{{ '-'.repeat(index * 2) }}</span>-->
<!--            <i class="ri-folder-6-line me-1 fs-18"/>-->
<!--            {{ item.name }}-->
<!--          </div>-->
<!--        </context-menu-item>-->
<!--      </template>-->
<!--    </context-menu>-->
  </div>
</template>

<script setup lang="ts">
import {PropType} from "vue"
import {Icon} from "@iconify/vue"

defineProps({
  items: {
    type: Array as PropType<any[]>,
    default: () => []
  },
  current: {
    type: Object as PropType<any>,
    default: {
      id: 0,
      name: ''
    }
  }
})

// const show = ref(false)
// const options = ref({
//   x: 0,
//   y: 0,
// })
const emit = defineEmits(['current', 'back'])
// const openViewMenu = (e: MouseEvent) => {
//   show.value = true
//   options.value = {
//     x: e.x,
//     y: e.y
//   }
// }
</script>