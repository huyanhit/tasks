<template>
  <b-modal
    v-model="modal"
    :title="modalTitle"
    centered
    class="modal-forum full-modal"
    content-class="vh-100"
    fullscreen
    hide-footer
  >
    <template #header="{close}">
      <div class="d-flex align-items-center justify-content-between w-100">
        <strong v-if="isImage(file.extension)">{{ modalTitle }}</strong>
        <div v-if="!isImage(file.extension)" class="d-flex" >
          <div data-bs-toggle="tooltip" data-bs-placement="top" title="Google View" @click="toggleTool('google')">
            <icon icon="ri:google-fill" class="icon" :color="checkActive('google') ? '#fb6900' : '#cfcfcf'" />
          </div>
          <div data-bs-toggle="tooltip" data-bs-placement="top" title="Microsoft View" @click="toggleTool('microsoft')">
            <icon icon="ri:windows-fill" class="icon" :color="checkActive('microsoft') ? '#fb6900' : '#cfcfcf'" />
          </div>
          <div data-bs-toggle="tooltip" data-bs-placement="top" title="Download" >
            <Icon icon="ri:download-cloud-2-line" class="icon btn-success"  />
          </div>
          <div data-bs-toggle="tooltip" data-bs-placement="top" title="Print" >
            <Icon icon="ri:printer-cloud-line" class="icon btn-success"  />
          </div>
        </div>
        <Icon  class="btn-close" icon="ri:close-line" width="24"  @click="close" />
      </div>
    </template>

    <template v-if="isImage(file.extension)">
      <div class="d-flex justify-content-center align-items-center" style="height: 100%">
        <img :src="urlView"
             alt="image"
             @wheel.prevent="resizeImage($event.deltaY)"
             :style="{ transform: `scale(${scale})`, 'max-height': '100%', 'max-width': '100%',}"
             ref="messageImage"
             class="modal-image" />
      </div>
      <div class="btn-group position-absolute" style="top: 20px; right: 20px">
        <button class="btn btn-outline-secondary" @click.prevent="resizeImage(-100)"><i class="ri ri-zoom-out-line"></i></button>
        <button class="btn btn-outline-secondary" @click.prevent="resizeImage(100)"><i class="ri ri-zoom-in-line"></i></button>
        <button class="btn btn-outline-secondary" @click.prevent="toggleImageSize"><i class="ri ri-fullscreen-line"></i></button>
      </div>
    </template>


    <template v-if="!isImage(file.extension)">
      <iframe
        v-if="checkActive('google')"
        :src="`https://docs.google.com/viewer?url=${urlView}`"
        width="100%"
        height="100%"
        frameborder="0"
      ></iframe>
      <iframe
        v-if="checkActive('microsoft')"
        :src="`https://view.officeapps.live.com/op/embed.aspx?src=${urlView}`"
        width="100%"
        height="100%"
        frameborder="0"
      ></iframe>
    </template>
  </b-modal>
</template>

<script setup lang="ts">
import {Attachment} from "@/modules/document/models/document-attachment"
import {Icon} from "@iconify/vue"
import useDocument from "@/components/module/document/composable/use-document";
import {DocumentAttachmentService} from "@/modules/document/services/document-attachment";

const { isImage } = useDocument()
const URL = import.meta.env.VITE_APP_API_DOMAIN
const modal = ref(false)
const modalTitle = ref('')
const scale = ref(1);
const isModalImage = ref(true);
const apiDocument = new DocumentAttachmentService();
const urlView = ref('')
const file = ref<Attachment>({
  id: 0,
  name: '',
  type: '',
  extension: '',
  capacity: '',
  thumbnail_url: '',
  viewer: '',
  created_at: '',
})

const typeView = ref('google')

const openModal = (attachment: Attachment) => {
  file.value = attachment;
  modalTitle.value = attachment.name;
  modal.value = true;
  viewFile()
}

const viewFile = () => {
  if (isImage(file.value.extension)) {
    apiDocument.downloadDocument(file.value.id).then((res: any) => {
      urlView.value = window.URL.createObjectURL(res.data)
    })
  } else {
    urlView.value = `${URL}/${file.value.viewer}`
  }
}
const toggleTool = (type: string) => {
  typeView.value = type
}

const checkActive = (type: string) => {
  return typeView.value === type
}

const resizeImage = (deltaY: number) => {
  const img = document.querySelector('.modal-image') as HTMLImageElement;
  if (!img) return;
  const newScale = scale.value + deltaY * 0.001;
  scale.value = Math.max(0.1, newScale); // Prevents the image from being too small
  img.style.transform = `scale(${scale.value})`;
}

const toggleImageSize = () => {
  isModalImage.value = !isModalImage.value;
  const img = document.querySelector('.modal-image') as HTMLImageElement;
  if (!img) return;
  scale.value = isModalImage.value ? (img.naturalWidth / img.width) : 1;
  img.style.transform = `scale(${scale.value})`;
}

defineExpose({
  openModal
})
</script>


<style scoped>

</style>