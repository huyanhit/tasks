<template>
  <d-accordion>
    <template #accordion-header>
      <div class="actions d-flex align-items-center justify-content-between my-0 d-accordion">
        <div v-if="selected.length" class="d-flex align-items-center justify-content-start">
          <div class="btn btn-sm button btn-form-icon" @click="bulkDelete">
            <Icon icon="mdi-delete-outline" width="18" />
            <span class="action-label d-block">{{ t('document.document.action.delete') }}</span>
          </div>
          <div v-if="checkDownload()" class="btn btn-sm button btn-form-icon" @click="bulkDownload">
            <Icon icon="ri:download-cloud-2-line" width="18" />
            <span class="action-label d-block">{{ t('document.document.action.download') }}</span>
          </div>
        </div>
        <breadcrumb-document v-else :items="breadcrumb" :current="currentFolder" @back="backFolder"
                             @current="chooseFolder"/>
        <div class="d-flex align-items-center mx-2">
          <Icon icon="ri:folder-add-line" class="icon" color="#909090" alt="Create Folder" @click="createFolder"/>
          <Icon icon="ri:file-upload-line" class="icon" color="#909090" alt="Upload File" @click="triggerFileInput"/>
          <Icon :icon="typeViewIcon" class="icon" color="#909090" @click.prevent.stop="openViewMenu"/>
          <input type="file" ref="fileInput" @change="uploadFile" style="display: none" :accept="accept"/>
        </div>
      </div>
    </template>
    <template #body-accordion>
      <b-overlay :show="loading" rounded="sm" spinner-variant="secondary">
        <DFileManagement
          :initial-items="documents"
          :type-view="typeView"
          :model-id="modelId"
          :module-type="moduleType"
          @load-current="nextFolder"
          @reload="getDocumentProject"
        />
      </b-overlay>
    </template>
  </d-accordion>
  <!-- modal -->

  <create-or-update-folder ref="folderModal" @update="getDocumentProject"/>
</template>

<script setup lang="ts">
import DFileManagement from "@/components/common/DFileManagement.vue"
import DAccordion from "@/components/common/DAccordion.vue"
import CreateOrUpdateFolder from "@/components/module/document/modals/CreateOrUpdateFolder.vue"
import BreadcrumbDocument from "@/components/module/document/BreadcrumbDocument.vue"
import {h} from "vue"
import {useI18n} from "vue-i18n"
import {showToast} from "@/helpers/common"
import useDocument from "@/components/module/document/composable/use-document"
import {Icon} from "@iconify/vue"
import ContextMenu from "@imengyu/vue3-context-menu"
import {DocumentAttachmentService} from "@/modules/document/services/document-attachment"
import {Attachment} from "@/modules/document/models/document-attachment";

const props = defineProps<{
  modelId: string | number;
  moduleType: string;
  title: string;
}>();
const {t} = useI18n()
const emitter = inject<any>('emitter')
const {accept} = useDocument()
const apiDocument = new DocumentAttachmentService()
const loading = ref(false);
const documents = ref<Attachment[]>([])
const selected = ref([])
const typeView = ref('group');
const typeViewIcon = ref('ri:list-indefinite');
const fileInput = ref<HTMLInputElement | null>(null);
const folderModal = ref<InstanceType<typeof CreateOrUpdateFolder> | null>(null)
const currentFolder = ref({
  id: null,
  name: ''
})

const breadcrumb = ref([
  {
    id: null,
    name: props.title
  }
])

const nextFolder = (folder: any) => {
  currentFolder.value = folder
  breadcrumb.value.push(folder)
  getDocumentProject()
}

const backFolder = () => {
  currentFolder.value = breadcrumb.value[breadcrumb.value.length - 2]
  breadcrumb.value.pop()
  getDocumentProject()
}

const chooseFolder = (index: any) => {
  currentFolder.value = breadcrumb.value[index]
  breadcrumb.value.splice(index + 1)
  getDocumentProject()
}

const openViewMenu = (e: MouseEvent) => {
  ContextMenu.showContextMenu({
    x: e.x,
    y: e.y,
    items: [
      {
        label: t('document.document.view.grid'),
        icon: h('i', {class: 'ri-layout-grid-2-fill'}),
        onClick: () => {
          typeView.value = 'grid'
          typeViewIcon.value = 'ri:layout-grid-2-fill'
        },
      },
      {
        label: t('document.document.view.list'),
        icon: h('i', {class: 'ri-list-unordered'}),
        onClick: () => {
          typeView.value = 'list'
          typeViewIcon.value = 'ri:list-unordered'
        },
      },
      {
        label: t('document.document.view.group'),
        icon: h('i', {class: 'ri-list-indefinite'}),
        onClick: () => {
          typeView.value = 'group'
          typeViewIcon.value = 'ri:list-indefinite'
        },
      },
    ]
  })
}

const createFolder = () => {
  const form = {
    id: currentFolder.value.id || '',
    type: 'folder',
    folder_name: '',
    module_type: props.moduleType,
    model_id: props.modelId,
  }
  folderModal.value?.open(form, currentFolder.value.id ? 'add-children' : 'add-root')
}
const triggerFileInput = () => {
  fileInput.value?.click();
}

const uploadFile = () => {
  const files = fileInput.value?.files;
  if (files && files.length > 0) {
    loading.value = true
    let formData = new FormData()
    const file = files[0];
    if (!currentFolder.value.id) {
      formData.append('model_id', props.modelId.toString())
      formData.append('module_type', props.moduleType)
    }
    formData.append('type', 'file')
    formData.append('file[0]', file)

    const action = currentFolder.value.id ? apiDocument.createChildrenAttachment(currentFolder.value.id, formData) : apiDocument.createAttachment(formData)

    action.then((res: any) => {
      if (res.success) {
        showToast({icon: "success", title: t('common.message.success')})
        getDocumentProject()
      } else {
        showToast({icon: 'error', title: t('common.message.error'), text: res.message})
      }
    }).finally(() => {
      loading.value = false
    })
  }
}

const checkDownload = () => {
  return !selected.value.some((id: string | number) => documents.value.find((item: Attachment) => item.id === id)?.type === 'folder')
}

const bulkDelete = () => {
  apiDocument.deleteAttachment({ids: selected.value}).then((res: any) => {
    if (res.success) {
      showToast({icon: "success", title: t('common.message.success')})
      getDocumentProject()
    } else {
      showToast({icon: 'error', title: t('common.message.error'), text: res.message})
    }
  })
}

const bulkDownload = () => {
  console.log('bulk download')
}

onMounted(() => {
  emitter.on('select-attachments', (items: []) => {
    selected.value = items
  })
  getDocumentProject()
})

const getDocumentProject = () => {
  loading.value = true
  if (currentFolder.value.id) {
    apiDocument.getChildOfDocument(currentFolder.value.id, {per_page: 1000}).then((res) => {
      documents.value = res.data.data
    }).finally(() => {
      loading.value = false
    })
  } else {
    apiDocument.getRootDocument({
      model_id: props.modelId,
      module_type: props.moduleType,
      per_page: 1000
    }).then((res) => {
      documents.value = res.data.data
    }).finally(() => {
      loading.value = false
    })
  }
}

</script>
<style scoped>
.icon {
  cursor: pointer;
  font-size: 30px;
  padding: 5px;
}

.action-label {
  color: #909090;
  font-size: 12px;
}
.btn:hover .action-label{
  color: var(--color-orange);
}
</style>

