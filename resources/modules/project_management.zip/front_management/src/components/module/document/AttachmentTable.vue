<template>
  <data-table
    v-model:selected="selected"
    :headers="headers"
    :data="data"
    hide-pagination
    is-show-checkbox
    @open-menu="openContextMenu"
    @update:selected="emitter.emit('select-attachments', selected)"
  >
    <template #item.name="{item}: {item: Attachment}">
      <div class="d-flex align-items-center cell-name" @click="emit('open', item)"><img
        :src="item.thumbnail_url"
        alt=""
        width="25"
        height="25"
        loading="lazy"
        :title="item.name"
      /><span class="ms-2 text-truncate">{{ item.name }}</span></div>
    </template>
    <template #item.capacity="{item}: {item: Attachment}">
      <span>{{ getItemSize(parseInt(item.capacity)) }}</span>
    </template>
    <template #item.created_at="{item}: {item: Attachment}">
      <span>{{ moment(item.created_at).format('hh:mm DD/MM/YYYY') }}</span>
    </template>
    <template #item.created_by="{item}: {item: Attachment}">
      <d-users :users="[item.created_by]"/>
    </template>
  </data-table>
</template>

<script setup lang="ts">
import {useI18n} from "vue-i18n"
import moment from "moment"
import {Attachment} from "@/modules/document/models/document-attachment"
import {h, PropType} from "vue"
import DataTable from "@/components/common/DataTable.vue"
import useDocument from "@/components/module/document/composable/use-document"
import DUsers from "@/components/common/DUsers.vue"
import ContextMenu from "@imengyu/vue3-context-menu";

defineProps(
  {
    data: {
      type: Array as PropType<Attachment[]>,
      default: () => []
    }
  }
)

const {getItemSize} = useDocument()
const {t} = useI18n()
const emit = defineEmits(['update', 'open'])
const emitter = inject<any>('emitter')
const selected = ref([])
const headers = ref([
  {text: t('document.document.label.name'), value: 'name'},
  {text: t('document.document.label.capacity'), value: 'capacity', width: '150px'},
  {text: t('document.document.label.extension'), value: 'extension', width: '100px'},
  {text: t('document.document.label.created_at'), value: 'created_at', width: '200px'},
  {text: t('document.document.label.created_by'), value: 'created_by', width: '200px'},
])

const openContextMenu = ({$event, item}: any) => {
  let items = [
    {
      label: t('document.document.action.change_name'),
      icon: h("i", {class: "ri-edit-line"}),
      onClick: () => emit('update', {type: 'change_name', item}),
    },
    {
      label: t('document.document.action.move'),
      icon: h("i", {class: "ri-corner-up-right-line"}),
      onClick: () => emit('update', {type: 'move', item}),
    },
    {
      label: t('document.document.action.delete'),
      icon: h("i", {class: "ri-delete-bin-line"}),
      onClick: () => emit('update', {type: 'delete', item}),
    }
  ]

  if (item.type === 'folder') {
    items = [
      {
        label: t('document.document.action.add'),
        icon: h("i", {class: "ri-folder-add-line"}),
        onClick: () => emit('update', {type: 'add', item}),
      },
      {
        label: t('document.document.action.upload'),
        icon: h("i", {class: "ri-file-upload-line"}),
        onClick: () => emit('update', {type: 'upload', item}),
      },
      ...items
    ]
  } else {
    items = [
      {
        label: t('document.document.action.download'),
        icon: h("i", {class: "ri-download-line"}),
        onClick: () => emit('update', {type: 'download', item}),
      },
      {
        label: t('document.document.action.view'),
        icon: h("i", {class: "ri-search-line"}),
        onClick: () => emit('update', {type: 'view', item}),
      },
      ...items
    ]
  }

  ContextMenu.showContextMenu({
    x: $event.x,
    y: $event.y,
    items: items
  });
}

</script>

<style scoped>
.cell-name:hover {
  color: var(--color-orange);
  cursor: pointer;
}
</style>