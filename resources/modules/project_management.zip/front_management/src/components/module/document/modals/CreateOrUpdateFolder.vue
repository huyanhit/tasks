<template>
  <d-form-modal
    v-model="modal"
    :loading
    centered
    :title="!form.id ? t('document.document.action.add') : t('document.document.action.update')"
    @submit="submit"
  >
    <d-text-field name="name" :label="t('document.document.label.name')" v-model="form.folder_name" required rules="required"/>
  </d-form-modal>
</template>
<script setup lang="ts">
import DFormModal from "@/components/common/DFormModal.vue"
import DTextField from "@/components/common/DTextField.vue"
import {DocumentAttachmentService} from "@/modules/document/services/document-attachment"
import {showToast} from "@/helpers/common"
import {useI18n} from "vue-i18n"
import * as string_decoder from "string_decoder";

const {t} = useI18n()
const apiAttachment = new DocumentAttachmentService()
const emit = defineEmits(['update'])
const modal = ref(false)
const loading = ref(false)
const typeAction = ref('add-root')
const id = ref(0)
const form = ref({
  id: '',
  type: 'folder',
  folder_name: '',
  module_type: '',
  model_id: 0,
})

const open = (data: any, type:string = 'add-root') => {
  if (type === 'add-children') {
    id.value = data.id
  } else {
    form.value = Object.assign({}, data)
  }
  typeAction.value = type
  modal.value = true
}

const submit = () => {
  let action: any = null

  switch (typeAction.value) {
    case 'add-root':
      action = apiAttachment.createAttachment(form.value)
      break
    case 'update':
      action = apiAttachment.updateAttachment(form.value.id, {name: form.value.folder_name})
      break
    case 'add-children':
      action = apiAttachment.createChildrenAttachment(id.value, form.value)
      break
    default:
      return
  }

  loading.value = true
  action.then((response: any) => {
    if (response.success) {
      showToast({icon: "success", title: t('common.message.success')});
      emit('update', form.value)
      modal.value = false
    } else {
      showToast({icon: 'error', title: t('common.message.error'), text: response.message})
    }
  }).finally(() => {
    loading.value = false
  })
}

defineExpose({
  open
})
</script>
<style scoped>

</style>