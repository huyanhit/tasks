<template>
  <div class="attachment-card" @contextmenu.prevent.stop="openContextMenu($event, item)">
    <div class="attachment-thumbnail d-flex flex-column align-items-center justify-content-center">
      <img
        :class="isImage(item.extension) ? 'thumb-image' : 'thumb-icon'"
        :src="item.thumbnail_url"
        :alt="item.name"
        loading="lazy"
        :title="item.name"
      />
    </div>
    <div class="mt-1 d-flex align-items-center">
      <div v-if="item.type !== 'folder'" class="me-2">
        <img
          :src="item.thumbnail_url"
          :alt="item.name"
          height="20"
          width="20"
          loading="lazy"
        />
      </div>
      <div class="flex-grow-1 overflow-hidden">
        <div class="text-truncate fw-medium attachment-title cursor-pointer">{{ item.name }}</div>
        <div class="attachment-info d-flex align-items-center justify-content-between fw-lighter">
          <div class="date">{{ filters.date(item.created_at) }}</div>
          <div class="size">{{ getItemSize(parseInt(item.capacity)) }}</div>
        </div>

      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import filters from '@/helpers/filter'
import {Attachment} from '@/modules/document/models/document-attachment'
import useDocument from "@/components/module/document/composable/use-document"
import {h} from "vue"
import ContextMenu from "@imengyu/vue3-context-menu"
import {useI18n} from "vue-i18n"

defineProps<{
  item: Attachment
}>()
const emit = defineEmits(['update'])
const {t} = useI18n()
const {isImage, getItemSize} = useDocument()

const openContextMenu = (event: any, item: any) => {
  let items = [
    {
      label: t('document.document.action.change_name'),
      icon: h("i", {class: "ri-edit-line"}),
      onClick: () => emit('update', {type: 'change_name', item}),
    },
    {
      label: t('document.document.action.move'),
      icon: h("i", {class: "ri-corner-up-right-line"}),
      onClick: () => emit('update', {type: 'move', item}),
    },
    {
      label: t('document.document.action.delete'),
      icon: h("i", {class: "ri-delete-bin-line"}),
      onClick: () => emit('update', {type: 'delete', item}),
    }
  ]

  if (item.type === 'folder') {
    items = [
      {
        label: t('document.document.action.add'),
        icon: h("i", {class: "ri-folder-add-line"}),
        onClick: () => emit('update', {type: 'add', item}),
      },
      {
        label: t('document.document.action.upload'),
        icon: h("i", {class: "ri-file-upload-line"}),
        onClick: () => emit('update', {type: 'upload', item}),
      },
      ...items
    ]
  } else {
    items = [
      {
        label: t('document.document.action.download'),
        icon: h("i", {class: "ri-download-line"}),
        onClick: () => emit('update', {type: 'download', item}),
      },
      {
        label: t('document.document.action.view'),
        icon: h("i", {class: "ri-search-line"}),
        onClick: () => emit('update', {type: 'view', item}),
      },
      ...items
    ]
  }

  ContextMenu.showContextMenu({
    x: event.x,
    y: event.y,
    items: items
  });
}
</script>

<style scoped>
.attachment-card {
  border-radius: 5px;
  padding: 12px 16px;
  background-color: rgba(89, 96, 255, 0.08);
  width: 100%;

  &:hover {
    .attachment-title {
      color: var(--color-orange);
    }
  }
}

.attachment-thumbnail {
  height: 110px;
  width: 100%;
}

.thumb-image {
  width: 100%;
  height: 100%;
  object-fit: cover;
}

.thumb-icon {
  width: 50px;
  height: 50px;
}

.attachment-info {
  font-size: 0.85em;
}
</style>