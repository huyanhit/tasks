<template>
  <BPopover :target="target" variant="link" triggers="focus" teleportTo="body">
    <div class="tooltip-custom">
      <div class="d-flex gap-3 mb-2">
        <a href="javascript: void(0);" class="avatar-group-item">
          <img :src="avatar" class="rounded-circle avatar-xs" />
        </a>
        <div class="d-flex flex-column">
          <h5 class="text-secondary mb-2">{{ name }}</h5>
          <div v-if="department" class="d-flex align-items-center gap-1">
            <Icon icon="material-symbols:home-outline-rounded" width="14" />
            {{ department }}
          </div>
          <div v-if="position" class="d-flex align-items-center gap-1">
            <Icon icon="material-symbols:frame-person" width="14" />
            {{ position }}
          </div>
        </div>
      </div>
      <div class="d-flex gap-2 justify-content-end">
        <BButton
          v-if="!hideChat"
          variant="secondary"
          :href="`/chat/rid-${id}`"
          class="btn btn-primary waves-effect waves-light"
          size="sm"
        >
          <Icon
            class="mb-1 me-1"
            icon="material-symbols:chat-bubble-outline-rounded"
            width="14"
          />Chat ngay
        </BButton>
        <BButton
          variant="outline-secondary"
          :href="`/user?id=${id}`"
          class="btn btn-primary waves-effect waves-light"
          size="sm"
        >
          <Icon class="mb-1 me-1" icon="material-symbols:person-rounded" width="14" />Trang cá nhân
        </BButton>
      </div>
    </div>
  </BPopover>
</template>
<script setup>
import { computed } from 'vue'
 defineProps({
  target: {
    type: String,
    required: true
  },
  avatar: {
    type: String,
    required: true
  },
  name: {
    type: String,
    required: true
  },
  department: {
    type: String,
  },
  position: {
    type: String,
  },
  id: {
    type: String,
    required: true
  },
  hideChat: {
    type: Boolean,
    default: false
  }
});
</script>

<style lang="scss" scoped>
.tooltip-custom {
.overflow-auto {
  width: 300px !important;
}
}

</style>