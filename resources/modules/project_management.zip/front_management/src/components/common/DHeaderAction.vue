<template>
  <div id="headerAction" class="d-flex align-items-center">
    <div v-if="dropdownData && dropdownData.length && !modalId">
      <BDropdown no-caret offset="8" size="sm" class="rounded-pill bg_content" variant="link">
        <template #button-content>
          <Icon icon="mdi-plus-circle-outline" width="32" />
        </template>
        <template class="d-none d-sm-block " v-for="(item, index) in dropdownData" :key="index">
          <BDropdownDivider v-if="item.footer" />
          <BDropdownItem v-b-modal="item.id" :href="item.href ?? '#'">
            {{ item.title }}
          </BDropdownItem>
        </template>
      </BDropdown>
    </div>
    <div v-else-if="modalId && (!dropdownData || !dropdownData.length)">
      <BButton class="rounded-pill bg_content" v-b-modal="modalId" variant="link" @click="$emit('addNew')">
        <Icon icon="mdi-plus-circle-outline" width="32" color="#f87c30"/>
      </BButton>
    </div>
    <div v-else-if="contextMenu && (!dropdownData || !dropdownData.length)">
      <BButton class="rounded-pill bg_content" v-b-modal="contextMenu" variant="link">
        <Icon icon="mdi-plus-circle-outline" width="32" color="#f87c30"/>
      </BButton>
    </div>
    <div class="d-grid text-left">
      <span class="fs-5 fw-bold d-none d-md-block">{{ pageTitle }}</span>
    </div>
  </div>
</template>

<script setup lang="ts">
  import { Icon } from '@iconify/vue';
  import { onMounted } from 'vue';

const props = defineProps({
  dropdownData: {
    type: Array as () => { id?: string; title?: string; href?: string; footer?: boolean }[],
    default: () => [],
  },
  pageTitle: {
    type: String,
    required: true,
  },
  modalId: {
    type: String,
    required: false,
  },
  contextMenu: {
    type: String,
    required: false,
  },
})

</script>

<style lang="css">
  .btn-add-modal{
    cursor: pointer;
    height: 28px;
    width: 28px;
    padding: 0;
    display: flex;
    align-items: center;
    justify-content: center;
    border-radius: 50%;
    color: rgb(39, 140, 205);
    background: #fff;
    font-size: 1.5em;
    transition: all .4s ease-in;
    border: 1px solid rgb(251,105,0);
    transform: rotate(0deg);
    margin-right: 10px;
  }
  .btn-add-modal:hover{
    transform: rotate(90deg);
    box-shadow: 0 0 0 5px rgb(251,105,0,.2);
    background: rgb(251,105,0);
    color: #fff;
  }
  .btn-add-modal:hover svg, .btn-add-modal:hover svg path{
    color: #fff !important;
  }
  #headerAction button[type='button'],
  #headerAction button[type='button']:after {
    background-color: white;
    border: none;
    color: #f87c30;
    padding-left: 0px;
  }
  #headerAction .dropdown-item{
    padding: 8px 17px;
  }
</style>
