
<template>
    <div
        @dragover.prevent
        @drop.prevent="dragFile"
        :class="{ 'active-dropzone': data.active }"
        class="dropzone position-relative text-center"
    >
        <div class="mb-1">
            <i class="display-4 text-muted ri-upload-cloud-2-fill"></i>
        </div>
        <h5>Drop files here or click to upload.</h5>
        <label for="dropzoneFile" class="stretched-link">Upload</label>
        <input type="file" id="dropzoneFile" class="dropzoneFile btn btn-primary d-none" multiple v-on:change="chooseFiles($event)"/>
    </div>
    <simplebar data-simplebar style="max-height: 320px">
    <ul class="list-unstyled mb-0 pe-3" id="dropzone-preview">
        <li class="mt-2" id="dropzone-preview-list" v-for="(item, index) in props.files" :key="index">
            <div class="border rounded">
                <div class="d-flex p-2">
                    <div class="flex-shrink-0 me-3">
                        <div class="avatar-sm bg-light rounded">
                            <img :src="item.thumbnail_url" class="img-fluid rounded d-block" alt="preview"/>
                        </div>
                    </div>
                    <div class="flex-grow-1">
                        <div class="pt-3">
                            <h5 class="fs-14 mb-1">{{ item.name }}.{{ item.extension }}</h5>
                        </div>
                    </div>
                    <div class="flex-shrink-0 mt-2">
                        <span @click="deleteFile(index)" class="btn btn-sm btn-danger" v-if="item.data">Delete</span>
                    </div>
                </div>
            </div>
        </li>
    </ul>
    </simplebar>
</template>
<script setup>

import { reactive, watch } from 'vue'

const props = defineProps(['files'])
const emit  = defineEmits(['changeFile'])
const data  = reactive({
    active: true,
    scr_preview: [],
    icon_preview: [],
})
watch(props.files, (files) => {
    emit('changeFile', files);
})
const deleteFile = function(index){
    delete props.files.splice(index, 1)
}
const chooseFiles = function(e){
    for(let file of e.target.files){
        unshiftFile(file);
    }
}
const unshiftFile = function(file){
    const split = file.name.split('.');
    props.files.unshift({
        name: split[0],
        extension: split[0],
        thumbnail_url: URL.createObjectURL(file),
        data: file
    });
}
const dragFile = function(ev){
    if (ev.dataTransfer.items) {
        [...ev.dataTransfer.items].forEach((item, i) => {
            if (item.kind === "file") {
                const file = item.getAsFile()
                unshiftFile(file);
            }
        });
    } else {
        [...ev.dataTransfer.files].forEach((file) => {
            unshiftFile(file);
        });
    }
}

</script>
  