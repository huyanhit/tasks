<template>
  <BCol :class="class" :lg="col">
    <div>{{ label }}</div>
    
    <div class="upload-wrapper" :style="mode === 'file' ? 'height: 80px' : ''">
      <div class="upload-area" :class="mode">
        <input
          type="file"
          class="input-file"
          @change="handleFileUpload"
          :accept="mode === 'image' ? 'image/*' : '*/*'"
          ref="fileInput"
        />
        <div v-if="fileUrl" class="preview-container">
          <img v-if="mode === 'image' && isImage(fileUrl)" :src="fileUrl" alt="Preview" @click="triggerFileInput" />
          <div v-else-if="mode === 'file'" class="file-icon">
            <Icon icon="ri:file-fill" width="50" />
            <span class="file-name">{{ fileName }}</span>
          </div>
          <div class="icon-close" @click.stop="clearFile">
            <Icon class="btn-close" icon="ri:close-line" />
          </div>
        </div>
      
        <div v-else class="preview-placeholder" @click="triggerFileInput">
          <Icon :icon="mode === 'image' ? 'ri:upload-cloud-2-fill' : 'ri:upload-cloud-2-fill'" width="30" class="upload-icon" />
          
        </div>
     
      </div>
    </div>
  </BCol>
</template>

<script lang="ts" setup>

// Define the props with default values
const props = defineProps<{
  label?: string;
  class?: string;
  col?: number;
  mode?: 'image' | 'file'; // Define the mode prop
}>();
const fileModel = defineModel();
// Default value for mode
const mode = ref(props.mode ?? 'image');

const fileUrl = ref<string>('');
const fileInput = ref<HTMLInputElement | null>(null);
const fileName = ref<string>('');
const handleFileUpload = (event: Event) => {
  const input = event.target as HTMLInputElement;
  if (input.files && input.files[0]) {
    const file = input.files[0];
    if (mode.value === 'image' && file.type.startsWith('image/')) {
      const reader = new FileReader();
      reader.onload = (e) => {
        if (e.target && typeof e.target.result === 'string') {
          fileUrl.value = e.target.result;
          
        }
      };
      reader.readAsDataURL(file);
    } else if (mode.value === 'file') {
      const reader = new FileReader();
      reader.onload = (e) => {
        if (e.target && typeof e.target.result === 'string') {
          fileUrl.value = fileModel.value = e.target.result;
        }
      };
      reader.readAsDataURL(file);
    }
    fileName.value = file.name;
    fileModel.value = file;
  }
};

const clearFile = () => {
  fileUrl.value = fileModel.value = fileName.value ='';
  if (fileInput.value) {
    fileInput.value.value = '';
  }
};


const triggerFileInput = () => {
  if (fileInput.value) {
    fileInput.value.click();
  }
};

const isImage = (url: string): boolean => {
  return url.startsWith('data:image/');
};
</script>

<style lang="scss" scoped>
.mode-selector {
  display: flex;
  justify-content: center;
  margin-bottom: 10px;
}

.mode-selector button {
  margin: 0 5px;
  padding: 5px 10px;
  border: none;
  background: #f0f0f0;
  cursor: pointer;
  transition: background 0.3s;
}

.mode-selector button.active {
  background: #e0e0e0;
  font-weight: bold;
}

.upload-wrapper {
  display: flex;
  flex-direction: column;
  align-items: center;
}

.upload-area {
  position: relative;
  display: flex;
  justify-content: center;
  align-items: center;
  border: 1px dashed #797979;
  border-radius: 8px;
  background-color: #f8f8f8;
  cursor: pointer;
  overflow: hidden;
  padding: 0;
  width: 100%;
  height: 150px;
}

.upload-area.image {
  background-color: #f8f8f8;
}

.upload-area.file {
  background-color: #e0e0e0;
}

.upload-icon {
  color: #a9b0b3;
}

.upload-area:hover .upload-icon {
  color: #f87c30;
}

.input-file {
  display: none;
}

.icon-close {
  position: absolute;
  right: 10px;
  top: 10px;
  cursor: pointer;
  background-color: rgba(255, 255, 255, 0.8);
  border-radius: 50%;
  padding: 5px;
  z-index: 10;
}

.preview-container {
  position: relative;
  width: 100%;
  height: 100%;
  display: flex;
  justify-content: center;
  align-items: center;
  background: #e6e6e6;
}

.preview-container img {
  max-width: 100%;
  max-height: 100%;
}

.file-icon {
  display: flex;
  justify-content: center;
  align-items: center;
  width: 100%;
  height: 100%;
}

.preview-placeholder {
  display: flex;
  justify-content: center;
  align-items: center;
  width: 100%;
  height: 100%;
  background: #f1f1f1;
}
</style>
