<template>
  <Multiselect
      v-model="selectedValues"
      :mode="isMultiple ? 'tags' : 'single'"
      :close-on-select="!isMultiple"
      :placeholder="placeholderText"
      :options="options"
      :searchable="searchable"
  >
    <template v-slot:singlelabel="{ value }">
      <div class="multiselect-single-label">
        <img v-if="value.avatar" class="rounded-circle avatar-xs" :src="value.avatar" alt="" />
        {{ value.name }}
      </div>
    </template>

    <template v-slot:option="{ option }">
      <div class="d-flex gap-3 align-items-center">
        <a v-if="option.avatar" href="javascript: void(0);" class="avatar-group-item">
          <img :src="option.avatar" class="rounded-circle avatar-xs" alt="" />
        </a>
        <div class="d-flex flex-column">
          <h5 class="mb-2">{{ option.name }}</h5>
          <div v-if="option.desc" class="d-flex align-items-center gap-1">
            {{ option.desc }}
          </div>
        </div>
      </div>
    </template>
  </Multiselect>
</template>

<script setup lang="ts">
import { ref, defineProps } from 'vue'

const props = defineProps({
  placeholderText: String,
  options: {
    type: Array as () => Array<{
      name: string
      avatar?: string
      desc?: string
    }>,
    required: true
  },
  searchable: Boolean,
  isMultiple: {
    type: Boolean,
    default: false
  }
})

const selectedValues = ref([]);
</script>

<style lang="css">
.multiselect-single-label img {
  margin-right: 5px;
}

.avatar-group-item img {
  width: 24px;
  height: 24px;
}
.multiselect-wrapper {
  align-items: center !important;
  box-sizing: border-box !important;
  cursor: pointer !important;
  display: flex !important;
  justify-content: flex-end !important;
  margin: 0 auto !important;
  min-height: calc(var(--ms-border-width, 1px)* 2 + var(--ms-font-size, 1rem)* var(--ms-line-height, 1.375) + var(--ms-py, .5rem)* 2);
  outline: none !important;
  position: relative !important;
  width: 100% !important;
  min-height: 100% !important;
  height: auto !important;
}
</style>
