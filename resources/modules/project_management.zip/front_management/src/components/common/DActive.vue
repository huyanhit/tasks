<template>
  <span
    class="badge rounded-pill border"
    :class="active ? 'border-success text-success' : 'border-danger text-danger'"
  >
    {{
      active
        ? $t('setting_system.department_business.status.active')
        : $t('setting_system.department_business.status.inactive')
    }}
  </span>
</template>

<script setup lang="ts">
import { defineProps } from 'vue'

const props = defineProps<{
  active: boolean
}>()
</script>

<style scoped>
/* Add your styles here */
</style>
