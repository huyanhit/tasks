<template>
  <div>
       <span class="badge rounded-pill border me-1" :style="`border-color: ${color} !important; color: ${color};`">
        {{ text }}
      </span>
  </div>
</template>
<script setup lang="ts">
defineProps({
  text: {
    type: String,
    default: ''
  },
  color: {
    type: String,
    default: 'primary'
  }
})
</script>

<style scoped>

</style>