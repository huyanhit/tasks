<template>
  <div class="d-accordion d-accordion-list mb-3" :class="{ 'overflow-none': !overflow }">
    <div class="d-accordion-header">
      <!-- Display content of slot accordion-header if present -->
      <template v-if="$slots['accordion-header']">
        <slot name="accordion-header" />
      </template>
      <template v-else-if="$slots['tabs']">
        <slot name="tabs" />
      </template>
      <template v-else>
        <span>{{ header }}</span>
        <span class="sub-title" v-if="!isVisible">
          {{ subtitle.length > 100 ? subtitle.substring(0, 100) + "..." : subtitle }}
        </span>
      </template>

      <BRow>
        <BCol class="p-0">
          <BButton
            v-if="addNew && !$slots['action-accordion-header']"
            type="button"
            class="btn-light"
            @click="$emit('add')"
          >
            +
          </BButton>
          <template v-else>
            <slot name="action-accordion-header" />
          </template>
        </BCol>
        <BCol class="p-0">
          <BButton type="button" @click="toggleAccordion" class="btn-light">
            <i :class="isVisible ? 'ri-arrow-up-s-line' : 'ri-arrow-down-s-line'"></i>
          </BButton>
        </BCol>
      </BRow>
    </div>
    <div v-show="isVisible" class="accordion">
      <slot />
      <slot name="body-accordion" />
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, defineEmits, defineProps } from "vue";

const isVisible = ref(true);

const toggleAccordion = () => {
  isVisible.value = !isVisible.value;
};

const props = defineProps({
  header: {
    type: String,
    default: "",
  },
  subtitle: {
    type: String,
    default: "",
  },
  addNew: {
    type: Boolean,
    default: false,
  },
  modalId: {
    type: String,
    default: "",
  },
  overflow: {
    type: Boolean,
    default: true,
  },
});

const emit = defineEmits(["add"]);
</script>

<style scoped>
.sub-title {
  font-weight: 500 !important;
  font-style: oblique;
  margin-left: 10px;
  text-align: end;
}
.overflow-none {
  overflow: inherit !important;
}
.d-accordion .d-accordion-header{
  padding-top: 3px;
  padding-bottom: 3px;
}
</style>
