<template>
  <div class="search-bar d-flex align-items-center border bg-white">
    <Icon icon="basil:search-outline" color="#909090" width="30" />
    <BFormInput
      v-model="form.keyword"
      :placeholder="t('common.common.search')"
      class="flex-grow-1 border-0 input-search-header"
      @keydown.enter="emit('filter')"
    ></BFormInput>
    <BButtonGroup v-if="isShowModal" class="d-flex gap-2 align-items-center">
      <BButton @click="modal = !modal" size="sm" class="rounded-pill search-auto" variant="link">
        <Icon icon="mdi:slider" color="#909090" width="20" class="icon-search-header" />
      </BButton>
    </BButtonGroup>
  </div>
  <BModal :title="modalTitle ? modalTitle : t('common.common.search')" v-model="modal">
    <slot v-if="modal" />
    <template #footer="{ cancel }">
      <b-button
        type="submit"
        variant="secondary"
        class="w-sm"
        :disabled="loading"
        @click="
          emit('filter', form);
          cancel();
        "
      >
        <span
          class="spinner-border spinner-border-sm mr-2"
          role="status"
          aria-hidden="true"
          v-show="loading"
        ></span>
        {{ $t("common.form.search") }}
      </b-button>
      <b-button variant="outline-secondary" class="w-sm" @click="reset">
        {{ $t("common.form.resetFilter") }}
      </b-button>
    </template>
  </BModal>
</template>

<script setup lang="ts">
  import { Icon } from "@iconify/vue";
  import { useI18n } from "vue-i18n";
  import { mapValues } from "lodash";

  const { t } = useI18n();
  const props = defineProps({
    modalTitle: {
      type: String,
      default: "",
    },
    isShowModal: {
      type: Boolean,
      default: false,
    },
    modelValue: {
      type: Object,
      required: true,
    },
    loading: {
      type: Boolean,
      default: false,
    },
  });

  const defaultForm = ref(mapValues(props.modelValue, () => null));
  const emit = defineEmits(["filter"]);
  const modal = ref(false);
  const form = defineModel("modelValue", {
    type: Object,
    default: {
      keyword: null,
    },
  });

  const reset = () => {
    form.value = Object.assign({}, defaultForm.value);
    emit("filter");
    modal.value = false;
  };
</script>
