<template>
  <div class="btn btn-sm button btn-form-icon dropdown-toggle dropdown-toggle-no-caret"
    :size="size"
    @click="deleteItem">
    <Icon icon="mdi-delete-outline" width="20" />
    {{ $t('common.form.delete') }}
  </div>
</template>
<script setup lang="ts">
import { defineProps } from 'vue'
import { showConfirm } from '@/helpers/common'
import { useI18n } from 'vue-i18n'
const { t } = useI18n()

interface DeleteButtonProps {
  click: Function;
  size?: string;
  variant?: string;
  deleteConfirm?: string;
  item?: any;
}

const { click, deleteConfirm, item } = withDefaults(
  defineProps<DeleteButtonProps>(), {
    size: 'sm',
    variant: 'danger',
    deleteConfirm: 'common.common.sweetalert.delete_confirm',
    item: null
  }
);

const deleteItem = () => {
  showConfirm({
    html: t(deleteConfirm, [item]),
    confirmButtonColor: '#ca383a',
    cancelButtonColor: '#fff',
    confirmButtonText: t('common.common.sweetalert.delete_button_text'),
    customClass: {
        cancelButton: 'text-black-50 border',
    }
  }).then((result: any) => {
    if (result.isConfirmed) {
      click()
    }
  })
}
</script>
