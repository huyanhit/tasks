<template>
  <BButton
    @click="handleCancel"
    :variant="props.variant"
    :class="['btn', `btn-${props.variant}`, `w-${props.size}`, 'me-1']"
  >
    {{ t(props.name) }}
  </BButton>
</template>

<script setup lang="ts">
import { useI18n } from 'vue-i18n'
interface Props {
  click?: () => void
  size?: string
  name?: string
  variant?: string
}

const props = withDefaults(defineProps<Props>(), {
  size: 'sm',
  name: 'common.form.cancel',
  variant: 'outline-secondary'
})

const emit = defineEmits(['click'])

const { t } = useI18n()

function handleCancel() {
  emit('click')
}
</script>
