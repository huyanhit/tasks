<template>
	<BButton
		type="submit"
		:variant="props.variant"
		:class="['w-' + props.size, 'btn', `btn-${props.variant}`]"
		@click="handleClick"
	>
    <span
	    v-if="loading"
	    class="spinner-border spinner-border-sm mr-2"
	    role="status"
	    aria-hidden="true"
    ></span>
		{{ t(props.name) }}
	</BButton>
</template>

<script setup lang="ts">
import { ref } from 'vue'
import { useI18n } from 'vue-i18n'

interface Props {
	click?: any,	
	size?: string,
	name?: string,
	variant?: string,
}

const props = withDefaults(defineProps<Props>(), {
	size: 'sm',
	name: 'common.form.update',
	variant: 'secondary'
})

const emit = defineEmits(['click'])

const { t } = useI18n()

const loading = ref(false)

function handleClick(event: Event) {
	if (props.click) {
		loading.value = true
		emit('click', event)
		props.click(event).finally(() => {
			loading.value = false
		})
	} else {
		emit('click', event)
	}
}
</script>

<style scoped>
.mr-2 {
	margin-right: 0.5rem;
}
</style>
