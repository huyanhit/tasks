<template>
  <BCol :lg="col" class="checkbox-parent">
    <label v-if="showLabel">{{ label }} <span v-if="required" class="text-danger">*</span></label>
    <Field
      :name="name"
      :label="label"
      class="form-control"
      v-model="modelValue"
      v-slot="{ field }"
      :rules="rules"
    >
      <BFormGroup v-if="options && options.length" v-slot="{ ariaDescribedby }">
         <BFormCheckboxGroup
            :id="id"
            v-model="modelValue"
            :options="options"
            :aria-describedby="ariaDescribedby"
            :value-field="valueField"
            :text-field="textField"
            disabled-field="notEnabled"
            
          />
       
      </BFormGroup>
      <BFormCheckbox v-else inline v-model="modelValue">{{ label }}</BFormCheckbox>
    </Field>
    <ErrorMessage :name="name" class="text-danger text-xs" as="div"/>
  </BCol>
</template>
<script setup lang="ts">
import { ErrorMessage, Field } from 'vee-validate';

const props = defineProps<{
  options?: { text: string; value: string; notEnabled?: boolean }[];
  label?: string;
  id?: string;
  textField?: string;
  valueField?: string;
  col?: number;
  name: string;
  rules?: string;
  showLabel?: boolean;
  required?: boolean;
}>();

const modelValue = defineModel<any>('modelValue');



const {
  name,
} = props;
</script>


<style>
.checkbox-parent .form-check-input:checked {
    background-color: var(--vz-secondary);
    border-color: var(--vz-secondary);
}
.checkbox-parent .form-check-input {
    font-size: 1rem;
}
</style>