<template>
  <BCol :lg="col">
    <div class="form-group cursor-pointer mb-2">
      <div class="position-relative">
        <Field :name="name" :label="label" class="form-control" v-model="value" v-slot="{ field }" :rules="rules">
          <BFormInput
            :label="label"
            v-model="value"
            :type="type"
            v-bind="field"
            :class="className"
            :placeholder="placeholder"
            :readonly="readonly"
            :disabled="disabled"
          />
          <label v-if="!noLabel">{{ label }} <span v-if="required" class="text-danger">*</span></label>
        </Field>
        <Icon class="icon-sp-input" v-if="icon" :icon="icon" width="18" @click="emit('icon-click')"/>
      </div>
      <ErrorMessage :name="name" class="text-danger text-xs" as="div"/>
    </div>
  </BCol>
</template>

<script setup lang="ts">
import {ErrorMessage, Field} from "vee-validate"
import {Icon} from "@iconify/vue";

const emit = defineEmits(['icon-click'])
const props = defineProps({
  col: {
    type: [String, Number],
    default: 12,
  },
  icon: {
    type: String,
    default: ''
  },
  modelValue: {
    type: [String, Number]
  },
  label: {
    type: String,
    default: ''
  },
  placeholder: {
    type: String,
    default: ''
  },
  required: {
    type: Boolean,
    default: false
  },
  name: {
    type: String,
    default: ''
  },
  type: {
    type: String,
    default: 'text'
  },
  noLabel: {
    type: Boolean,
    default: false
  },
  rules: {
    type: [String, Object]
  },
  readonly: {
    type: Boolean,
    default: false
  },
  className: {
    type: String,
    default: ''
  },
  disabled: {
    type: Boolean,
    default: false
  }
})
const value = defineModel('modelValue')
const colorPlaceHolder = ref(props.noLabel ? '#495057' : 'transparent')
</script>
<style scoped lang="scss">
.form-group {
  position: relative;
}

.form-control {
  height: 45px;
  border: 1px solid #ced4da;
  border-radius: 4px;
  color: #495057;
  padding: 0.25rem 0.75rem;
  transition: border-color 0.3s ease-in-out, box-shadow 0.3s ease-in-out;

  &::placeholder {
    color: v-bind(colorPlaceHolder);
  }

  &:focus {
    border-color: var(--color-orange);
    outline: 0;

    & + label {
      color: var(--color-orange);
    }

    &::placeholder {
      color: #495057;
    }
  }

  &:not(:placeholder-shown) + label,
  &:focus + label {
    top: -0.6rem;
    left: 0.75rem;
    font-size: 12px;
    background-color: var(--bg-color);
    padding: 0 0.25rem;
  }
  
  &:disabled {
    &:not(:placeholder-shown) + label,
    &:focus + label {
      background: linear-gradient(0deg, rgba(238,242,249,1) 0%, rgba(238,242,249,1) 49%, rgba(255,255,255,1) 50%, rgba(255,255,255,1) 100%) !important;
    }
  }
}

label {
  position: absolute;
  top: 0.75rem;
  left: 0.75rem;
  color: #495057;
  padding: 0 0.25rem;
  transition: all 0.3s ease-in-out;
  pointer-events: none;
  background-color: transparent;
}

input {
  &[readonly] {
    border-color: var(--color-disable);
    border-style: solid;
    border-width: 1px;
    background-color: var(--bg-disable);
    color: var(--color-disable);

    &:focus {
      background-color: var(--bg-color);
    }
  }

  &.placeholder-right {
    &::placeholder {
      text-align: right;
      direction: rtl;
    }
  }
}

.icon-sp-input {
  position: absolute;
  right: 10px;
  top: 50%;
  transform: translateY(-50%);
  color: #a9b0b3;
}
</style>