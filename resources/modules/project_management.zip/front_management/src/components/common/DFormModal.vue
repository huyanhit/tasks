<template>
  <Form v-if="modal" v-slot="{ handleSubmit }" :initial-values="initialData" >
    <BModal :id="id" v-model="modal" :title v-bind="$attrs" @close="emit('close')" :class="classModal" @shown="emit('shown')">
      <slot />
      <template #footer>
        <b-button
          v-if="!hideSubmit"
          type="submit"
          variant="secondary"
          class="w-sm"
          :disabled="loading"
          @click="handleSubmit(submit)"
        >
          <span class="spinner-border spinner-border-sm mr-2" role="status" aria-hidden="true" v-show="loading" />
          {{ submitText ? submitText : $t('common.form.update') }}
        </b-button>
        <b-button variant="outline-secondary" @click="close">
          {{ cancelText ? cancelText : $t('common.form.cancel') }}
        </b-button>
      </template>
    </BModal>
  </Form>
</template>
<script setup lang="ts">
import {Form} from 'vee-validate'

const emit = defineEmits(['submit', 'close', 'shown'])
defineProps({
  modelValue: {
    type: Boolean,
    default: false
  },
  id: {
    type: String,
    default: ''
  },
  title: {
    type: String,
    default: ''
  },
  submitText: {
    type: String,
    default: ''
  },
  cancelText: {
    type: String,
    default: ''
  },
  hideSubmit: {
    type: Boolean,
    default: false
  },
  loading: {
    type: Boolean,
    default: false
  },
  initialData: {
    type: Object,
    default: () => ({})
  },
  classModal: {
    type: String,
    default: ''
  }
})
const modal = defineModel('modelValue', {type: Boolean});

const submit = (data:any, extra: any) => {
  emit('submit', {data, extra})
}

const close = () => {
  modal.value = false
  emit('close')
}
</script>