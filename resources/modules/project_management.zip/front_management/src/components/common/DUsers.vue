<template>
  <div ref="container" class="d-flex avatar__group"
    :class="showName ? 'flex-wrap gap-2' : ''">
    <div
      v-for="(user, index) in users.slice(0, 2)"
      :key="user.id"
      @mouseover="showTooltip(user)"
      @mouseleave="hideTooltip"
      class="position-relative avatar__group--user"
    >
      <div :ref="(el) => (buttonRefs[user.id] = el as HTMLElement)">
      <DAvatar :size="30" :name="user.name ?? user.username" :url="user.avatar_url" 
          v-bind="{ text: showName ? (user.name ?? user.username) : undefined }"
        />
      </div>
      <BPopover
        :target="buttonRefs[user.id]"
        variant="link"
        triggers="focus"
        teleportTo="body"
        style="min-width: 320px; max-width: 560px"
      >
        <div class="tooltip-content">
          <DAvatar
            :size="60"
            :name="user.name ?? user.username"
            :url="user.avatar_url"
            class="m-lg-2"
          />
          <div class="p-2 text-right">
            <h6>{{ user.name }}</h6>
            <p>{{ user.status }}</p>
            <p v-if="user.address"><i class="ri-map-pin-line fs-16 align-middle me-1"></i> {{ user.address }}</p>
            <p v-if="user.position">
              <i class="ri-building-4-line fs-16 align-middle me-1"></i>
              {{ user.position }}
            </p>
            <div class="d-flex gap-2 mt-2">
              <BButton :href="`/chat/${user.id}`" class="btn waves-effect btn-chat" size="sm">
                <Icon
                  class="mb-1 me-1"
                  icon="material-symbols:chat-bubble-outline-rounded"
                  width="14"
                />
                {{ $t('common.component.d_users.message') }}
              </BButton>
              <BButton
                variant="outline-warning"
                :href="`/employee/detail-profile`"
                class="btn waves-effect btn-profile"
                size="sm"
              >
                <Icon class="mb-1 me-1" icon="material-symbols:person-rounded" width="14" />
                {{ $t('common.component.d_users.personel_record') }}
              </BButton>
            </div>
          </div>
        </div>
      </BPopover>
    </div>
    <div
      v-if="users.length > maxVisibleAvatars"
      class="rounded-circle avatar-xxs d-flex align-items-center justify-content-center cursor-pointer"
      :class="showName ? 'ms-1' : ''"
      @click="showAdditionalTooltip = true"
    >
      {{ updateUserDisplay() }}
    </div>
    <BModal
      v-model="showAdditionalTooltip"
      title="Danh sách người dùng"
      size="md"
      scrollable
      hide-footer
      centered
      class="modal-forum"
    >
      <template #header>
        <div class="d-flex align-items-center justify-content-between w-100">
          <strong>{{ users.length }} {{ $t('common.component.d_users.hr') }}</strong>
          <div class="cursor-pointer d-flex align-items-center gap-2">
            <Icon
              class="me-1 text-secondary"
              icon="ri-wechat-line"
              style="margin-right: 15px"
              width="22"
            />
            <Icon
              class="text-secondary"
              icon="ri-close-line"
              width="24"
              @click="showAdditionalTooltip = false"
            />
          </div>
        </div>
      </template>

      <BCardBody
        v-for="(user, index) in users"
        :key="user.id"
        @mouseover="showTooltip(user)"
        @mouseleave="hideTooltip"
        no-body
        class="p-0"
      >
        <BFormGroup>
          <BRow
            class="align-items-center justify-content-center py-1"
            :style="{ background: index % 2 === 0 ? 'white' : '#e9e9e952' }"
          >
            <BCol xl="2">
              <DAvatar
                :size="50"
                :name="user.name ?? user.username"
                :url="user.avatar_url"
                class="m-lg-3"
              />
            </BCol>
            <BCol>
              <BCardTitle class="mb-1 font-300 text__bg--title">{{ user.name }}</BCardTitle>
              <b-card-text>
                <span>
                  <Icon class="me-1" icon="ri-mind-map" /> Ban Giám đốc ||
                  <Icon class="me-1" icon="bi:person-fill" /> Cố vấn Ban giám đốc
                </span>
              </b-card-text>
            </BCol>
          </BRow>
        </BFormGroup>
      </BCardBody>
    </BModal>
  </div>
</template>

<script lang="ts" setup>
import { ref, computed } from 'vue'

interface User {
  id: string
  name: string
  type: string
  username: string
  avatar_url?: string
  status?: string
  address?: string
  position?: string
  department?: string,
  showName?: string;
}

const props = defineProps({
  users: {
    type: Array as () => User[],
    default: []
  },
  showName: {
    type: Boolean,
    default: false
  }

})
const showAdditionalTooltip = ref(false)
const tooltipUser = ref<User | null>(null)
const container = ref<HTMLElement | null>(null)
const maxVisibleAvatars = 2

const buttonRefs = ref<Record<string, HTMLElement | null>>({})

const updateUserDisplay = () => {
  const totalUsers = props.users.length
  return totalUsers > maxVisibleAvatars ? `+${totalUsers - maxVisibleAvatars}` : ''
}

const showTooltip = (user: User) => {
  if (showAdditionalTooltip.value) return
  tooltipUser.value = user
}

const hideTooltip = () => {
  tooltipUser.value = null
}
</script>

<style scoped lang="scss">
@mixin avatar-size($size) {
  width: $size;
  height: $size;
}

@mixin border-style($borderColor) {
  background-color: white;
  border: 1px solid $borderColor;
}

@mixin button-style($bgColor, $textColor, $hoverBgColor, $hoverTextColor) {
  border-color: $bgColor;
  color: $textColor;
  transition:
    background-color 0.3s,
    color 0.3s;
  border-radius: 20px;

  &:hover {
    background-color: $hoverBgColor;
    color: $hoverTextColor;
    border-color: $bgColor;
  }
}

.popper {
  position: fixed;
}

.avatar__group {
  .avatar-xxs {
    z-index: 3;
    margin-left: -15px;
    @include avatar-size(30px);
    @include border-style(#dee2e6);
  }
}

.tooltip-custom {
  padding: 0.5rem 1rem;
  background-color: #fff;
  border-radius: 0.5rem;
  transition: opacity 0.3s ease;
  box-shadow: 0 0.5rem 1rem rgba(0, 0, 0, 0.15);
  min-width: 320px;
  max-width: 560px;
}

.tooltip-content {
  display: flex;
  align-items: start;
}

.tooltip-avatar {
  @include avatar-size(50px);
  margin-right: 10px;
}

p {
  margin-bottom: 5px;
}

.text__bg--title {
  color: #fb6900;
}

.text-red {
  color: red;
}

.btn-profile {
  @include button-style(#fb6900, #fb6900, #fb6900, white);
}

.btn-chat {
  @include button-style(#fb6900, white, white, #fb6900);
}
</style>
