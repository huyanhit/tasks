<template>
  <div class="avatar-container d-flex align-items-center">
    <div :class="['card-group', { 'card-group-with-text': hasText }]">
      <img
        class="card-img-top rounded-circle"
        :src="avatarUrl"
        alt="Card image cap"
        :style="{ width: size + 'px', height: size + 'px' }"
        @error="onImageError"
      />
      <div class="card-body">
        <p v-if="text" class="card-text fw-bold text-nowrap"
          :class="{ 'pe-2' : text }">
          {{ text }}
        </p>
      </div>
    </div>
  </div>
</template>

<script lang="ts" setup>
import { ref, computed } from 'vue'

const props = defineProps<{
  name: string
  url: string | null | undefined
  size: number
  text?: string // Optional text prop
}>()

const fallbackImage = ref<string>('')

// Function to generate a fallback avatar image using an external service or placeholder image
const generateAvatar = (name: string, size: number): string => {
  const canvas = document.createElement('canvas')
  const context = canvas.getContext('2d')
  if (!context) return ''

  // Set canvas size
  canvas.width = size
  canvas.height = size

  // Fill background with red color
  context.fillStyle = '#eaeaea'
  context.fillRect(0, 0, size, size)

  // Set text style and color
  context.fillStyle = '#000000'
  context.font = `${size / 2}px Arial`
  context.textAlign = 'center'
  context.textBaseline = 'middle'

  // Draw the first letter of the name
  const letter = name.charAt(0).toUpperCase()
  context.fillText(letter, size / 2, size / 2)

  return canvas.toDataURL('image/png')
}

// Computed property for the avatar URL
const avatarUrl = computed(() => {
  return props.url || fallbackImage.value || generateAvatar(props.name, props.size)
})

// Handle image load error
const onImageError = (event: Event) => {
  const img = event.target as HTMLImageElement
  if (props.url) {
    fallbackImage.value = generateAvatar(props.name, props.size)
    img.src = fallbackImage.value
  }
}

// Computed property to determine if the text is present
const hasText = computed(() => {
  return !!props.text
})
</script>

<style scoped lang="scss">
.avatar-group{
  padding-left: 0;
}
.avatar-container {
  display: flex;
  align-items: center;

  .card-group {
    display: flex;
    align-items: center;
    margin-left: -15px;
    // padding-right: .5rem

    &.card-group-with-text {
      margin-left: 0;
      background-color: #faefea;
      border-radius: 30px;
    }

    .card-text {
      margin-left: 0px;
      color: #f4671d;
    }
  }

  .card-img-top {
    border-radius: 50%;
    margin-right: 5px;
    border: 2px solid #ffffff;
    background-color: #fff;
    
    &:hover{
      box-shadow: rgba(100, 100, 111, 0.16) 0px 3px 3px 1px;
    }
  }

  .card-body {
    display: flex;
    flex-direction: column;
    justify-content: center;
    padding: 0;
  }
}

.card-title {
  margin: 0;
}
</style>
