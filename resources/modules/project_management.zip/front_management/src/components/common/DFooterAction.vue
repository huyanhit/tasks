<template>
    <div class="footer_action">
        <slot></slot>
    </div>
</template>
