<template>
	<div class="d-flex align-items-center justify-content-between breadcrumb w-md-100">
		<ul class="nav nav-tabs-custom border-0" role="tablist">
			<b-tabs
				v-model="activeTab"
				class="nav nav-tabs-custom border-0 border-white"
				nav-class="border-0 p-0"
				active-nav-item-class="bg-transparent"
			>
				<b-tab
					v-for="(tab, index) in tabs"
					:key="index"
					:title="$t(tab.label) + (tab.count !== undefined ? ` (${tab.count})` : '')"
					@click="props.changeTab && props.changeTab(index)"
				>
				</b-tab>
			</b-tabs>
		</ul>
	</div>
</template>

<script setup lang="ts">
import { defineProps, PropType } from 'vue'
import { defineModel } from 'vue'

const activeTab = defineModel()

const props = defineProps({
  tabs: {
    type: Array as PropType<Array<{ label: string, count?: number }>>,
    required: true
  },
  changeTab: {
    type: Function,
    required: false
  }
})
</script>

