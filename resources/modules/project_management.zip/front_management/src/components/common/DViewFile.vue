<template>
    <BModal 
            v-model="showFileModal"
            :title="fileModalTitle"
            ok-title="Đóng"
            @ok="closeFileModal"
            centered
            class="modal-forum full-modal"
            content-class="vh-100"
            fullscreen
            hide-footer
            >
            <template #header>
                <div class="d-flex align-items-center justify-content-between w-100">
                    <strong v-if="selectedFile && isImage(selectedFile)">{{ fileModalTitle }}</strong>
                    <div v-if="selectedFile && !isImage(selectedFile) && !isMedia(selectedFile)" class="d-flex" >
                        <div alt="Google Icon" data-bs-toggle="tooltip" data-bs-placement="top" title="Google View" @click=" toggleTool() , isGoogleView =!isGoogleView" >
                            <Icon icon="ri:google-fill" class="icon" :color="isGoogleView ? '#fb6900' : '#cfcfcf'" />
                        </div>
                        <div alt="Microsoft Icon" data-bs-toggle="tooltip" data-bs-placement="top" title="Microsoft View" @click="toggleTool() , isMicrosoftView =!isMicrosoftView" >
                            <Icon icon="ri:windows-fill" class="icon" :color="isMicrosoftView ? '#fb6900' : '#cfcfcf'" />
                        </div>
                        <div alt="Download Icon" data-bs-toggle="tooltip" data-bs-placement="top" title="Download">
                            <Icon icon="ri:download-cloud-2-line" class="icon btn-success"  />
                        </div>
                        <div alt="Print Icon" data-bs-toggle="tooltip" data-bs-placement="top" title="Print" >
                            <Icon icon="ri:printer-cloud-line" class="icon btn-success"  />
                        </div>
                    </div>
                   <Icon  class="btn-close" icon="ri:close-line" width="24"  @click="closeFileModal" />
                </div>
            </template>
            <template v-if="selectedFile && isImage(selectedFile)">
            <div class="d-flex justify-content-center align-items-center" style="height: 100%">
                        <img :src="url"
                            @wheel.prevent="resizeImage($event.deltaY)"
                            :style="{ transform: `scale(${scale})`, 'max-height': '100%', 'max-width': '100%',}"
                            ref="messageImage"
                            class="modal-image" />
                    </div>
              <div class="btn-group position-absolute" style="top: 20px; right: 20px">
                        <button class="btn btn-outline-secondary" @click.prevent="resizeImage(-100)"><i class="ri ri-zoom-out-line"></i></button>
                        <button class="btn btn-outline-secondary" @click.prevent="resizeImage(100)"><i class="ri ri-zoom-in-line"></i></button>
                        <button class="btn btn-outline-secondary" @click.prevent="toggleImageSize"><i class="ri ri-fullscreen-line"></i></button>
                    </div>
            </template>
      
            <template v-if="selectedFile && !isImage(selectedFile) && !isMedia(selectedFile)">
                <iframe
                v-if="isGoogleView"
                :src="`https://docs.google.com/viewer?url=${url}&embedded=true`"
                width="100%"
                height="100%"
                frameborder="0"
                ></iframe>
                <iframe
                v-if="isMicrosoftView"
                :src="`https://view.officeapps.live.com/op/embed.aspx?src=${url}`"
                width="100%"
                height="100%"
                frameborder="0"
                ></iframe>
            </template>
            <template v-if="selectedFile && isMedia(selectedFile)">
              <iframe
                :src="url"
                width="100%"
                height="100%"
                frameborder="0"
                allow='autoplay'
                >
              </iframe>
            </template>
            </BModal>
</template>
<script lang="ts" setup>

const emit = defineEmits(['closeModal'])

interface Item {
id: number;
name: string;
type: boolean;
capacity?: number; // Dung lượng (byte)
extension: string; // Định dạng
}
const showFileModal = ref(false);
const fileModalTitle = ref('');
const isGoogleView = ref(false);
const isMicrosoftView = ref(true);
const props = defineProps<{
selectedFile?: Item;
url: string;
}>();

const closeFileModal = () => {
showFileModal.value = false;
emit('closeModal')
};

const scale = ref(1);
const isModalImage = ref(false);

const resizeImage = (deltaY: number) => {
const img = document.querySelector('.modal-image') as HTMLImageElement;
if (!img) return;
const newScale = scale.value + deltaY * 0.001;
scale.value = Math.max(0.1, newScale); // Prevents the image from being too small
img.style.transform = `scale(${scale.value})`;
};

const toggleImageSize = () => {
isModalImage.value = !isModalImage.value;
const img = document.querySelector('.modal-image') as HTMLImageElement;
if (!img) return;
scale.value = isModalImage.value ? (img.naturalWidth / img.width) : 1;
img.style.transform = `scale(${scale.value})`;
};

const toggleTool = () => {
isGoogleView.value = isMicrosoftView.value = false;
}


const isImage = (item: Item) => {
return ["jpg", "jpeg", "png", "gif", "bmp", "tiff"].includes(item.extension);
};

const isMedia = (item: Item) => {
return ['mp4', 'mp3'].includes(item.extension)
}


</script>

<style scoped>

.icon {
cursor: pointer;
font-size: 30px;
padding: 5px;
}
</style>
