<template>
<div>{{ label }}</div>
  <div class="py-2 image-container text-center">
    <img v-if="images"
        :key="images.id"
        :src="images.url"
        :alt="images.name"
        class="image-thumbnail"
        @click="openModal(images)"
      />
    <div v-else class="no-images">{{ t('common.common.no_images') }}</div>
  </div>

  <detail-document ref="detailDocument" :callAPi="callAPi"/>
</template>

<script lang="ts" setup>
import { ref } from 'vue';
import { useI18n } from 'vue-i18n';
import DetailDocument from "@/components/module/document/modals/DetailDocument.vue"
import { Attachment } from '@/modules/document/models/document-attachment';

const detailDocument = ref<InstanceType<typeof DetailDocument> | null>(null);
interface Image {
  id?: number | string;
  url?: string;
  name?: string;
}

const { t } = useI18n();

const props = defineProps({
  images: {
    type: Object as () => Image,
    required: true,
  },
  label: {
    type: String,
    required: false,
    default: '',
    },
  callAPi: {
    type: Boolean,
    default: true
  } 
})
const openModal = (image: Image) => {
  const attachment: Attachment = {
    id: image.id ?? 0,
    name: image.name ?? '',
    type: '',
    extension: 'jpg',
    capacity: '',
    thumbnail_url: image.url ?? '',
    viewer: '',
    created_at: '',
  };
  detailDocument.value?.openModal(attachment);
};
</script>

<style scoped>
.image-thumbnail {
  max-width: 100%;
  cursor: pointer;
  border: 1px solid #ccc;
  border-radius: 4px;
  margin: 0 auto;
}

.no-images {
  text-align: center;
  color: #999;
}
</style>
