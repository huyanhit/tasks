<template>
  <BCol class="d-date-picker" :lg="col">
    <div class="form-group cursor-pointer mb-2">
      <div class="position-relative">
        <Field :name="name" :label="label" class="form-control" v-model="modelValue" v-slot="{ field }" :rules="rules">
          <Flatpickr
            v-model="modelValue"
            class="form-control flatpickr-input"
            :config="config"
            :id="fieldId"
            :name="name"
            :disabled="disabled"
            :required="required"
            :placeholder="placeholder"
            :class="icon ? 'box-input' : ''"
          />
          <label v-if="!noLabel">{{ label }} <span v-if="required" class="text-danger">*</span></label>
        </Field>
        <Icon class="icon-sp-input" v-if="icon" :icon="icon" width="18"></Icon>
      </div>
      <ErrorMessage :name="name" class="text-danger text-xs" as="div"/>
    </div>
  </BCol>
</template>

<script setup lang="ts">
import {ErrorMessage, Field} from "vee-validate";
import Flatpickr from 'vue-flatpickr-component';

const props = defineProps({
  icon: {
    type: String,
    default: ''
  },
  col: {
    type: [String, Number],
    default: 12
  },
  fieldId: {
    type: String,
    default: ''
  },
  label: {
    type: String,
    default: ''
  },
  placeholder: {
    type: String,
    default: ''
  },
  required: {
    type: Boolean,
    default: false
  },
  name: {
    type: String,
    default: ''
  },
  config: {
    type: Object,
    default: () => ({})
  },
  noLabel: {
    type: Boolean,
    default: false
  },
  disabled: {
    type: Boolean,
    default: false
  },
  rules: {
    type: [String, Object]
  }
})
const modelValue = defineModel<string>('modelValue');

const colorPlaceHolder = ref(props.noLabel ? '#495057' : 'transparent')

</script>

<style scoped lang="scss">
.form-group {
  position: relative;
}

.form-control {
  height: 45px;
  border: 1px solid #ced4da;
  border-radius: 4px;
  color: #495057;
  padding: 0.25rem 0.75rem;
  transition: border-color 0.3s ease-in-out, box-shadow 0.3s ease-in-out;

  &:focus {
    border-color: var(--color-orange);
    outline: 0;

    & + label {
      color: var(--color-orange);
    }

    &::placeholder {
      color: #495057;
    }
  }

  &:not(:placeholder-shown) + label,
  &:focus + label {
    top: -0.6rem;
    left: 0.75rem;
    font-size: 12px;
    background-color: #fff;
    padding: 0 0.25rem;
  }

  &:disabled {
      background-color: var(--vz-tertiary-bg) !important;
  }
}

label {
  position: absolute;
  top: 0.75rem;
  left: 0.75rem;
  color: #495057;
  padding: 0 0.25rem;
  transition: all 0.3s ease-in-out;
  pointer-events: none;
  background-color: transparent;
}

.form-control::placeholder {
  color: v-bind(colorPlaceHolder);
}

input.form-control:read-only {
  background-color: white;
}

</style>