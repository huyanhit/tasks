<template>
  <BCol :lg="col">
  <div class="form-group cursor-pointer d-autocomplete mb-2">
   <div class=" position-relative">
    <Field :name="name" :label="label" v-model="value" v-slot="{ field }" :rules="rules">
      <Multiselect
        :mode="mode"
        v-model="value"
        v-bind="field"
        :value-prop="valueProp"
        :label="labelProp"
        :placeholder="placeholder"
        close-on-select
        :min-chars="1"
        :delay="300"
        can-clear
        :searchable="searchable"
        class="form-control shadow-none"
        :class="icon ? 'box-input' : ''"
        :options="options"
        :appendToBody="true"
        filter-results
        @focusout="validate"
        @input="handleChange"
        @close="emit('close')"
      >
        <template v-for="(slotContent, slotName) in $slots" :key="slotName" v-slot:[slotName]="slotProps">
          <slot :name="slotName" v-bind="slotProps"></slot>
        </template>
      </Multiselect>
      <label v-if="!noLabel">{{ label }} <span v-if="required" class="text-danger">*</span></label>
    </Field>
     <Icon class="icon-sp-input" v-if="icon" :icon="icon" width="18"></Icon>
      </div>
    <ErrorMessage :name="name" class="text-danger text-xs" as="div"/>
  </div>
  </BCol>
</template>

<script setup lang="ts">
import {ErrorMessage, Field, useField} from "vee-validate";

const props = defineProps({
  icon: {
    type: String,
    default: ''
  },
  col: {
    type: [Number, String],
    default: 12,
  },
  modelValue: {
    type: [String,Number, Array],
    required: false
  },
  label: {
    type: String,
    default: ''
  },
  placeholder: {
    type: String,
    default: ''
  },
  required: {
    type: Boolean,
    default: false
  },
  name: {
    type: String,
    default: ''
  },
  noLabel: {
    type: Boolean,
    default: false
  },
  valueProp: {
    type: String,
    default: 'id'
  },
  labelProp: {
    type: String,
    default: 'name'
  },
  mode: {
    type: String,
    default: 'single'
  },
  options: {
    type: [Array, Object, Function],
    required: false,
    default: () => ([])
  },
  rules: {
    type: [String, Object]
  },
  searchable: {
    type: Boolean,
    default: false
  }
})
const { validate } = useField(props.name)
const emit = defineEmits(['input', 'change', 'close'])
const value = defineModel('modelValue')
const colorPlaceHolder = ref(props.noLabel ? '#495057' : 'transparent')
const handleChange = (newValue: any) => {
  value.value = newValue;
  emit('input', newValue);
  emit('change', newValue);
};
</script>

<style  lang="scss">
.multiselect.form-control {
  display: flex;
}
.form-group {
  position: relative;
}
.icon-sp-input {
  position: absolute;
  right: 10px;
  top: 50%;
  transform: translateY(-50%);
  color: #a9b0b3;
}
.box-input{
  padding-right: 2rem !important;
}
.d-autocomplete {
  .form-control {
    min-height: 45px;
    border: 1px solid #ced4da;
    border-radius: 4px;
    padding: 0.25rem 0.75rem;
    transition: border-color 0.3s ease-in-out, box-shadow 0.3s ease-in-out;

    &:focus-within {
      border-color: var(--color-orange);
      outline: 0;
    }

    &:focus-within + label {
      color: var(--color-orange);
    }

    &:focus-within + label,
    &:has(.multiselect-single-label) + label,
    &:has(.multiselect-tag) + label,
    .multiselect-search:not(:placeholder-shown) + label {
      top: -0.6rem;
      left: 0.75rem;
      font-size: 12px;
      background-color: #fff;
      padding: 0 0.25rem;
    }
  }
.multiselect-wrapper {
  min-height: auto !important;
}
  label {
    position: absolute;
    top: 0.75rem;
    left: 0.75rem;
    color: #495057;
    padding: 0 0.25rem;
    transition: all 0.3s ease-in-out;
    pointer-events: none;
    background-color: transparent;
  }

  .multiselect-placeholder {
    color: v-bind(colorPlaceHolder);
  }

  .multiselect-search,
  .multiselect-placeholder,
  .multiselect-single-label {
    padding-left: 0 !important;
  }

  .multiselect-search:focus-within + .multiselect-placeholder {
    color: #495057;
  }
}
.multiselect-option.is-selected,.multiselect-option.is-selected.is-pointed,.multiselect-option:hover {
    background: #0000000a !important;
    color: #000 !important;
}
</style>