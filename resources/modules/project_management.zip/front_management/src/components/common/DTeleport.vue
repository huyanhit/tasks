<template>
    <Teleport :to="to" v-if="mounted">
        <slot></slot>
    </Teleport>
</template>;
<script setup>
import { ref, onMounted } from 'vue'
const props = defineProps({
    to: {
        type: String,
        required: true
    }
});
const mounted = ref(false);
onMounted(() => {
    mounted.value = true;
});
</script>
