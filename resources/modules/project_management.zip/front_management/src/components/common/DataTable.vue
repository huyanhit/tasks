<template>
  <b-overlay :show="loading" rounded="sm" spinner-variant="secondary">
    <div v-if="data.length" class="tab-content text-muted">
      <table class="table table-responsive table-hover table-nowrap dataTable table_list w-100 table-layout-fixed">
        <thead class="table-light">
        <tr>
          <th v-if="isShowCheckbox" class="td_checkbox text-center">
            <BFormCheckbox v-model="check" :checked="isCheckedAll()" @click="checkedAll"/>
          </th>
          <th v-if="isShowIndex" class="text-center">
            <span>#</span>
          </th>
          <th v-for="(header, index) in headers" :key="index"
              class="position-relative"
              :class="[getSortingClass(header.value, header.sortable), `text-${header.align}`, 'text-wrap text-break']"
              @click.prevent="sortBy(header.value, header.sortable)"
              :style="{ width: header.width, maxWidth: header.maxWidth, minWidth: header.minWidth }"
          >
            <template v-if="$slots[`header.${header.value}`]">
              <slot :name="`header.${header.value}`" :header="header"/>
            </template>
            <span v-else>{{ header.text }}</span>
          </th>
        </tr>
        </thead>
        <tbody>
        <template v-if="$slots['body']">
          <slot name="body" :items="data" :headers="headers" :isShowIndex="isShowIndex" :isShowCheckbox="isShowCheckbox" :selected="selectedCheckbox" :checkedAll="check"/>
        </template>
        <template v-else>
          <tr v-for="(item, rowIndex) in data" :key="rowIndex"
              @contextmenu.prevent.stop="emit('openMenu', {$event, item})">
            <td v-if="isShowCheckbox" class="td_checkbox">
              <BFormCheckbox :value="item[checkBoxValue]" v-model="selectedCheckbox" :key="rowIndex"/>
            </td>
            <td v-if="isShowIndex">{{ rowIndex + 1 }}</td>
            <td v-for="(header, cellIndex) in headers" :key="cellIndex"
                :class="`text-${header.align} font-text`"
                :style="{ width: header.width, maxWidth: header.maxWidth, minWidth: header.minWidth }"
            >
              <template v-if="$slots[`item.${header.value}`]">
                <slot :name="`item.${header.value}`" :header="header" :item="item" :index="rowIndex"/>
              </template>
              <span v-else> {{ item[header.value] }}</span>
            </td>
          </tr>
        </template>
        </tbody>
      </table>
      <DPagination
        v-if="!hidePagination"
        v-model="paramsTable"
        :hide-per-page="hidePerPage"
        :total-pages="totalPages"
        :hide-page="hidePage"
        @change="changePagination"
      />
    </div>
    <div v-else class="text-center py-3">
      <img src="/src/assets/images/svg/record.svg" class="me-2" alt="no-data">
      {{ $t('common.common.no_result') }}
    </div>
  </b-overlay>
</template>

<script setup lang="ts">
import TableHeader from '@/modules/setting_project/models/table'
import DPagination from "@/components/common/DPagination.vue"

const props = defineProps({
  headers: {
    type: Array<TableHeader>,
    default: () => []
  },
  data: {
    type: Array<any>,
    default: () => []
  },
  selected: {
    type: Array,
    default: () => []
  },
  isShowCheckbox: {
    type: Boolean,
    default: false
  },
  checkBoxValue: {
    type: String,
    default: 'id'
  },
  isShowIndex: {
    type: Boolean,
    default: false
  },
  params: {
    type: Object,
    default: () => ({})
  },
  totalPages: {
    type: Number,
    default: 1
  },
  hidePerPage: {
    type: Boolean,
    default: false
  },
  hidePage: {
    type: Boolean,
    default: false
  },
  hidePagination: {
    type: Boolean,
    default: false
  },
  loading: {
    type: Boolean,
    default: false
  },
  checkboxValues: {
    type: Array,
    default: () => []
  }
})

const emit = defineEmits(['openMenu'])

const paramsTable = defineModel('params', {
    type: Object,
    default: () => ({
        page: 1,
        per_page: 15,
        sort: '',
        order_by: 'asc'
    })
})

// Handle checkbox
const selectedCheckbox = defineModel('selected', {
    type: Array,
    default: () => []
})

const check = ref(false)
const isCheckedAll = () => {
    let allCheckboxData = props.checkboxValues.length > 0
        ? props.checkboxValues
        : props.data

    return props.data.length > 0 && allCheckboxData.every(row => selectedCheckbox.value.includes(row[props.checkBoxValue]))
}

const checkedAll = () => {
    check.value = !check.value
    if (!check.value) {
        selectedCheckbox.value = []
    } else {
        selectedCheckbox.value = props.data.map(row => row[props.checkBoxValue])
    }
}

const sortBy = (key: string, canSort: boolean) => {
    if (canSort) {
        if (paramsTable.value.sort === key) {
            paramsTable.value.order_by = paramsTable.value.order_by === 'asc' ? 'desc' : 'asc';
        } else {
            paramsTable.value.sort = key;
            paramsTable.value.order_by = 'asc';
        }
    } else {
        paramsTable.value.sort = null;
        paramsTable.value.order_by = null;
    }
};

const getSortingClass = (key: string, canSort: boolean) => {
    let classSort = '';
    if (canSort) {
        classSort = 'sorting';
    }

    if (paramsTable.value.sort === key) {
        classSort = `${classSort}  ${paramsTable.value.order_by === 'asc' ? 'sorting_asc' : 'sorting_desc'}`;
    }

    return classSort;
};

const changePagination = (payload: any) => {
    if (payload.page) {
        paramsTable.value.page = payload.page
    }
    if (payload.per_page) {
        paramsTable.value.per_page = payload.per_page
    }
}

const getTextClass = (header: TableHeader) => {
  return (header.width || header.maxWidth || header.minWidth) ? 'text-wrap text-break' : '';
}

const getWidthStyle = (header: TableHeader) => {
  const count = props.headers.length
  return {
    width: header.width ? header.width : `${100 / count}%`,
    maxWidth: header.maxWidth ? header.maxWidth : `${100 / count}%`,
    minWidth: header.minWidth ? header.minWidth : `${100 / count}%`
  }
}
</script>

<style lang="css">
.table-responsive-container {
    overflow-x: auto;
    /* Enables horizontal scrolling */
}

.table.table-responsive {
    min-width: 100%;
    width: 1000px;
}

.table thead th {
    white-space: nowrap;
}

.table tbody td {
    white-space: nowrap;
}
</style>