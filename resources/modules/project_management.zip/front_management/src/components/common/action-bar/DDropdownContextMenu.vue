<template>
  <div class="d-flex align-items-center btn btn-sm btn-link dropdown-toggle dropdown-toggle-no-caret"
    @click="handleDropdownClick($event)">
      <div class="button btn-form-icon">
        <i :class="dropdownData.icon" class="icon-tag"></i>
        <div class="action-label">{{ dropdownData.label }}</div>
      </div>
  </div>
</template>

<script lang="ts" setup>
import { defineProps } from 'vue';
import ContextMenu from '@imengyu/vue3-context-menu';

const props = defineProps({
  dropdownData: {
    type: Object as () => {
      id: string;
      label: string;
      href?: string;
      icon?: string;
      children?: Array<{ id: string; label: string }>
      item: Array<{
        label: string;
        onClick?: () => void;
        children?: Array<{ label: string }>
      }>[]
    },
    required: true
  },
});

function handleDropdownClick(e: MouseEvent) {
  e.preventDefault();
  ContextMenu.showContextMenu({
    x: e.clientX,
    y: e.clientY,
    items: props.dropdownData.item.flat()
  });
}
</script>
