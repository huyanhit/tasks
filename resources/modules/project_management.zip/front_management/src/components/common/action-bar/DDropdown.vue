<template>
  <div v-if="dropdownData.length > 0" class="d-flex align-items-center">
    <div v-for="item in dropdownData" :key="item.id" class="btn-sm btn-link gap-2">
      <!-- Conditional rendering based on the type -->
      <template v-if="item.type === 'link'">
        <a
          :href="item.href"
          class="button btn-form-icon"
          @click="$emit('clickItem', item)"
        >
          <i :class="item.icon" class="icon-tag"></i>
          <div class="action-label">{{ $t(item.label) }}</div>
        </a>
      </template>

      <template v-else-if="item.type === 'modal'">
        <span
          @click="$emit('clickItem', item)"
          class="button btn-form-icon"
          variant="link"
        >
          <i :class="item.icon" class="icon-tag"></i>
          <div class="action-label">{{ $t(item.label) }}</div>
        </span>
      </template>

      <template v-else>
        <BDropdown
          :key="item.id"
          no-caret
          offset="8"
          size="sm"
          class="action_dropdown_custom"
          variant="link"
        >
          <template #button-content>
            <span class="button btn-form-icon">
              <i :class="item.icon" class="icon-tag"></i>
              <div class="action-label">{{ $t(item.label) }}</div>
            </span>
          </template>

          <div v-if="item.child?.length">
            <template
              v-for="child in item.child"
              :key="child.id"
              class="rounded-pill bg_content"
            >
              <BDropdownDivider v-if="child.footer" />
              <BDropdownItem @click="$emit('clickItem', child)">{{
                $t(child.title)
              }}</BDropdownItem>
            </template>
          </div>
        </BDropdown>
      </template>
    </div>
  </div>
</template>

<script setup lang="ts">
import { defineProps } from "vue";

const props = defineProps({
  dropdownData: {
    type: Array as () => Array<{
      id: string;
      label: string;
      href?: string;
      type?: string;
      icon: string;
      child?: Array<{ id: string; title: string; footer?: boolean }>;
    }>,
    required: true,
  },
});
</script>

<style scoped>
.action_dropdown_custom .dropdown-item {
  padding: 8px 17px;
}
</style>
