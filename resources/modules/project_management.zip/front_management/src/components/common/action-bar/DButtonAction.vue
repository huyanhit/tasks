<template>
  <div class="d-flex align-items-center" v-if="buttonData.length > 0">
    <BButton
      v-for="item in buttonData"
      :key="item.id"
      no-caret
      offset="8"
      size="sm"
      class="action_button_custom"
      variant="link"
      @click="item.type === 'event' ? item.click() : router.push(item.href)"
    >
      <div class="button btn-form-icon">
        <i :id="item.id" :class="item.icon"></i>
        <div :id="item.idLabel" class="action-label">{{ item.label }}</div>
      </div>
    </BButton>
  </div>
</template>

<script lang="ts" setup>
import { defineProps } from 'vue'
import { useRouter } from 'vue-router'; 

const router = useRouter();
const props = defineProps({
  buttonData: {
    type: Array as () => Array<{
      id: string
      idLabel: string
      label: string
      type: string
      href?: string
      icon: string
      click: any
    }>,
    required: true
  }
})
</script>
