<template>
    <div v-if="dropdownData.length > 0" class="d-flex">
        <BDropdown v-for="item in dropdownData" :key="item.id" no-caret offset="8" size="sm" class='action_dropdown_custom' variant="link"
            @shown="$emit('showDropdownCheckBox')">
	        <template #button-content>
						<span class="button btn-form-icon">
							<i :class="item.icon" class="icon-tag"></i>
							<div class="action-label">{{ $t(item.label) }}</div>
						</span>
	        </template>

            <div v-if="item.child?.length" @click.stop>
                <simplebar class='simplebar_dropdown' style="max-height: 300px;">
                    <template v-for="child in item.child" :key="child.id" class="rounded-pill bg_content">
                        <div id="actionBar" class="select-container">
                            <div class="inner-container">
                                <div class="list list-menu">
                                    <a class="list-item">
                                        <div class="list-item-link">
                                            <div class="title">
                                                <b-form-group class="d-flex checkbox-actionbar">
                                                    <b-form-checkbox v-model="child.check">
                                                        {{ $t(child.title)}}
                                                    </b-form-checkbox>
                                                </b-form-group>
                                            </div>
                                        </div>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </template>
                </simplebar>
                <hr />
                <BFormGroup alignSelf="center" class="text-center mb-2">
                    <BButtonGroup class="btn btn-sm btn-check-form-click" @click="$emit('apply', item)">
                        {{ $t('common.action_bar.filter_by_selected_label') }}
                    </BButtonGroup>
                </BFormGroup>
            </div>
            <div v-else style="min-width: 250px" class="p-3 text-center">
                <span class="spinner-border spinner-border-sm p3" role="status" aria-hidden="true"></span>
            </div>
        </BDropdown>
    </div>
</template>

<script lang="ts" setup>
import { defineProps } from 'vue'
const props = defineProps({
    visible: {
        type: Boolean,
        default: false
    },
    dropdownData: {
        type: Array as () => Array<{
            id: string
            label: string
            href?: string
            child?: Array<{ id: string; title: string; footer?: boolean }>
        }>,
        required: true
    }
})
</script>

<style lang="css">
.simplebar_dropdown .simplebar-content-wrapper {
    display: grid !important;
    justify-content: space-around;
    justify-items: center;
}

</style>
