<template>
  <div class="form-group cursor-pointer mb-2">
    <Field :name="name" :label="label" class="form-control" v-model="value" v-slot="{ field }">
        <BFormInput
          :label="label"
          v-model="value"
          :type="hidePassword ? 'password' : 'text'"
          v-bind="field"
          :placeholder="placeholder"
        />
        <div class="position-absolute top-50 end-0 translate-middle-y px-3 py-2"  @click="hidePassword = !hidePassword">
          <Icon :icon="hidePassword ? 'ri-eye-off-fill' : 'ri-eye-fill'" />
        </div>
      <label v-if="!noLabel">{{ label }} <span v-if="required" class="text-danger">*</span></label>
    </Field>
    <ErrorMessage :name="name" class="text-danger text-xs" as="div"/>
  </div>
</template>

<script setup lang="ts">
import {ErrorMessage, Field} from "vee-validate";
import {Icon} from "@iconify/vue";

const props = defineProps({
  modelValue: {
    type: [String, Number],
    required: true
  },
  label: {
    type: String,
    default: ''
  },
  placeholder: {
    type: String,
    default: ''
  },
  required: {
    type: Boolean,
    default: false
  },
  name: {
    type: String,
    default: ''
  },
  noLabel: {
    type: Boolean,
    default: false
  }
})
const value = defineModel('modelValue')
const hidePassword = ref(true)
const colorPlaceHolder = ref(props.noLabel ? '#495057' : 'transparent')
</script>

<style scoped lang="scss">
.form-group {
  position: relative;
}

.form-control {
  height: 45px;
  border: 1px solid #ced4da;
  border-radius: 4px;
  color: #495057;
  padding: 0.25rem 0.75rem;
  transition: border-color 0.3s ease-in-out, box-shadow 0.3s ease-in-out;

  &:focus {
    border-color: var(--color-orange);
    outline: 0;

    & + label {
      color: var(--color-orange);
    }

    &::placeholder {
      color: #495057;
    }
  }

  &:not(:placeholder-shown) + label,
  &:focus + label {
    top: -0.6rem;
    left: 0.75rem;
    font-size: 12px;
    background-color: #fff;
    padding: 0 0.25rem;
  }
}

label {
  position: absolute;
  top: 0.75rem;
  left: 0.75rem;
  color: #495057;
  padding: 0 0.25rem;
  transition: all 0.3s ease-in-out;
  pointer-events: none;
  background-color: transparent;
}

.form-control::placeholder {
  color: v-bind(colorPlaceHolder);
}
</style>