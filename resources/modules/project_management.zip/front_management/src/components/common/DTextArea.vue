<template>
  <BCol :lg="col">
    <div class="form-group cursor-pointer mb-2">
      <Field :name="name" :label="label" class="form-control" v-model="value" v-slot="{ field }">
        <BFormTextarea
          :label="label"
          v-model="value"
          :type="type"
          v-bind="field"
          :rows="rows"
          :placeholder="placeholder"
        />
        <label v-if="!noLabel">{{ label }} <span v-if="required" class="text-danger">*</span></label>
      </Field>
      <ErrorMessage :name="name" class="text-danger text-xs" as="div"/>
    </div>
  </BCol>
</template>

<script setup lang="ts">
import { ErrorMessage, Field } from "vee-validate";

const props = defineProps({
  modelValue: {
    type: [String,Number],
    required: true
  },
  label: {
    type: String,
    default: ''
  },
  placeholder: {
    type: String,
    default: ''
  },
  required: {
    type: Boolean,
    default: false
  },
  name: {
    type: String,
    default: ''
  },
  type: {
    type: String,
    default: 'text'
  },
  noLabel: {
    type: Boolean,
    default: false
  },
  rows: {
    type: [Number, String],
    default: 3
  }
})
const value = defineModel('modelValue')
const colorPlaceHolder = ref(props.noLabel ? '#495057': 'transparent')
</script>

<style scoped lang="scss">
.form-group {
  position: relative;
}

.form-control {
  min-height: 45px;
  border: 1px solid #ced4da;
  border-radius: 4px;
  color: #495057;
  padding: 0.25rem 0.75rem;
  transition: border-color 0.3s ease-in-out, box-shadow 0.3s ease-in-out;

  &:focus {
    border-color: var(--color-orange);
    outline: 0;

    & + label {
      color: var(--color-orange);
    }

    &::placeholder {
      color: #495057;
    }
  }

  &:not(:placeholder-shown) + label,
  &:focus + label {
    top: -0.6rem;
    left: 0.75rem;
    font-size: 12px;
    background-color: #fff;
    padding: 0 0.25rem;
  }
  
  &:disabled {
    &:not(:placeholder-shown) + label,
    &:focus + label {
      background: linear-gradient(0deg, rgba(238,242,249,1) 0%, rgba(238,242,249,1) 49%, rgba(255,255,255,1) 50%, rgba(255,255,255,1) 100%) !important;
    }
  }
}

label {
  position: absolute;
  top: 0.75rem;
  left: 0.75rem;
  color: #495057;
  padding: 0 0.25rem;
  transition: all 0.3s ease-in-out;
  pointer-events: none;
  background-color: transparent;
}

.form-control::placeholder {
  color: v-bind(colorPlaceHolder);
}

</style>