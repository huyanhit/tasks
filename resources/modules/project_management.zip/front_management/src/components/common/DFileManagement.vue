<template>
  <div class="p-2">
    <template v-if="typeView === 'group'">
      <div v-if="initialItems?.some((e) => e.type === 'folder')" class="title-head">{{ t('document.document.type.folder') }}</div>
      <div class="grid-view">
        <attachment-card
          v-for="item in initialItems?.filter((e) => e.type === 'folder')"
          :key="item.id" :item="item"
          @click="emit('load-current', item)"
          @update="updateData"
        />
      </div>
      <div v-if="initialItems?.some((e) => e.type !== 'folder')" class="title-head">{{ t('document.document.type.file') }}</div>
      <div class="grid-view">
        <attachment-card
          v-for="item in initialItems?.filter((e) => e.type !== 'folder')"
          :key="item.id" :item="item"
          @click="viewFile(item)"
          @update="updateData"
        />
      </div>
    </template>
    <template v-else-if="typeView === 'list'">
      <attachment-table :data="initialItems" @update="updateData" @open="open"/>
    </template>
    <template v-else>
      <div v-if="initialItems?.length" class="title-head">{{ t('common.common.all') }}</div>
      <div class="grid-view">
        <attachment-card
          v-for="item in initialItems"
          :key="item.id" :item="item"
          @click="open(item)"
        />
      </div>
    </template>

    <div v-if="!initialItems?.length && typeView !== 'list'" class="text-center py-3">
      <img src="/src/assets/images/svg/record.svg" class="me-2" alt="no-data">
      {{ $t('common.common.no_result') }}
    </div>
  </div>
  <!-- modal -->
  <detail-document ref="detailDocument"/>
  <create-or-update-folder ref="folderModal" @update="emit('reload')"/>
  <input type="file" ref="fileInput" @change="uploadFile" style="display: none" :accept="accept"/>
</template>

<script lang="ts" setup>
import DetailDocument from "@/components/module/document/modals/DetailDocument.vue"
import {Attachment} from "@/modules/document/models/document-attachment"
import AttachmentCard from "@/components/module/document/AttachmentCard.vue"
import {useI18n} from "vue-i18n";
import AttachmentTable from "@/components/module/document/AttachmentTable.vue"
import CreateOrUpdateFolder from "@/components/module/document/modals/CreateOrUpdateFolder.vue"
import {DocumentAttachmentService} from "@/modules/document/services/document-attachment";
import {showToast} from "@/helpers/common";
import useDocument from "@/components/module/document/composable/use-document";

const { t } = useI18n()
const emit = defineEmits(['reload', 'load-current'])
const { accept, downloadFile } = useDocument()
const props = defineProps<{
  initialItems?: Attachment[];
  typeView: string;
  moduleType: string;
  modelId: number | string;
  currentPath?: [];
}>();

const apiDocument = new DocumentAttachmentService()
const fileInput = ref<HTMLInputElement | null>(null)
const idUpload = ref(0)
const detailDocument = ref<InstanceType<typeof DetailDocument> | null>(null)
const folderModal = ref<InstanceType<typeof CreateOrUpdateFolder> | null>(null)

const viewFile = (attachment: Attachment) => {
  detailDocument.value?.openModal(attachment)
}

const open =(item: any) => {
  if (item.type === 'folder') {
    emit('load-current', item)
  } else {
    viewFile(item)
  }
}

const addOrUpdateFolder = (item: any = null, type: string) => {
  const form = {
    id: item?.id || '',
    type: item?.type || 'folder',
    folder_name: item?.name || '',
    module_type: props.moduleType,
    model_id: props.modelId,
  }
  folderModal.value?.open(form, type)
}

const deleteAttachment = (item: any) => {
  apiDocument.deleteAttachment({ ids: [ item.id ]}).then((res: any) => {
    if (res.success) {
      showToast({icon: "success", title: t('common.message.success')})
      emit('reload')
    } else {
      showToast({icon: 'error', title: t('common.message.error'), text: res.message})
    }
  })
}

const downloadAttachment = (item: any) => {
  apiDocument.downloadDocument(item.id).then((res: any) => {
    downloadFile(res.data, `${item.name}.${item.extension}`)
    showToast({icon: "success", title: t('common.message.success')})
  }).catch((e) => {
    showToast({icon: 'error', title: t('common.message.error'), text: e.message})
  })
}

const uploadFile = () => {
  const files = fileInput.value?.files;
  if (files && files.length > 0) {
    let formData = new FormData()
    const file = files[0];
    formData.append('type', 'file')
    formData.append('file[0]', file)

    apiDocument.createChildrenAttachment(idUpload.value, formData).then((res: any) => {
      if (res.success) {
        showToast({icon: "success", title: t('common.message.success')})
        emit('reload')
      } else {
        showToast({icon: 'error', title: t('common.message.error'), text: res.message})
      }
    })
  }
}

const moveFile = (item: any) => {
  console.log(item)
}

const updateData = ({type, item}: any) => {
  switch (type) {
    case 'add':
      addOrUpdateFolder(item, 'add-children')
      break;
    case 'change_name':
      addOrUpdateFolder(item, 'update')
      break;
    case 'move':
      moveFile(item)
      break;
    case 'delete':
      deleteAttachment(item)
      break;
    case 'upload':
      fileInput.value?.click();
      idUpload.value = item.id
      break;
    case 'download':
      downloadAttachment(item)
      break;
    case 'view':
      viewFile(item)
      break;
  }

}
</script>

<style scoped>
.grid-view {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
  gap: 10px;
}

.title-head {
  padding: 10px 10px 10px 0;
  font-weight: bold;
  opacity: 0.7;
}
</style>
