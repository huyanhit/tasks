<template>
  <fieldset>
    <legend>
      <icon :icon="isFormVisible ? 'ri-arrow-drop-down-line' : 'ri-arrow-drop-right-line'"
            width="30"
            class="cursor-pointer"
            @click="toggleForm"
      />
      {{ title }}
    </legend>
    <div v-if="isFormVisible">
      <slot/>
    </div>
    <div v-else>
      <span class="fs-13 fst-italic py-3">{{ summary }}</span>
    </div>
  </fieldset>
</template>

<script setup lang="ts">
import {Icon} from "@iconify/vue";

defineProps({
  title: {
    type: String,
    required: true
  },
  summary: {
    type: String,
    default: ''
  }
})
const isFormVisible = ref(true)
const toggleForm = () => {
  isFormVisible.value = !isFormVisible.value
}
</script>

<style scoped lang="scss">

label {
  display: block;
  margin-bottom: 5px;
}

legend {
  color: #f5671d;
  margin-bottom: 20px;
  font-weight: bold;
  font-size: 14px;
}
</style>