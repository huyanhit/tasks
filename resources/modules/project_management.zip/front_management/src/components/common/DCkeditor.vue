<template>
  <BCol :lg="col">
    <div class="form-group cursor-pointer mb-2">
      <div class="position-relative">
        <Field :name="name" :label="label" class="form-control" v-model="value" v-slot="{ field }" :rules="rules">
          <ckeditor v-model="value" :editor="editor" v-bind="field" />
        </Field>
      </div>
      <ErrorMessage :name="name" class="text-danger text-xs" as="div"/>
    </div>
  </BCol>
</template>

<script setup lang="ts">
import {ErrorMessage, Field} from "vee-validate"
import ClassicEditor from "@ckeditor/ckeditor5-build-classic";

const emit = defineEmits(['icon-click'])
const props = defineProps({
  col: {
    type: [String, Number],
    default: 12,
  },
  label:{
    type: String,
    default: ''
  },
  modelValue: {
    type: [String, Number]
  },
  name: {
    type: String,
    default: ''
  },
  rules: {
    type: [String, Object]
  },
  disabled: {
    type: Boolean,
    default: false
  }
})
const value = defineModel('modelValue')
const editor = ClassicEditor
</script>