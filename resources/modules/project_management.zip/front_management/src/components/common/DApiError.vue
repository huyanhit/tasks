<template>
    <span v-if="response && message" role="alert" class="text-danger text-capitalize"> {{$t(`back_end_validation.${message}`)}} </span>
</template>
<script setup>

const props = defineProps(['response', 'name']);
const message = computed(() => {
    if(props.response.errors){
        for (const index in props.response.errors) {
            if (index === props.name){
                return props.response.errors[index];
            }
        }
    }

})
</script>
