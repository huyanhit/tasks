<template>
  <div class="d-flex align-items-center justify-content-between p-3">
    <div v-if="!hidePerPage" class="d-flex flex-row gap-1 align-items-center">
      <span class="w-max">{{ $t('common.pagination.per_page') }}</span>
      <BFormSelect
        size="sm"
        class="w-fit ms-1"
        no-caret
        v-model="data.per_page"
        :options="DataTableConfigs.itemsPerPageOptions"
      />
    </div>
    <div v-if="!hidePage" class="d-flex w-100 flex-row gap-1 align-items-center justify-content-end">
      <BButton
        variant="ghost-secondary"
        size="sm"
        class="btn-icon"
        @click.prevent.stop="changePage('first')"
        :disabled="data.page == 1"
      >
        <Icon icon="ri:skip-left-line" width="28"/>
      </BButton>
      <BButton
        variant="ghost-secondary"
        size="sm"
        class="btn-icon"
        @click.prevent.stop="changePage('prev')"
        :disabled="data.page == 1"
      >
        <Icon icon="ri:arrow-left-s-line" width="28"/>
      </BButton>
      {{ $t('common.pagination.page') }}
      <input
        type="number"
        class="form-control form-control-sm mw-52-px"
        style="min-width: 1px"
        min="1"
        :max="totalPages"
        v-model="page"
        @focusout="outFocus"
      />
      / {{ totalPages }}
      <BButton
        variant="ghost-secondary"
        size="sm"
        class="btn-icon"
        @click.prevent.stop="changePage('next')"
        :disabled="data.page == totalPages"
      >
        <Icon icon="ri:arrow-right-s-line" width="28"/>
      </BButton>
      <BButton
        variant="ghost-secondary"
        size="sm"
        class="btn-icon"
        @click.prevent.stop="changePage('last')"
        :disabled="data.page == totalPages"
      >
        <Icon icon="ri:skip-right-line" width="28"/>
      </BButton>
    </div>
  </div>
</template>

<script setup lang="ts">
import {DataTableConfigs} from '@/configs/index.ts'
import {Icon} from "@iconify/vue"

interface Pagination {
  page: number,
  per_page: number
}

const props = defineProps(['totalPages', 'hidePerPage', 'hidePage'])
const data = defineModel<Pagination>('modelValue', {
  default: {
    per_page: 15,
    page: 1
  }
})

const page = ref(1)
const outFocus = () => {
  if (page.value < 1) {
    page.value = 1
  } else if (page.value > props.totalPages) {
    page.value = props.totalPages
  }
  data.value.page = page.value
}

const changePage = (action: string) => {
  switch (action) {
    case 'first':
      page.value = 1
      break
    case 'prev':
      --page.value
      break
    case 'next':
      ++page.value
      break
    case 'last':
      page.value = props.totalPages
      break
    default:
      break
  }

  data.value.page = page.value
}

</script>

<style scoped>
.btn:disabled,
.btn.disabled {
  border-color: transparent;
}

/* Chrome, Safari, Edge, Opera */
input::-webkit-outer-spin-button,
input::-webkit-inner-spin-button {
  -webkit-appearance: none;
  margin: 0;
}

/* Firefox */
input[type='number'] {
  -moz-appearance: textfield;
}
</style>
