<template>
    <div v-if="response">
        <div v-if="response.code === 422" class="alert alert-danger alert-dismissible fade show mb-2" role="alert" @click.prevent.stop="showErrors = !showErrors">
            <strong> {{ $t('common.validate.validate_message')}} </strong>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            <ul class="list-unstyled mb-0 mt-2" v-if="detail && showErrors">
                <li v-for="(item, index) in response.errors" :key="index" class="text-danger mx-2">
                    <template v-for="(message, i) in item" :key="i">
                        {{ $t(`common.back_end_validation.${message}`) }}
                    </template>
                </li>
            </ul>
        </div>
        <div v-if="response.code === 403" class="alert alert-danger alert-dismissible fade show mb-2" role="alert" @click.prevent.stop="showErrors = !showErrors">
            <strong> {{ $t('common.message.error_403') }} </strong>
        </div>
    </div>
</template>

<script setup>
import { ref } from 'vue'

const value = defineModel();
const props = defineProps({
    response: { type: Object },
    detail: { default: false },
});

const showErrors = ref(false)
</script>
