import { getCurrentInstance } from 'vue';
import { useCookies as useVueCookies } from 'vue3-cookies';
import Swal from 'sweetalert2';
import i18n from '@/plugins/i18n';
import { I18n } from 'vue-i18n';

export default {
    useEvent: () => getCurrentInstance()?.appContext.config.globalProperties.event,
    useFilter: () => getCurrentInstance()?.appContext.config.globalProperties.filter,
    useRoute: () => getCurrentInstance()?.appContext.config.globalProperties.$router,
    useSocket: () => getCurrentInstance()?.appContext.config.globalProperties.$socket,
    useCookies: () => useVueCookies({ expire: '7d' }).cookies,
};

interface ShowOptions {
    title?: string | null;
    text?: string | null;
    icon?: Swal.SweetAlertIcon | string | null;
    html?: string | null;
    color?: string | null;
    confirmButtonColor?: string | null;
    cancelButtonColor?: string | null;
    confirmButtonText?: string | null;
    cancelButtonText?: string | null;
    customClass?: any;
    position?: string;
    confirm?: boolean;
    timer?: number;
    progress?: boolean;
}

export const { showConfirm, showAlert, showToast, parseErrorKey } = {
    showConfirm: (options: ShowOptions) => {
        return Swal.fire({
            title: options.title ?? null,
            text: options.text ?? null,
            icon: options.icon ?? 'warning',
            html: options.html ?? null,
            showCancelButton: true,
            color: options.color ?? '#545454',
            confirmButtonColor: options.confirmButtonColor ?? '#34c38f',
            cancelButtonColor: options.cancelButtonColor ?? '#f46a6a',
            confirmButtonText: options.confirmButtonText ?? i18n.global.t('common.common.sweetalert.confirm_button_text'),
            cancelButtonText: options.cancelButtonText ?? i18n.global.t('common.common.sweetalert.cancel_button_text'),
            allowOutsideClick: false,
            customClass: options.customClass ?? {},
        });
    },
    showAlert: (options: ShowOptions) => {
        Swal.fire({
            title: options.title ?? null,
            text: options.text ?? null,
            icon: options.icon ?? 'info',
            showCloseButton: true,
            allowOutsideClick: false,
        });
    },
    showToast: (options: ShowOptions) => {
        const Toast = Swal.mixin({
            toast: true,
            position: options.position ?? 'top',
            showConfirmButton: options.confirm ?? false,
            timer: options.timer ?? 3000,
            timerProgressBar: options.progress ?? true,
            didOpen: (toast) => {
                toast.onmouseenter = Swal.stopTimer;
                toast.onmouseleave = Swal.resumeTimer;
            },
        });

        Toast.fire({
            icon: options.icon ?? 'info',
            title: options.title ?? null,
            text: options.text ?? null,
            html: options.html ?? null,
        });
    },
    parseErrorKey: (errors: Record<string, string[]> | null) => {
        const parsedData: Record<string, string[]> = {};

        if (errors) {
            for (const key in errors) {
                if (errors.hasOwnProperty(key)) {
                    parsedData[key] = errors[key].map((entry) => entry.split('#')[0]);
                }
            }
        }

        return parsedData;
    },
};

export const ID_VN = 1423;
