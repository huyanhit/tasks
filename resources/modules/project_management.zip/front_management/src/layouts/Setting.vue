<template>
	<BContainer fluid id="setting-layout">
		<TheHeader />
	</BContainer>
	<div class="setting-layout main-content">
		<div class="page-content d-flex">
			<BContainer fluid >
				<BRow>
					<BCol class="col-lg-2 d-none d-sm-block">
						<simplebar id="scrollbar" class="h-100 work__task--settings" ref="scrollbar">
							<TheNavBar :groupMenu="groupMenu" />
						</simplebar>
					</BCol>
					<BCol class="col-12 col-lg-8">	
						<router-view :key="$i18n.locale"></router-view>
					</BCol>
				</BRow>
			</BContainer>
		</div>
	</div>

	<!-- Loading -->
	<div id="preloader" v-show="layout.state.preloader !== 'disable'">
		<div id="status">
			<div class="spinner-border text-primary avatar-sm" role="status">
				<span class="visually-hidden">Loading...</span>
			</div>
		</div>
	</div>
</template>

<script setup lang="ts">
import { watch } from 'vue'
import TheHeader from '@/layouts/setting/TheHeader.vue'
import { useLayoutStore } from '@/stores/useLayout'
import { getGroupMenuByModule, groupMenu } from '@/configs/groupMenu/index'
import { useRoute } from 'vue-router'
import TheSidebar from './setting/TheSidebar.vue'
import TheNavBar from './setting/TheNavBar.vue'

const route = useRoute()
const layout = useLayoutStore()
layout.setLayoutType('horizontal');

watch(
() => route.meta.module,
(newModule) => {
if (newModule) {
	groupMenu.value = getGroupMenuByModule(newModule as string)
	console.log(groupMenu.value);

}
},
{ immediate: true }
);

</script>

<style scoped lang="scss">
.navbar-menu {
	border-right: none;
	box-shadow: none;
}
</style>
