<template>
    <li v-for="menuItem in groupMenu" :key="menuItem.id" class="nav-item" :class="vertical && 'nav-setting mb-2'">
        <div :id="menuItem.role" class="menu-dropdown" :class="vertical || 'collapse'">
            <ul class="nav nav-sm flex-column">
                <li class="nav-item rounded-1"  v-for="child in menuItem.children" :key="child.id" >
                    <router-link :to=child.url class="nav-link"  :active-class="vertical ? 'nav-setting-active' : 'active'">
                        {{ $t(child.title) }}
                    </router-link>
                </li>
            </ul>
        </div>
    </li>
</template>

<script setup>
import { defineProps } from 'vue';

const props = defineProps({
  vertical: {
    type: Boolean,
    default: false,
  },
    groupMenu: {
    type: Array,
    default: () => [],
  },
});
</script>

<style scoped lang="scss">
.nav-setting{
    ul.nav{
        padding: 0
    }
    .nav-item{
        margin-bottom: .15em;
    }
    .nav-link{
        &::before{
            content: none !important;
        }
    &:hover{
        background-color: #fff;
        color: var(--color-orange) !important;
        border-radius: .25em;
    }
    }

    .nav-setting-active{
        background-color: #fff;
        color: var(--color-orange) !important;
        border-radius: .25em;
    }
}
</style>