<template>
  <div class="d-flex justify-content-center bg-white">
    <Logo />
  </div>
  <div>
    <BContainer fluid>
      <div class="ps-3">
        <simplebar class="navbar-nav mt-3" id="navbar-nav">
          <template v-for="item in groupMenu">
            <!-- <DDropdownContextMenu v-if="item?.dropdown" :dropdown-data="item" /> -->
            <ParentNavItem :groupMenu="[item]" vertical />
            <ChildNavItem :groupMenu="[item]" vertical />
          </template>
        </simplebar>
      </div>
    </BContainer>
  </div>
  <div class="sidebar-background"></div>
</template>

<script setup>
import Logo from '../partials/Logo.vue'
import ParentNavItem from '../setting/ParentNavItem.vue'
import ChildNavItem from '../setting/ChildNavItem.vue'
defineProps({
  groupMenu: {
    type: Array,
    default: () => [],
  },
});
</script>

<style scoped>
/* Your component styles here */
</style>
