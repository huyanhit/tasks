<template>
  <li v-for="menuItem in groupMenu" :key="menuItem.id" data-v-inspector>
    <!-- Layout Setting -->
    <template v-if="vertical">
      <div class="mb-2">{{ $t(menuItem.title) }}</div>
    </template>
    <template v-else>
      <router-link v-if="menuItem.url" :to="menuItem.url" class="nav-icon"
                   @click.prevent="handleMenuClick(menuItem.url, $event)" aria-expanded="false"
                   :class="{ active: isActive(menuItem.url) }">
        <Icon :icon="menuItem.icon" width="20"/>
      </router-link>
      <a v-else-if="menuItem.role" class="nav-icon" :title="$t(menuItem.title)" :href="'#' + menuItem.role"
         role="button" aria-expanded="false" :aria-controls="menuItem.role"
         @click.prevent="handleMenuClick(menuItem.role, $event)"
         :class="{ active: isActive(menuItem.role) }">
        <Icon :icon="menuItem.icon" width="20"/>
      </a>
    </template>
  </li>
</template>

<script setup>
import { defineProps } from 'vue';
import { updateMenu } from '../typescript/sidebar';
import { Icon } from '@iconify/vue';

const props = defineProps({
  vertical: {
    type: Boolean,
    default: false,
  },
  groupMenu: {
    type: Array,
    default: () => [],
  },
});

const handleMenuClick = (menuItemUrl, event) => {
  updateMenu(menuItemUrl, event);
  localStorage.setItem('activeMenuItem', menuItemUrl);
};
const isActive = (menuItemUrl) => {
  const activeMenuItem = localStorage.getItem('activeMenuItem');
  return activeMenuItem === menuItemUrl;
};
</script>
