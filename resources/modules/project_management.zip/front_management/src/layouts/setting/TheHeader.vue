<template>
	<header id="page-topbar">
		<div class="layout-width">
			<div class="navbar-header p-0">
				<!-- Logo -->
				<BContainer fluid>
					<BRow>
						<BCol sm="2" md="2" class="d-sm-none d-md-block" alignSelf="center">
							<div class="navbar-brand-box">
								<router-link to="/" class="logo logo-dark">
									<span class="logo-lg">
										<img src="@/assets/images/logo-dark.png" height="55" />
									</span>
								</router-link>
								<router-link to="/" class="logo logo-light">
									<span class="logo-lg">
										<img src="@/assets/images/logo-light.png" height="55" />
									</span>
								</router-link>
							</div>
						</BCol>
						<BCol sm="8" md="8" alignSelf="center" class="header_setting d-flex align-items-center justify-content-between">
							<!-- Header Action -->
							<div id="teleport-header-action"></div>
							<!-- Header Search -->
							<div id="teleport-header-search"></div>
						</BCol>
						<BCol sm="2" md="2" alignSelf="center">
							<div class="d-flex align-items-center justify-content-end">
								<Apps/>
								<Chat/>
								<Notification/>
								<UserProfileHeader/>
							</div>
						</BCol>
					</BRow>
				</BContainer>
			</div>
		</div>
	</header>
</template>

<script setup lang="ts">
import {onMounted, ref} from 'vue';
import Chat from '@/layouts/partials/Chat.vue'
import Notification from '@/layouts/partials/Notification.vue'
import UserProfileHeader from '@/layouts/partials/UserProfileHeader.vue'
import Apps from '@/layouts/partials/Apps.vue'

onMounted(() => {
	document.addEventListener("scroll", function () {
		const pageTopbar = document.getElementById("page-topbar");
		if (pageTopbar) {
			document.body.scrollTop >= 50 || document.documentElement.scrollTop >= 50 ? pageTopbar.classList.add(
			"topbar-shadow") : pageTopbar.classList.remove("topbar-shadow");
		}
	});
});
</script>

<style lang="css" scoped>
	.header_setting{
		padding-left: 20px;
		padding-right: 20px;
	}
</style>