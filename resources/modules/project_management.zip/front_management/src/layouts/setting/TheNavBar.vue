<template>
  <template v-if="vertical" v-for="menuItem in groupMenu" :key="menuItem.id">
    <div class="mb-2">{{ $t(menuItem.title) }}</div>
  </template>
  <template v-else>
    <ul class="navbar-nav h-100" id="navbar-nav" v-for="menuItem in groupMenu" :key="menuItem.id">
      <li v-if="menuItem.groupTitle" class="menu-title">
        <i class="ri-more-fill"></i><span data-key="t-pages">{{menuItem.title}}</span>
      </li>
      <li class="nav-item" v-if="menuItem.url">
        <router-link
          class="nav-link menu-link"
          :to="menuItem.url"
          @click="(event) => handleMenuClick(menuItem.url, event)"
        >
          <Icon :icon="menuItem.icon" width="20" />
          <span data-key="t-widgets">{{ $t(menuItem.title) }}</span>
        </router-link>
      </li>
      <li class="nav-item" v-else-if="menuItem.role">
        <BLink
          class="nav-link menu-link"
          :href="'#' + menuItem.role"
          data-bs-toggle="collapse"
          role="button"
          :aria-expanded="isActiveMenuItem(menuItem.role)"
          aria-controls="sidebarDashboards"
          @click="(event) => toggleMenu(menuItem.role, event)"
        >
          <Icon :icon="menuItem.icon" width="20" />
          <span data-key="t-dashboards">{{ $t(menuItem.title) }}</span>
        </BLink>
        <div
          class="collapse menu-dropdown"
          :id="menuItem.role"
          :class="{ show: isActiveMenuItem(menuItem.role) }"
        >
          <ul class="nav nav-sm flex-column">
            <li class="nav-item" v-for="child in menuItem.children" :key="child.id">
              <router-link
                :to="child.url"
                class="nav-link"
                :active-class="
                  isActive('#' + menuItem.role) || isActive(child.url)
                    ? 'active'
                    : 'nav-setting-active'
                "
                @click="(event) => handleMenuClick(child.url, event)"
              >
                {{ $t(child.title) }}
              </router-link>
            </li>
          </ul>
        </div>
      </li>
    </ul>
  </template>
</template>

<script setup>
import { defineProps, ref, watchEffect } from 'vue'
import { useRoute } from 'vue-router'
import { updateMenu } from '../vertical/TheSidebar'
import { Icon } from '@iconify/vue'

const props = defineProps({
  vertical: {
    type: Boolean,
    default: false
  },
  groupMenu: {
    type: Array,
    default: () => []
  }
})

const route = useRoute()
const activeMenu = ref(localStorage.getItem('activeMenuRole') || '')

const handleMenuClick = (menuItemUrl, event) => {
  updateMenu(menuItemUrl, event)
  localStorage.setItem('activeMenuItem', menuItemUrl)
}

const isActive = (menuItemUrl) => {
  const activeMenuItem = localStorage.getItem('activeMenuItem')
  return activeMenuItem === menuItemUrl
}

const toggleMenu = (menuItemRole, event) => {
  if (activeMenu.value === menuItemRole) {
    activeMenu.value = ''
    localStorage.removeItem('activeMenuRole')
  } else {
    activeMenu.value = menuItemRole
    localStorage.setItem('activeMenuRole', menuItemRole)
  }
  updateMenu(menuItemRole, event)
}

const isActiveMenuItem = (menuItemRole) => {
  return activeMenu.value === menuItemRole
}

// Watch for route changes to update sidebar size and reload menu
watchEffect(() => {
  if (route.path === '/') {
    document.documentElement.setAttribute('data-sidebar-size', 'sm')
    // Reload menu logic here if needed
    updateMenu('', null)
  } else {
    document.documentElement.setAttribute('data-sidebar-size', 'lg')
  }
});
</script>

<style scope lang="scss">
</style>
