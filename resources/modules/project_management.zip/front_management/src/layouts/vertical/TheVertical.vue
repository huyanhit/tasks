<template>
  <div id="layout-wrapper">
    <TheHeader />
    <div class="app-menu navbar-menu">
      <Logo />
      <simplebar id="scrollbar" class="h-100" ref="scrollbar">
        <TheNavBar :groupMenu="groupMenu" />
      </simplebar>
      <div class="sidebar-background"></div>
    </div>
    <!-- Left Sidebar End -->
    <!-- Vertical Overlay-->
    <div class="vertical-overlay" id="overlay"></div>
    <!-- ============================================================== -->
    <!-- Start Page Content here -->
    <!-- ============================================================== -->

    <div class="main-content">
      <div class="page-content">
        <!-- Start Content-->
        <BContainer fluid class="p-0">
          <router-view :key="$i18n.locale"></router-view>
        </BContainer>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import TheNavBar from '@/layouts/vertical/TheNavBar.vue'
import Logo from '@/layouts/partials/Logo.vue'
import { watch } from 'vue'
import { useRoute } from 'vue-router'
import { getGroupMenuByModule, groupMenu } from '@/configs/groupMenu/index'
import TheHeader from '@/layouts/vertical/TheHeader.vue'

const route = useRoute()
watch(
  () => route.meta.module,
  (newModule) => {
    if (newModule) {
      groupMenu.value = getGroupMenuByModule(newModule as string)
    }
  },
  { immediate: true }
)
</script>

<style scoped>
.navbar-menu{
  border-right: none !important;
}
</style>
