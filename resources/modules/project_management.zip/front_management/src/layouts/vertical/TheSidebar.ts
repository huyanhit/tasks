import { onMounted, onUnmounted } from 'vue';

// Danh sách các thuộc tính cần xóa khỏi body
const removeAttributes: readonly string[] = [
  'data-layout',
  'horizontal',
  'data-topbar',
  'dark',
  'data-layout-size',
  'boxed'
];

// Hàm để xóa các thuộc tính được chỉ định khỏi body
const removeAttributesFromBody = (attributes: readonly string[]): void => {
  const body = document.body;
  attributes.forEach((attribute) => {
    if (body.hasAttribute(attribute)) {
      body.removeAttribute(attribute);
    }
  });
};

// Gọi hàm removeAttributesFromBody với danh sách thuộc tính cần xóa
removeAttributesFromBody(removeAttributes);

// Hàm để cập nhật menu
export const updateMenu = (id: string, event: Event | null): void => {
  // Xóa trạng thái active trước đó
  clearActiveState('.navbar-nav .active');
  clearActiveState('.menu-link.active');

  // Cập nhật menu item hiện tại
  const element = document.getElementById(id);
  if (element) {
    element.classList.add('show');
  } else {
    document.body.classList.add('twocolumn-panel');
  }

  // Cập nhật class cho phần tử target
  if (event) {
    const target = event.currentTarget as HTMLElement;
    target.classList.add('active');
  }

  // Lưu trạng thái menu active vào localStorage
  localStorage.setItem('activeMenuItem', id);
};

// Hàm để xóa trạng thái active từ các phần tử được chỉ định
const clearActiveState = (selector: string): void => {
  const activeItems = document.querySelectorAll(selector);
  activeItems.forEach((item) => item.classList.remove('active'));
};

// Hàm để bật/tắt menu
export const toggleMenu = (): void => {
  const windowSize = document.documentElement.clientWidth;
  const layoutType = document.documentElement.getAttribute('data-layout');
  document.documentElement.setAttribute('data-sidebar-visibility', 'show');
  const visibilityType = document.documentElement.getAttribute('data-sidebar-visibility');

  if (windowSize > 767) {
    const hamburgerIcon = document.querySelector('.hamburger-icon');
    if (hamburgerIcon) {
      hamburgerIcon.classList.toggle('open');
    }
  }

  if (layoutType === 'horizontal') {
    document.body.classList.toggle('menu');
  }

  if (visibilityType === 'show' && (layoutType === 'vertical' || layoutType === 'semibox')) {
    adjustVerticalMenu(windowSize);
  }

  if (layoutType === 'twocolumn') {
    document.body.classList.toggle('twocolumn-panel');
  }
};

// Hàm để điều chỉnh menu dọc
const adjustVerticalMenu = (windowSize: number): void => {
  if (windowSize < 1025 && windowSize > 767) {
    document.body.classList.remove('vertical-sidebar-enable');
    document.documentElement.setAttribute(
        'data-sidebar-size',
        document.documentElement.getAttribute('data-sidebar-size') === 'sm' ? '' : 'sm'
    );
  } else if (windowSize > 1025) {
    document.body.classList.remove('vertical-sidebar-enable');
    document.documentElement.setAttribute(
        'data-sidebar-size',
        document.documentElement.getAttribute('data-sidebar-size') === 'lg' ? 'sm' : 'lg'
    );
  } else if (windowSize <= 767) {
    document.body.classList.add('vertical-sidebar-enable');
    document.documentElement.setAttribute('data-sidebar-size', 'lg');
  }
};

// Hàm để cập nhật kích thước sidebar
export const updateSidebarSize = (): void => {
  const windowSize = window.innerWidth;
  document.body.classList.remove('vertical-sidebar-enable');
  const hamburgerIcon = document.querySelector('.hamburger-icon');
  if (hamburgerIcon) {
    hamburgerIcon.classList.add('open');
  }

  if (windowSize < 1025) {
    document.documentElement.setAttribute('data-sidebar-size', 'sm');
  } else {
    document.documentElement.setAttribute('data-sidebar-size', 'lg');
  }
};
