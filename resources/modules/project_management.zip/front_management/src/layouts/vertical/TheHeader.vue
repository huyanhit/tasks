<template>
  <header id="page-topbar">
    <div class="layout-width">
      <div class="navbar-header">
        <div class="d-flex align-items-center">
          <div id="teleport-header-action"></div>
        </div>
        <div class="d-flex align-items-center">
          <div id="teleport-header-search" class="m-lg-2"></div>
          <Apps />
          <Chat />
          <Notification />
          <UserProfileHeader />
        </div>
      </div>
    </div>
  </header>
</template>

<script setup lang="ts">
import i18n from '@/plugins/i18n'
import { userSettingStore } from '@/stores/user-setting.ts'
import { useI18n } from 'vue-i18n'
import Language from '@/layouts/partials/Language.vue'
//import Chat from '@/layouts/partials/Chat.vue'
import Notification from '@/layouts/partials/Notification.vue'
import UserProfileHeader from '@/layouts/partials/UserProfileHeader.vue'
import Apps from '@/layouts/partials/Apps.vue'
import {Icon} from "@iconify/vue";
const { t } = useI18n()

const userSetting = new userSettingStore()
</script>

<style scoped>
  .navbar-header{
    height: 60px;
    padding-left: 12px;
    padding-right: 12px;
  }
</style>
