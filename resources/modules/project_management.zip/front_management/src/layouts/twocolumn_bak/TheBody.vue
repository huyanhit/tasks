<script setup lang="ts">
import TheHeader from '@/layouts/twocolumn/header/TheHeader.vue'
import TheSidebar from '@/layouts/twocolumn/sidebar/TheSidebar.vue'
import { defineProps } from 'vue'

const props = defineProps({
  layoutType: {
    type: String,
    required: true
  }
})
</script>

<template>
  <div id="layout-wrapper">
    <TheHeader />

    <!-- Sidebar Component -->
    <div class="app-menu navbar-menu">
      <TheSidebar />
    </div>
  </div>

  <!-- Main Content Area -->
  <div class="main-content">
    <div class="page-content">
      <!-- Container for BootstrapVue -->
      <BContainer fluid>
        <!-- Router View to Render Route Components -->
        <router-view></router-view>
      </BContainer>
    </div>
  </div>
</template>
