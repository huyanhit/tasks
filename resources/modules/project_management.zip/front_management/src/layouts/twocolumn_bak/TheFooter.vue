<template>
    <footer class="footer">
        <BContainer fluid>
            <BRow>
                <BCol col sm="6">
                    {{ new Date().getFullYear() }} © Management Partners.
                </BCol>
                <BCol col sm="6">
                    <div class="text-sm-end d-none d-sm-block">
                        Design & Develop by Management Partners
                    </div>
                </BCol>
            </BRow>
        </BContainer>
    </footer>
</template>
