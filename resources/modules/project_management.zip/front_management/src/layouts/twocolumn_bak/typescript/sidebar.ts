// Define types
type MenuItem = HTMLAnchorElement;
type MenuItemArray = MenuItem[];

// Initial variable declarations
let layoutType: 'twocolumn' | 'vertical' = 'twocolumn';

// Array of attributes to remove from the body
const removeAttributes: readonly string[] = ["data-layout", "horizontal", "data-topbar", "dark", "data-layout-size", "boxed"];

// Function to remove specified attributes from the body
const removeAttribute = (attributes: readonly string[]): void => {
    attributes.forEach(attribute => {
        const body = document.body;
        if (body.hasAttribute(attribute)) {
            body.removeAttribute(attribute);
        }
    });
};

// Execute removeAttribute function
removeAttribute(removeAttributes);

// Function to get the active menu item based on the current path
const getActiveItem = (items: MenuItemArray): MenuItem | undefined => {
    const pathName = window.location.pathname;
    return items.find(item => item.getAttribute("href") === pathName);
};

// Function to remove the active state from menu items
const removeActivation = (items: MenuItemArray): void => {
    items.forEach(item => {
        if (item.classList.contains("active")) {
            item.classList.remove("active");
            if (item.classList.contains("menu-link")) {
                item.setAttribute("aria-expanded", "false");
                const nextElementSibling = item.nextElementSibling as HTMLElement;
                if (nextElementSibling) {
                    nextElementSibling.classList.remove("show");
                }
            } else if (item.classList.contains("nav-link")) {
                const nextElementSibling = item.nextElementSibling as HTMLElement;
                if (nextElementSibling) {
                    nextElementSibling.classList.remove("show");
                }
                item.setAttribute("aria-expanded", "false");
            }
        }
    });
};

// Function to initialize the active menu
const initActiveMenu = (): void => {
    const navbarNav = document.getElementById("navbar-nav");
    if (navbarNav) {
        const navLinks = Array.from(navbarNav.querySelectorAll("a.nav-link")) as MenuItemArray;
        removeActivation(navLinks);
        matchingMenuItem(navLinks);
    }
};

// Function to remove the last active navbar state
const removeLastActiveNavbar = (): void => {
    document.body.classList.remove("twocolumn-panel");
    const navbarNav = document.getElementById("navbar-nav");
    if (navbarNav) {
        const items = Array.from(navbarNav.querySelectorAll(".show")) as HTMLElement[];
        items.forEach(item => item.classList.remove("show"));
    }
};

// Function to remove the last active icon bar state
const removeLastActiveIconbar = (): void => {
    const icons = document.getElementById("two-column-menu");
    if (icons) {
        const activeIcons = Array.from(icons.querySelectorAll(".nav-icon.active")) as HTMLElement[];
        activeIcons.forEach(item => item.classList.remove("active"));
    }
};

// Function to update the menu based on the clicked item
export const updateMenu = (id: string, event: Event): void => {
    removeLastActiveNavbar();
    removeLastActiveIconbar();
    const element = document.getElementById(id);
    if (element) {
        element.classList.add("show");
    } else {
        document.body.classList.add("twocolumn-panel");
    }
    const target = event.target as HTMLElement;
    target.classList.add("active");

    // Lưu trạng thái active vào localStorage
    localStorage.setItem('activeMenuItem', id);
};


// Function to activate the icon sidebar
const activateIconSidebarActive = (id: string): void => {
    const menu = document.querySelector(`#two-column-menu .simplebar-content-wrapper a[href='${id}'].nav-icon`) as HTMLElement;
    if (menu) {
        menu.classList.add("active");
    }
};

// Function to activate the parent dropdown menu
const activateParentDropdown = (item: MenuItem): void => {
    item.classList.add("active");
    const parentCollapseDiv = item.closest(".collapse.menu-dropdown");
    if (parentCollapseDiv) {
        parentCollapseDiv.classList.add("show");
        const parent = parentCollapseDiv.parentElement;
        if (parent) {
            const parentLink = parent.children[0] as HTMLElement;
            parentLink.classList.add("active");
            parentLink.setAttribute("aria-expanded", "true");
            const grandparentCollapse = parent.closest(".collapse.menu-dropdown");
            if (grandparentCollapse) {
                const grandparent = grandparentCollapse.previousElementSibling?.parentElement?.closest(".collapse.menu-dropdown");
                if (grandparent) {
                    activateIconSidebarActive(`#${grandparent.id}`);
                    grandparent.classList.add("show");
                }
                activateIconSidebarActive(`#${grandparentCollapse.id}`);
                grandparentCollapse.classList.add("show");
                const grandparentLink = grandparentCollapse.previousElementSibling as HTMLElement;
                grandparentLink.classList.add("active");
            }
        }
        activateIconSidebarActive(`#${parentCollapseDiv.id}`);
    }
};

// Function to match and activate the menu item
const matchingMenuItem = (items: MenuItemArray): void => {
    const pathName = window.location.pathname;
    const activeItem = getActiveItem(items);
    if (activeItem) {
        activateParentDropdown(activeItem);
    } else {
        if (pathName === "/") {
            document.body.classList.add("twocolumn-panel");
        } else {
            const id = pathName.replace("/", "");
            if (id) {
                document.body.classList.add("twocolumn-panel");
            }
            activateIconSidebarActive(pathName);
        }
    }
};

// Function to initialize the layout and menu behavior
export const mounted = (rmenu: string): void => {
    initActiveMenu();
    if (rmenu === 'vertical' && layoutType === 'twocolumn') {
        document.documentElement.setAttribute("data-layout", "vertical");
    }
    document.getElementById('overlay')?.addEventListener('click', () => {
        document.body.classList.remove('vertical-sidebar-enable');
    });

    window.addEventListener("resize", () => {
        if (layoutType === 'twocolumn') {
            const windowSize = document.documentElement.clientWidth;
            if (windowSize < 767) {
                document.documentElement.setAttribute("data-layout", "vertical");
                rmenu = 'vertical';
                localStorage.setItem('rmenu', 'vertical');
            } else {
                document.documentElement.setAttribute("data-layout", "twocolumn");
                rmenu = 'twocolumn';
                localStorage.setItem('rmenu', 'twocolumn');
                setTimeout(initActiveMenu, 50);
            }
        }
    });

    const collapses = document.querySelectorAll(".navbar-nav .collapse");
    collapses.forEach(collapse => {
        collapse.addEventListener("show.bs.collapse", (e: Event) => {
            e.stopPropagation();
            const closestCollapse = collapse.closest(".collapse");
            if (closestCollapse) {
                const siblingCollapses = closestCollapse.querySelectorAll(".collapse.show");
                siblingCollapses.forEach(siblingCollapse => {
                    siblingCollapse.classList.remove("show");
                    const parentLink = siblingCollapse.parentElement?.firstElementChild as HTMLElement;
                    parentLink.setAttribute("aria-expanded", "false");
                });
            } else {
                const siblings = Array.from(collapse.parentElement?.parentElement?.children || []) as HTMLElement[];
                siblings.forEach(sibling => {
                    if (sibling !== collapse.parentElement) {
                        const siblingLink = sibling.firstElementChild as HTMLElement;
                        siblingLink.setAttribute("aria-expanded", "false");
                        siblingLink.classList.remove("active");
                        const siblingCollapse = sibling.querySelector(".collapse.show");
                        if (siblingCollapse) {
                            siblingCollapse.classList.remove("show");
                        }
                    }
                });
            }
        });

        collapse.addEventListener("hide.bs.collapse", (e: Event) => {
            e.stopPropagation();
            const childCollapses = collapse.querySelectorAll(".collapse.show");
            childCollapses.forEach(childCollapse => {
                childCollapse.classList.remove("show");
                const parentLink = childCollapse.parentElement?.firstElementChild as HTMLElement;
                parentLink.setAttribute("aria-expanded", "false");
            });
        });
    });
};
