<template>
  <header id="page-topbar">
    <div class="layout-width">
      <div class="navbar-header">
        <div class="d-flex">
          <!-- LOGO -->
          <div class="navbar-brand-box horizontal-logo">
            <router-link to="/" class="logo logo-dark">
							<span class="logo-sm">
								<img src="@/assets/images/logo-sm.png" alt="" height="22"/>
							</span>
              <span class="logo-lg">
								<img src="@/assets/images/logo-dark.png" alt="" height="17"/>
							</span>
            </router-link>

            <router-link to="/" class="logo logo-light">
							<span class="logo-sm">
								<img src="@/assets/images/logo-sm.png" alt="" height="22"/>
							</span>
              <span class="logo-lg">
								<img src="@/assets/images/logo-light.png" alt="" height="17"/>
							</span>
            </router-link>
          </div>
          <div id="teleport-header-action"></div>
        </div>

        <div class="d-flex align-items-center">
          <div id="teleport-header-search" class="m-lg-2"></div>
<!--          <Language/>-->
          <Apps/>
          <Chat/>
          <!-- Apps -->

<!--          <div class="ms-1 header-item d-none d-sm-flex">-->
<!--            <BButton type="button" variant="ghost-secondary" class="btn-icon btn-topbar rounded-circle"-->
<!--                     data-toggle="fullscreen" @click="initFullScreen">-->
<!--              <i class="bx bx-fullscreen fs-22"></i>-->
<!--            </BButton>-->
<!--          </div>-->

<!--          <div class="ms-1 header-item d-none d-sm-flex">-->
<!--            <BButton type="button" variant="ghost-secondary"-->
<!--                     class="btn-icon btn-topbar rounded-circle light-dark-mode" @click="setDarkMode">-->
<!--              <i class="bx bx-moon fs-22"></i>-->
<!--            </BButton>-->
<!--          </div>-->

          <Notification/>
          <UserProfileHeader/>
        </div>
      </div>
    </div>
  </header>
</template>

<script setup lang="ts">
import {onMounted, ref} from 'vue';
import i18n from "@/plugins/i18n";
import {userSettingStore} from '@/stores/user-setting.ts';
import {useI18n} from 'vue-i18n'
import Language from '@/layouts/partials/Language.vue'
//import Chat from '@/layouts/partials/Chat.vue'
import Notification from '@/layouts/partials/Notification.vue'
import UserProfileHeader from '@/layouts/partials/UserProfileHeader.vue'
import Apps from '@/layouts/partials/Apps.vue'

const {t} = useI18n();

const initFullScreen = () => {
  // Code to initialize full screen
  document.body.classList.toggle("fullscreen-enable");
  if (
      !document.fullscreenElement
  ) {
    // current working methods
    if (document.documentElement.requestFullscreen) {
      document.documentElement.requestFullscreen();
    }
  }
};

const getDarkMode = () => {
  const currentMode = userSetting.darkMode ? "dark" : "light";
  document.documentElement.setAttribute("data-bs-theme", currentMode);
}
const setDarkMode = () => {
  userSetting.setDarkMode();
  const currentMode = userSetting.darkMode ? "dark" : "light";
  document.documentElement.setAttribute("data-bs-theme", currentMode);
}
const userSetting = new userSettingStore();

onMounted(() => {
  getDarkMode();
  document.addEventListener("scroll", function () {
    const pageTopbar = document.getElementById("page-topbar");
    if (pageTopbar) {
      document.body.scrollTop >= 50 || document.documentElement.scrollTop >= 50 ? pageTopbar.classList.add(
          "topbar-shadow") : pageTopbar.classList.remove("topbar-shadow");
    }
  });
});
</script>


<style>
</style>