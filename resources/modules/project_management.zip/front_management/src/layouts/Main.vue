<template>
  <TheVertical></TheVertical>
  <div id="preloader" v-show="layout.state.preloader !== 'disable'">
    <div id="status">
      <div class="spinner-border text-primary avatar-sm" role="status">
        <span class="visually-hidden">Loading...</span>
      </div>
    </div>
  </div>
  <div id="modals"></div>
</template>

<script setup>
import Helper from '@/helpers/common.js'
import { useLayoutStore } from '@/stores/useLayout'
import { showNotification } from '@/helpers/notification.js'
import { notifyStore } from '@/modules/notification/stores/notification'
import TheVertical from "@/layouts/vertical/TheVertical.vue";

const layout = useLayoutStore()
const event = Helper.useEvent()
const store = notifyStore()
layout.setLayoutType('vertical');

store.bindEvents(event)
event.on('push-notification', (data) => {
  showNotification(data)
})
</script>
