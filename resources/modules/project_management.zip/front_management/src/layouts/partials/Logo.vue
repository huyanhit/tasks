<template>
  <div class="navbar-brand-box">
    <router-link to="/" class="logo logo-dark">
      <span class="logo-lg ms-lg-5">
        <img src="@/assets/images/logo-dark.png" height="55" />
      </span>
    </router-link>
    <router-link to="/" class="logo logo-light">
      <span class="logo-lg ms-lg-5">
        <img src="@/assets/images/logo-light.png" height="55" />
      </span>
    </router-link>
    <BButton
      variant="white"
      class="btn btn-sm px-4 fs-16 header-item header-icon-menu topnav-hamburger bg_icon_menu"
      id="topnav-hamburger-icon"
      @click="toggleMenu"
    >
      <Icon icon="ri-menu-2-line" class="text-body-secondary" width="24" />
    </BButton>
  </div>
</template>
<script setup lang="ts">
import { Icon } from '@iconify/vue'
import { onMounted } from 'vue'
import {toggleMenu, updateSidebarSize} from '@/layouts/vertical/TheSidebar.ts'

onMounted(() => {
	if (localStorage.getItem('hoverd') === 'true') {
		document.documentElement.setAttribute('data-sidebar-size', 'sm-hover-active');
	}

	const overlay = document.getElementById('overlay');
	if (overlay) {
		overlay.addEventListener('click', () => {
			document.body.classList.remove('vertical-sidebar-enable');
		});
	}

	if (window.screen.width < 1025) {
		document.documentElement.setAttribute("data-sidebar-size", "sm");
	}

	window.addEventListener("resize", updateSidebarSize);
});

onUnmounted(() => {
	window.removeEventListener("resize", updateSidebarSize);
});
</script>

<style lang="css" scoped>
.bg_icon_menu{
  background-color: #1F2C3E;
}
</style>
