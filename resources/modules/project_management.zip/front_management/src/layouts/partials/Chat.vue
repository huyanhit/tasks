<template>
    <BDropdown variant="ghost-secondary" dropstart :offset="{ alignmentAxis: 53, crossAxis: 0, mainAxis: -42 }"
            no-caret class="ms-1 dropdown" toggle-class="btn-icon btn-topbar rounded-circle mode-layout material-shadow-none"
            menu-class="dropdown-menu-lg dropdown-menu-end p-0" text="Manual close (auto-close=false)"
            auto-close="outside">
        <template #button-content>
            <i class="ri-wechat-line fs-22"></i>
        </template>
        <simplebar data-simplebar style="max-height: 300px">
            <div class="p-2">
                <div class="d-block dropdown-item dropdown-item-cart text-wrap px-3 py-2">
                    <div class="d-flex align-items-center">
                    <div class="flex-grow-1">
                        <h6 class="mt-0 mb-1 fs-14"><b class="text-reset">Tên nhóm</b></h6>
                        <p class="mb-0 fs-12 text-muted">Đoạn chat</p>
                    </div>
                    <div class="px-2">
                        <p class="mb-0 fs-12 text-muted">3/7/2024</p>
                    </div>
                    </div>
                </div>
                <div class="d-block dropdown-item dropdown-item-cart text-wrap px-3 py-2">
                    <div class="d-flex align-items-center">
                    <div class="flex-grow-1">
                        <h6 class="mt-0 mb-1 fs-14"><b class="text-reset">Tên nhóm</b></h6>
                        <p class="mb-0 fs-12 text-muted">Đoạn chat</p>
                    </div>
                    <div class="px-2">
                        <p class="mb-0 fs-12 text-muted">3/7/2024</p>
                    </div>
                    </div>
                </div>
                <div class="d-block dropdown-item dropdown-item-cart text-wrap px-3 py-2">
                    <div class="d-flex align-items-center">
                    <div class="flex-grow-1">
                        <h6 class="mt-0 mb-1 fs-14"><b class="text-reset">Tên nhóm</b></h6>
                        <p class="mb-0 fs-12 text-muted">Đoạn chat</p>
                    </div>
                    <div class="px-2">
                        <p class="mb-0 fs-12 text-muted">3/7/2024</p>
                    </div>
                    </div>
                </div>
            </div>
        </simplebar>
        <div  class="p-3 border-bottom-0 border-start-0 border-end-0 border-dashed border"
            id="checkout-elem">
            <router-link to="/chat" variant="secondary" class="btn btn-soft-secondary text-center w-100"> Xem tất cả <i class="ri-arrow-right-line align-middle"></i></router-link>
        </div>
    </BDropdown>
</template>