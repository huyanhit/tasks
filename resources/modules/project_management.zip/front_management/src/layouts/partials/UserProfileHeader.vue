<template>
	<div class="profile__header">
		<div id="scrollbar">
			<BContainer fluid>
				<ul class="navbar-nav" id="navbar-nav">
					<li class="nav-item">
						<span class="btn-navbar btn-navbar-user" data-bs-toggle="collapse" role="button" aria-expanded="false"
						   aria-controls="sidebarMore">
							<img class="rounded-circle header-profile-user" src="@/assets/images/users/avatar-1.jpg" alt="User Avatar">
						</span>
						<div class="collapse menu-dropdown show" id="sidebarMore">
							<ul class="nav nav-sm flex-column">
								<li class="nav-item">
									<router-link to="/" class="nav-link menu-link">
										<i class="mdi mdi-account-circle text-muted fs-16 align-middle me-2"></i>
										<span class="align-middle text-muted"> {{ $t('menu.user_menu.personal_information') }} </span>
									</router-link>
								</li>

								<li class="nav-item">
									<router-link to="/app/settings" class="nav-link menu-link">
										<i class="mdi mdi-cog-outline text-muted fs-16 align-middle me-2"></i>
										<span class="align-middle text-muted"> {{ $t('menu.user_menu.system_settings') }} </span>
									</router-link>
								</li>

								<li class="nav-item">
									<span class="nav-link menu-link" data-bs-toggle="collapse" role="button"
									   aria-expanded="false" aria-controls="sidebarAdvanceUI">
										<i class="ri-global-line text-muted fs-16 align-middle me-2"></i>
										<span class="align-middle text-muted"> {{ $t('menu.user_menu.language') }} </span>
										<span class="float-end">
											<img :src="selectedFlag" class="rounded" height="18" alt="Language Flag">
										</span>
									</span>
									<div class="collapse menu-dropdown" id="sidebarAdvanceUI">
										<ul class="nav nav-sm flex-column">
											<li class="nav-item sub-second" v-for="(entry, key) in languages" :key="key">
												<a href="javascript:void(0);" class="nav-link" data-key="t-sweet-alerts" @click="setLanguage(entry.language, entry.flag, entry.datePicker)">
													<img :src="entry.flag" alt="Language Flag" class="me-2 rounded" height="18">
													<span class="text-muted">{{ $t("menu.user_menu."+entry.language) }} </span>
												</a>
											</li>
										</ul>
									</div>
								</li>

								<li class="nav-item">
									<router-link class="nav-link menu-link" href="#" to="/widgets">
										<i class="ri-question-line text-muted fs-16 align-middle me-2"></i>
										<span class="align-middle text-muted"> {{ $t('menu.user_menu.user_guide') }} </span>
									</router-link>
								</li>

								<li class="nav-item">
									<router-link class="nav-link menu-link" href="#" to="/notification/setting">
										<i class="mdi mdi-lock text-muted fs-16 align-middle me-2"></i>
										<span class="align-middle text-muted"> {{ $t('menu.user_menu.change_password') }} </span>
									</router-link>
								</li>

								<li class="nav-item">
									<router-link class="nav-link menu-link" href="#" to="/" @click="handleLogout">
										<i class="mdi mdi-logout text-muted fs-16 align-middle me-2"></i>
										<span class="align-middle text-muted" data-key="t-logout"> {{ $t('menu.user_menu.logout') }} </span>
									</router-link>
								</li>
							</ul>
						</div>
					</li>
				</ul>
			</BContainer>
		</div>
	</div>
</template>

<script setup lang="ts">
import { ref } from 'vue';
import viFlag from '@/assets/images/flags/vn.svg';
import usFlag from '@/assets/images/flags/us.svg';
import jpFlag from '@/assets/images/flags/jp.svg';
import i18n from "@/plugins/i18n";
import { userSettingStore } from '@/stores/user-setting.ts';
import flatpickr from "flatpickr"
import { Vietnamese } from "flatpickr/dist/l10n/vn";
import { english } from "flatpickr/dist/l10n/default";
import { Japanese } from "flatpickr/dist/l10n/ja";
import { setLocale } from '@vee-validate/i18n';
import {useAppStore} from '@/stores/app'

// Define languages array
const languages = [
	{
		flag: viFlag,
		language: "vi",
		title: "Tiếng Việt",
    datePicker: Vietnamese
  },
	{
		flag: usFlag,
		language: "en",
		title: "English",
    datePicker: english
	},
	{
		flag: jpFlag,
		language: "jp",
		title: "Japanese",
    datePicker: Japanese
	}
];

// Initialize the user setting store
const userSetting = new userSettingStore();

// Define the function to get the flag based on the current locale
const getFlag = () => {
  console.log(i18n.global.locale.value);
	return languages.filter(item => item.language === i18n.global.locale.value)[0].flag;
};

// Define the reactive selectedFlag variable
const selectedFlag = ref(getFlag());

// Define the function to set the language
const setLanguage = (locale: string, flag: string, localeDate: any) => {
  flatpickr.localize(localeDate);
	localStorage.setItem('locale', locale);
	userSetting.setLanguage(locale);
	i18n.global.locale.value = locale;
	setLocale(locale);
	selectedFlag.value = flag;
	document.documentElement.lang = locale;
};

const handleLogout = () => {
	const appStore = useAppStore(); // Lấy ra store
	appStore.logout(); // Gọi hàm logout từ store khi nhấp vào liên kết
};
</script>


