<template>
    <BDropdown
      class="dropdown"
      variant="ghost-secondary"
      dropstart
      :offset="{ alignmentAxis: 53, crossAxis: 0, mainAxis: -42 }"
      toggle-class="btn-icon btn-topbar rounded-circle mode-layout ms-1 arrow-none"
      menu-class="p-0 dropdown-menu-end"
      no-caret
    >
      <template #button-content>
        <i class="ri-apps-2-line fs-22"></i>
      </template>
      <div class="p-3 border-top-0 dropdown-head border-start-0 border-end-0 border-dashed border dropdown-menu-xl">
        <BRow>
          <BCol v-for="(item, idx) in moduleMenu" cols="12" md="3">
            <BRow class="ms-2 pb-2 mb-2 fw-bold fs-15 border-bottom">{{ item.title }}</BRow>
            <BRow cols="12" v-for="(item, idx) in item.items">
              <BCol v-if="item.active" :class="{ 'mp_disabled': item.disable == true }" class="mb-1">
                  <BListGroup flush>
                    <BListGroupItem :to="{ name: item.route_name }" class="p-2 rounded-3">
                        <div class="d-flex align-items-center cursor-pointer">
                          <div class="text-white me-2">
                            <i :class="item.icon" class="p-2 rounded-3" style="font-size: 25px;"
                              :style="`color: rgb(${item.color}); background: rgba(${item.color}, 0.08)`"
                            ></i>
                          </div>
                          <div class="d-flex flex-column">
                            <span class="text-dark-emphasis fs-15">{{ $t(item.title) }}</span>
                            <span class="text-light-emphasis fs-12">{{ $t(item.desc) }}</span>
                          </div>
                        </div>
                    </BListGroupItem>
                  </BListGroup>
              </BCol>
            </BRow>
          </BCol>
        </BRow>
      </div>
    </BDropdown>
  </template>
  
  <script setup lang="ts">
  import {moduleMenu} from '@/configs/moduleMenu/index'
  </script>
  
  <style scoped>
  .list-group-item.list-group-item-secondary{
      --vz-list-group-bg: #fff;
      --vz-list-group-action-hover-bg: #fff3ea;
  }
  .text-dark-emphasis{
    font-weight: 500;
  }
  </style>
  