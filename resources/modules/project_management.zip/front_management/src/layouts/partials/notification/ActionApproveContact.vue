<template>
    <b-button v-if="checkContact === undefined" size="sm" class="mb-2 btn-outline-success" @click.prevent.stop="approveContactId({id:contact_id})"> {{ $t('notification.command.agree') }} </b-button>
</template>
<script setup>
    import { showToast } from '@/helpers/common.js'
    import { useSocketStore } from '@/modules/chat/stores/chat.js'
    import { useI18n } from 'vue-i18n'
    const { t } = useI18n();
    const props = defineProps(['contact_id'])
    const storeChat = useSocketStore();
    const checkContact = computed(()=>{
        if(storeChat.users)
        return storeChat.users.find(item => item.id === props.contact_id)
    })
    const approveContactId = async function(item) {
        const response = await storeChat.approveContact({ids:[item.id]})
        if(response.success){
            showToast({icon : "success", title: t('notification.command.message_approve_content') + item.name});
        }
    }
</script>
<style scoped>

</style>