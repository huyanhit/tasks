<template>
    <BDropdown class="dropdown" variant="ghost-secondary" dropstart
        :offset="{ alignmentAxis: 53, crossAxis: 15, mainAxis: -50 }"
        toggle-class="btn btn-icon btn-topbar btn-ghost-secondary rounded-circle arrow-none"
        menu-class="dropdown-menu-end"
		size="sm"
        no-caret>
        <template #button-content>
            <img id="" :src="getFlag()" alt="Tiếng Việt" height="20" class="rounded">
        </template>
        <BLink href="javascript:void(0);" class="dropdown-item notify-item language py-2"
            v-for="(entry, key) in languages" :data-lang="entry.language" :title="entry.title"
            @click="setLanguage(entry)" :key="key">
            <img :src="entry.flag" alt="user-image" class="me-2 rounded" height="18">
            <span class="align-middle">{{ entry.title }}</span>
        </BLink>
    </BDropdown>
</template>

<script setup lang="ts">
import viFlag from '@/assets/images/flags/vn.svg';
import usFlag from '@/assets/images/flags/us.svg';
import jpFlag from '@/assets/images/flags/jp.svg';
import i18n from "@/plugins/i18n";
import { userSettingStore } from '@/stores/user-setting.ts';
import { setLocale } from '@vee-validate/i18n'
import flatpickr from "flatpickr"
import {Vietnamese} from "flatpickr/dist/l10n/vn";
import {english} from "flatpickr/dist/l10n/default";
import {Japanese} from "flatpickr/dist/l10n/ja";

const languages = [
  {
    flag: viFlag,
    language: "vi",
    title: "Tiếng Việt",
    datePicker: Vietnamese
  },
  {
    flag: usFlag,
    language: "en",
    title: "English",
    datePicker: english
  },
  {
    flag: jpFlag,
    language: "jp",
    title: "Japanese",
    datePicker: Japanese
  }
];
const userSetting = new userSettingStore();
const getFlag = () => {
	return languages.filter(item => item.language === i18n.global.locale.value)[0].flag;
};

const setLanguage = (entry :any) => {
	localStorage.setItem('locale', entry.locale);
  flatpickr.localize(entry.datePicker);
	userSetting.setLanguage(entry.locale);
	i18n.global.locale.value = entry.locale;
    setLocale(entry.locale);
};
</script>