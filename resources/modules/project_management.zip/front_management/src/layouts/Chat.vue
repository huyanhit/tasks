<template>
    <BContainer fluid id="setting-layout">
        <TheHeader />
    </BContainer>
    <div class="layout-chat main-content">
        <div class="page-content d-flex px-0">
            <BContainer fluid class="px-0">
                <BRow>
                    <BCol class="col-lg-12">
                        <router-view :key="$i18n.locale"></router-view>
                    </BCol>
                </BRow>
            </BContainer>
        </div>
    </div>
    <footer class="footer">
        <div class="container-fluid">
            <div class="row">
                <div class="col-sm-6">
                    2024 � Velzon.
                </div>
                <div class="col-sm-6">
                    <div class="text-sm-end d-none d-sm-block">
                        Design &amp; Develop by Themesbrand
                    </div>
                </div>
            </div>
        </div>
    </footer>
    <!-- Loading -->
    <div id="preloader" v-show="layout.state.preloader !== 'disable'">
        <div id="status">
            <div class="spinner-border text-primary avatar-sm" role="status">
                <span class="visually-hidden">Loading...</span>
            </div>
        </div>
    </div>
</template>

<script setup>
import TheHeader from '@/layouts/setting/TheHeader.vue'
import Helper from '@/helpers/common'
import { useLayoutStore } from '@/stores/useLayout'
import { showNotification } from '@/helpers/notification.js'
import { notifyStore } from '@/modules/notification/stores/notification'

const layout = useLayoutStore()
const event = Helper.useEvent()
const store = notifyStore()
import moment from '@/plugins/moment'

layout.setLayoutType('horizontal');
store.bindEvents(event)
moment.locale('vi')
event.on('push-notification', (data) => {
    showNotification(data)
})
</script>

<style>
[data-layout='twocolumn'] #page-topbar {
    left: 220px;
}
[data-layout='twocolumn'] .app-menu {
    left: 0;
    width: 280px;
}
.navbar-menu {
    border-right: none;
    box-shadow: none;
}
.layout-chat .page-content{
    margin-top: 83px !important;
    padding: 0 !important;
}
.layout-chat .chat-wrapper {
    height: calc(100vh - 120px);
}

</style>
